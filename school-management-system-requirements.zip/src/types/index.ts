export type UserRole = 'super_admin' | 'principal' | 'hr' | 'accounts' | 'teacher' | 'student' | 'parent';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  phone?: string;
  is_active: boolean;
  created_at: string;
}

export interface Student {
  id: string;
  user_id: string;
  student_code: string;
  class_id: string;
  section: string;
  date_of_birth: string;
  guardian_id: string;
  admission_date: string;
  roll_no: string;
  address?: string;
  photo_url?: string;
}

export interface Staff {
  id: string;
  user_id: string;
  employee_code: string;
  designation: string;
  department?: string;
  join_date: string;
  cnic: string;
  base_salary: number;
  contract_type: 'permanent' | 'contract' | 'part_time';
  bank_account?: string;
}

export interface Class {
  id: string;
  name: string;
  level: string;
  max_students: number;
  class_teacher_id?: string;
}

export interface Subject {
  id: string;
  name: string;
  code: string;
  class_id: string;
  teacher_id?: string;
  credit_hours: number;
}

export interface Attendance {
  id: string;
  student_id?: string;
  staff_id?: string;
  date: string;
  status: 'present' | 'absent' | 'late' | 'leave';
  check_in?: string;
  check_out?: string;
  remarks?: string;
}

export interface FeeVoucher {
  id: string;
  student_id: string;
  fee_type_id: string;
  month: number;
  year: number;
  amount: number;
  due_date: string;
  status: 'paid' | 'unpaid' | 'overdue';
  voucher_no: string;
}

export interface Exam {
  id: string;
  name: string;
  class_id: string;
  academic_year: string;
  start_date: string;
  end_date: string;
}

export interface Mark {
  id: string;
  student_id: string;
  exam_id: string;
  subject_id: string;
  marks_obtained: number;
  grade: string;
}

export interface Assignment {
  id: string;
  title: string;
  subject_id: string;
  class_id: string;
  teacher_id: string;
  due_date: string;
  file_url?: string;
  max_marks: number;
}

export interface LeaveRequest {
  id: string;
  staff_id: string;
  leave_type_id: string;
  from_date: string;
  to_date: string;
  reason: string;
  status: 'pending' | 'approved' | 'rejected';
  reviewed_by?: string;
}

export interface Notice {
  id: string;
  title: string;
  content: string;
  target_roles: UserRole[];
  posted_by: string;
  posted_at: string;
  expiry_date?: string;
  is_active: boolean;
}

export interface Event {
  id: string;
  title: string;
  description: string;
  event_date: string;
  location?: string;
  created_by: string;
  target_roles: UserRole[];
}

export interface Expense {
  id: string;
  category: string;
  description: string;
  amount: number;
  date: string;
  paid_to: string;
  approved_by?: string;
  receipt_url?: string;
}

export interface Payroll {
  id: string;
  staff_id: string;
  month: number;
  year: number;
  basic_salary: number;
  allowances: number;
  deductions: number;
  net_salary: number;
  status: 'generated' | 'paid';
  paid_at?: string;
}

export interface ActivityLog {
  id: string;
  user_id: string;
  action: string;
  entity_type: string;
  entity_id?: string;
  ip_address?: string;
  timestamp: string;
}