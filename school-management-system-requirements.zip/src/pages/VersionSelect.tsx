import { useNavigate } from 'react-router-dom';
import {
  Smartphone, Globe, ArrowRight, AlertTriangle, CheckCircle2, Wrench,
} from 'lucide-react';

// Yeh page aapko do versions dikhata hai:
//   Option A = Mobile App (Capacitor) — jahan pehle "loading" wali galti thi (ab fix)
//   Option B = Website — aapki original website
export function VersionSelect() {
  const navigate = useNavigate();

  // Chuna gaya version yaad rakhte hain taake Login page bata sake aap kis mode mein hain.
  const choose = (mode: 'mobile' | 'web') => {
    try {
      localStorage.setItem('sms_view_mode', mode);
    } catch {
      /* ignore */
    }
    navigate('/login');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-indigo-50 px-4 py-10">
      <div className="mx-auto max-w-5xl">
        {/* Header */}
        <div className="mb-10 text-center">
          <div className="mx-auto mb-4 inline-flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-indigo-600 to-violet-600 shadow-lg shadow-indigo-200">
            <span className="text-xl font-bold text-white">SMS</span>
          </div>
          <h1 className="text-3xl font-bold tracking-tight text-slate-900">School Management System</h1>
          <p className="mt-2 text-slate-600">Apna version chunein — neeche dono ka farq aur galti ki tafseel mojood hai</p>
        </div>

        {/* Two options */}
        <div className="grid gap-6 md:grid-cols-2">
          {/* OPTION A — Mobile App */}
          <div className="relative overflow-hidden rounded-3xl border-2 border-indigo-200 bg-white p-7 shadow-sm transition hover:shadow-lg">
            <div className="absolute right-5 top-5 rounded-full bg-indigo-100 px-3 py-1 text-xs font-bold text-indigo-700">
              OPTION A
            </div>
            <div className="mb-4 inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-indigo-500 to-violet-600 text-white">
              <Smartphone className="h-7 w-7" />
            </div>
            <h2 className="text-xl font-bold text-slate-900">Mobile App (Capacitor)</h2>
            <p className="mt-1 text-sm text-slate-600">
              Yehi woh version hai jise Play Store par upload kiya jaata hai. Pehle yeh "Loading…"
              par atak jaata tha — ab woh galti theek ho chuki hai.
            </p>

            <div className="mt-4 space-y-2 rounded-xl bg-emerald-50 p-3">
              <p className="flex items-center gap-2 text-sm font-semibold text-emerald-800">
                <CheckCircle2 className="h-4 w-4" /> Ab theek kaam kar raha hai
              </p>
              <ul className="ml-6 list-disc space-y-1 text-xs text-emerald-700">
                <li>HashRouter (mobile <code>file://</code> par chalta hai)</li>
                <li>Database migration (purana data crash nahi karta)</li>
                <li>Splash screen + status bar + back button</li>
              </ul>
            </div>

            <button
              type="button"
              onClick={() => choose('mobile')}
              className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 px-4 py-3 font-semibold text-white shadow-md transition hover:from-indigo-700 hover:to-violet-700"
            >
              Mobile App kholein <ArrowRight className="h-4 w-4" />
            </button>
          </div>

          {/* OPTION B — Website (ab Mobile App bhi) */}
          <div className="relative overflow-hidden rounded-3xl border-2 border-blue-200 bg-white p-7 shadow-sm transition hover:shadow-lg">
            <div className="absolute right-5 top-5 rounded-full bg-blue-100 px-3 py-1 text-xs font-bold text-blue-700">
              OPTION B
            </div>
            <div className="mb-4 inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-500 to-cyan-600 text-white">
              <Globe className="h-7 w-7" />
            </div>
            <h2 className="text-xl font-bold text-slate-900">Website → Mobile App</h2>
            <p className="mt-1 text-sm text-slate-600">
              Aapki original website ab poori tarah mobile app mein convert ho chuki hai —
              hamburger menu, bottom navigation aur touch-friendly layout ke saath.
            </p>

            <div className="mt-4 space-y-2 rounded-xl bg-emerald-50 p-3">
              <p className="flex items-center gap-2 text-sm font-semibold text-emerald-800">
                <CheckCircle2 className="h-4 w-4" /> Ab mobile app jaisa chalta hai
              </p>
              <ul className="ml-6 list-disc space-y-1 text-xs text-emerald-700">
                <li>Slide-in side menu (hamburger ☰)</li>
                <li>Niche bottom navigation bar</li>
                <li>Phone screen ke mutabiq responsive UI</li>
              </ul>
            </div>

            <button
              type="button"
              onClick={() => choose('web')}
              className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-600 px-4 py-3 font-semibold text-white shadow-md transition hover:from-blue-700 hover:to-cyan-700"
            >
              Mobile App (B) kholein <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Galti ki tafseel */}
        <div className="mt-8 rounded-3xl border border-amber-200 bg-amber-50 p-6">
          <div className="mb-3 flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-amber-600" />
            <h3 className="text-lg font-bold text-amber-900">Galti kahan thi? (Mobile App / Option A)</h3>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <div className="rounded-2xl border border-rose-200 bg-white p-4">
              <p className="mb-2 flex items-center gap-2 text-sm font-bold text-rose-700">
                <AlertTriangle className="h-4 w-4" /> Masla (Pehle)
              </p>
              <ol className="ml-4 list-decimal space-y-1.5 text-sm text-slate-700">
                <li>
                  <b>BrowserRouter</b> mobile app ke <code>file://</code> protocol par
                  chal nahi raha tha — page khali aata tha.
                </li>
                <li>
                  Purana <b>database (localStorage)</b> mein nayi collections (Documents,
                  Cash Book waghera) mojood nahi thi.
                </li>
                <li>
                  Is wajah se <code>getAll()</code> har dafa <b>naya empty array</b> deta tha
                  → React <code>useSyncExternalStore</code> <b>infinite loop</b> mein chala
                  jaata → app "Loading…" par atak jaati.
                </li>
              </ol>
            </div>

            <div className="rounded-2xl border border-emerald-200 bg-white p-4">
              <p className="mb-2 flex items-center gap-2 text-sm font-bold text-emerald-700">
                <Wrench className="h-4 w-4" /> Hal (Ab)
              </p>
              <ol className="ml-4 list-decimal space-y-1.5 text-sm text-slate-700">
                <li>
                  <code>App.tsx</code> mein <b>HashRouter</b> use kiya — web + mobile dono par
                  routing chalti hai.
                </li>
                <li>
                  <code>db.ts</code> ke <code>load()</code> mein <b>migration</b> add kiya —
                  purane data mein nayi collections khud-ba-khud add ho jaati hain.
                </li>
                <li>
                  <code>getAll()</code> ab ek <b>stable EMPTY array</b> deta hai → infinite loop
                  khatam → app theek load hoti hai.
                </li>
              </ol>
            </div>
          </div>

          <div className="mt-4 rounded-xl bg-white p-3 text-xs text-slate-500">
            <b>Note:</b> Code dono (Mobile App aur Website) ke liye bilkul same hai. Farq sirf
            itna hai ke Mobile App Capacitor ke andar chalti hai aur Play Store par jaati hai,
            jabke Website browser mein khulti hai. Upar di gayi 3 cheezein theek karne ke baad
            dono perfect chalti hain.
          </div>
        </div>
      </div>
    </div>
  );
}
