import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { ForgotPassword } from './ForgotPassword';

const quickLogins = [
  { role: 'Super Admin', email: 'admin@school.edu' },
  { role: 'Principal', email: 'principal@school.edu' },
  { role: 'HR Manager', email: 'hr@school.edu' },
  { role: 'Accounts', email: 'accounts@school.edu' },
  { role: 'Teacher', email: 'teacher@school.edu' },
  { role: 'Student', email: 'student@school.edu' },
  { role: 'Parent', email: 'parent@school.edu' },
];

export function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showForgot, setShowForgot] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();
  // Kaunsa version chuna gaya (Option A = mobile, Option B = web)
  const viewMode = (() => {
    try { return localStorage.getItem('sms_view_mode'); } catch { return null; }
  })();

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');
    const res = await login(email, password);
    if (res.ok) navigate('/dashboard');
    else setError(res.error || 'Login failed');
    setIsLoading(false);
  };

  const quick = (qEmail: string) => {
    setEmail(qEmail);
    setPassword('admin123');
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-blue-50 via-white to-indigo-50 p-4">
      <div className="w-full max-w-md space-y-6">
        <div className="text-center">
          <div className="inline-flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-600 to-indigo-700 shadow-lg shadow-blue-200">
            <svg className="h-8 w-8 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
              <path d="M12 15c2.2 0 4-1.8 4-4V5l-4-3-4 3v6c0 2.2 1.8 4 4 4z" />
              <path d="M2 12h20" />
              <path d="M12 15v7" />
            </svg>
          </div>
          <h2 className="mt-6 text-3xl font-bold tracking-tight text-slate-900">School Management System</h2>
          <p className="mt-2 text-sm text-slate-600">Sign in to access your dashboard</p>
          {viewMode && (
            <span
              className={`mt-3 inline-block rounded-full px-3 py-1 text-xs font-semibold ${
                viewMode === 'mobile'
                  ? 'bg-indigo-100 text-indigo-700'
                  : 'bg-blue-100 text-blue-700'
              }`}
            >
              {viewMode === 'mobile' ? '📱 Option A — Mobile App Mode' : '🌐 Option B — Website Mode'}
            </span>
          )}
        </div>

        <form className="space-y-4 rounded-lg bg-white p-6 shadow-xl shadow-slate-200/50" onSubmit={submit}>
          <div>
            <label className="block text-sm font-medium text-slate-700">Email address</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="mt-1 block w-full rounded-md border border-slate-300 px-3 py-2 shadow-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
              placeholder="admin@school.edu"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700">Password</label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="mt-1 block w-full rounded-md border border-slate-300 px-3 py-2 shadow-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
              placeholder="Enter your password"
            />
          </div>
          {error && <div className="rounded-md bg-red-50 p-3 text-sm text-red-600">{error}</div>}
          <button
            type="submit"
            disabled={isLoading}
            className="flex w-full justify-center rounded-md bg-gradient-to-r from-blue-600 to-indigo-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:from-blue-700 hover:to-indigo-700 disabled:opacity-50"
          >
            {isLoading ? 'Signing in...' : 'Sign in'}
          </button>
          <button type="button" onClick={() => setShowForgot(true)} className="w-full text-center text-sm font-medium text-blue-600 hover:text-blue-700">
            Forgot Password?
          </button>
        </form>

        <div className="rounded-lg bg-white/70 p-4 shadow-sm">
          <p className="mb-2 text-center text-xs font-medium text-slate-500">
            Quick login (password: <span className="font-mono">admin123</span>)
          </p>
          <div className="grid grid-cols-2 gap-2">
            {quickLogins.map((q) => (
              <button
                key={q.email}
                onClick={() => quick(q.email)}
                className="rounded-md border border-slate-200 bg-white px-3 py-2 text-xs font-medium text-slate-700 hover:border-blue-400 hover:bg-blue-50"
              >
                {q.role}
              </button>
            ))}
          </div>
        </div>

        <div className="text-center">
          <button
            onClick={() => navigate('/')}
            className="text-sm font-medium text-slate-500 hover:text-slate-700"
          >
            ← Wapas (Version A / B chunein)
          </button>
        </div>
      </div>

      {showForgot && <ForgotPassword onClose={() => setShowForgot(false)} />}
    </div>
  );
}
