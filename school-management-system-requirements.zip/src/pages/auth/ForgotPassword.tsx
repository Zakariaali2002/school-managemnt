import { useState } from 'react';
import { KeyRound, ShieldCheck, CheckCircle2, X } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

// Forgot-password flow: identifier -> OTP -> verify -> new password.
export function ForgotPassword({ onClose }: { onClose: () => void }) {
  const { requestOtp, resetPassword } = useAuth();
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);
  const [identifier, setIdentifier] = useState('');
  const [sentOtp, setSentOtp] = useState('');
  const [via, setVia] = useState('');
  const [enteredOtp, setEnteredOtp] = useState('');
  const [newPass, setNewPass] = useState('');
  const [confirmPass, setConfirmPass] = useState('');
  const [error, setError] = useState('');

  const sendOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    const res = requestOtp(identifier);
    if (!res.ok) return setError(res.error || 'Failed');
    setSentOtp(res.otp!);
    setVia(res.via || '');
    setStep(2);
  };

  const verifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (enteredOtp.trim() !== sentOtp) return setError('Incorrect OTP. Please try again.');
    setStep(3);
  };

  const reset = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (newPass !== confirmPass) return setError('Passwords do not match');
    const res = resetPassword(identifier, newPass);
    if (!res.ok) return setError(res.error || 'Failed');
    setStep(4);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
      <div className="w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl">
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-600 to-violet-600 text-white">
              <KeyRound className="h-5 w-5" />
            </div>
            <h2 className="text-lg font-bold text-slate-900">Forgot Password</h2>
          </div>
          <button onClick={onClose} className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100"><X className="h-5 w-5" /></button>
        </div>

        {/* Step indicator */}
        <div className="mb-5 flex items-center gap-2">
          {[1, 2, 3].map((s) => (
            <div key={s} className={`h-1.5 flex-1 rounded-full ${step >= s ? 'bg-indigo-600' : 'bg-slate-200'}`} />
          ))}
        </div>

        {error && <div className="mb-3 rounded-md bg-rose-50 p-2.5 text-sm text-rose-600">{error}</div>}

        {step === 1 && (
          <form onSubmit={sendOtp} className="space-y-4">
            <p className="text-sm text-slate-500">Enter your registered email or mobile number to receive an OTP.</p>
            <div>
              <label className="block text-sm font-medium text-slate-700">Email or Mobile Number</label>
              <input value={identifier} onChange={(e) => setIdentifier(e.target.value)} required
                className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                placeholder="admin@school.edu or 0300-1234567" />
            </div>
            <button type="submit" className="w-full rounded-md bg-gradient-to-r from-indigo-600 to-violet-600 py-2 font-medium text-white hover:from-indigo-700 hover:to-violet-700">
              Send OTP
            </button>
          </form>
        )}

        {step === 2 && (
          <form onSubmit={verifyOtp} className="space-y-4">
            <div className="rounded-lg bg-indigo-50 p-3 text-sm text-indigo-700">
              <ShieldCheck className="mb-1 inline h-4 w-4" /> OTP sent via {via}.
              <div className="mt-1 text-xs text-indigo-500">Demo OTP: <span className="font-mono font-bold">{sentOtp}</span> (auto-shown for testing)</div>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700">Enter 6-digit OTP</label>
              <input value={enteredOtp} onChange={(e) => setEnteredOtp(e.target.value)} required maxLength={6}
                className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2 text-center font-mono text-lg tracking-widest focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                placeholder="------" />
            </div>
            <button type="submit" className="w-full rounded-md bg-gradient-to-r from-indigo-600 to-violet-600 py-2 font-medium text-white hover:from-indigo-700 hover:to-violet-700">
              Verify OTP
            </button>
          </form>
        )}

        {step === 3 && (
          <form onSubmit={reset} className="space-y-4">
            <p className="text-sm text-slate-500">Create a new password for your account.</p>
            <div>
              <label className="block text-sm font-medium text-slate-700">New Password</label>
              <input type="password" value={newPass} onChange={(e) => setNewPass(e.target.value)} required
                className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700">Confirm Password</label>
              <input type="password" value={confirmPass} onChange={(e) => setConfirmPass(e.target.value)} required
                className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500" />
            </div>
            <button type="submit" className="w-full rounded-md bg-gradient-to-r from-indigo-600 to-violet-600 py-2 font-medium text-white hover:from-indigo-700 hover:to-violet-700">
              Reset Password
            </button>
          </form>
        )}

        {step === 4 && (
          <div className="py-6 text-center">
            <CheckCircle2 className="mx-auto mb-3 h-14 w-14 text-emerald-500" />
            <h3 className="text-lg font-bold text-slate-900">Password Reset!</h3>
            <p className="mt-1 text-sm text-slate-500">You can now log in with your new password.</p>
            <button onClick={onClose} className="mt-5 w-full rounded-md bg-gradient-to-r from-indigo-600 to-violet-600 py-2 font-medium text-white hover:from-indigo-700 hover:to-violet-700">
              Back to Login
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
