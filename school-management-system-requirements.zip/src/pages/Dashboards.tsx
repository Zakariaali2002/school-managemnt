import { useNavigate } from 'react-router-dom';
import { useCollection } from '../hooks/useDB';
import { getAll, getSettings } from '../lib/db';
import { useAuth } from '../contexts/AuthContext';
import { PageHeader, StatCard, Card, Btn, EmptyState } from '../components/ui/Shared';
import { DocumentAlerts, MyDocumentAlerts } from '../components/DocumentAlerts';
import { StatusBadge, money, fmtDate, calcGrade, printDocument, barcodeSvgString } from '../lib/utils';
import {
  GraduationCap, Users, CreditCard, Activity, CheckSquare, FileText, ClipboardCheck,
  BookOpen, ScanLine, Contact,
} from 'lucide-react';

// ---------- SUPER ADMIN ----------
export function SuperAdminHome() {
  const navigate = useNavigate();
  const students = useCollection<any>('students');
  const staff = useCollection<any>('staff');
  const payments = useCollection<any>('feePayments');
  const logs = useCollection<any>('activityLogs');
  const studentAtt = useCollection<any>('studentAttendance');
  const staffAtt = useCollection<any>('staffAttendance');
  const collected = payments.reduce((a, p) => a + p.amount_paid, 0);
  const today = new Date().toISOString().slice(0, 10);
  const presentToday = studentAtt.filter((a) => a.date === today && (a.status === 'present' || a.status === 'late')).length
    + staffAtt.filter((a) => a.date === today && (a.status === 'present' || a.status === 'late')).length;

  return (
    <div>
      <PageHeader title="Super Admin Dashboard" subtitle="Full system overview" />
      <div className="mb-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard title="Total Students" value={students.length} icon={GraduationCap} color="from-blue-500 to-blue-600" onClick={() => navigate('/dashboard/students')} />
        <StatCard title="Total Staff" value={staff.length} icon={Users} color="from-green-500 to-green-600" onClick={() => navigate('/dashboard/staff')} />
        <StatCard title="Present Today" value={presentToday} icon={CheckSquare} color="from-teal-500 to-teal-600" sub="Scanned attendance" onClick={() => navigate('/dashboard/attendance')} />
        <StatCard title="Fee Collected" value={money(collected)} icon={CreditCard} color="from-purple-500 to-purple-600" onClick={() => navigate('/dashboard/finance')} />
      </div>
      <div className="mb-6 grid gap-6 lg:grid-cols-3">
        <Card title="ID Cards & Attendance" action={undefined}>
          <p className="mb-3 text-sm text-slate-600">Generate scannable ID cards and run the barcode attendance scanner.</p>
          <div className="flex flex-wrap gap-2">
            <Btn onClick={() => navigate('/dashboard/id-cards')}><span className="flex items-center gap-2"><Contact className="h-4 w-4" /> Generate ID Cards</span></Btn>
            <Btn variant="success" onClick={() => navigate('/dashboard/scanner')}><span className="flex items-center gap-2"><ScanLine className="h-4 w-4" /> Open Scanner</span></Btn>
          </div>
        </Card>
        <Card title="Quick Links">
          <div className="grid grid-cols-2 gap-2">
            <Btn variant="secondary" onClick={() => navigate('/dashboard/students')}>Students</Btn>
            <Btn variant="secondary" onClick={() => navigate('/dashboard/staff')}>Staff</Btn>
            <Btn variant="secondary" onClick={() => navigate('/dashboard/users')}>Users</Btn>
            <Btn variant="secondary" onClick={() => navigate('/dashboard/reports')}>Reports</Btn>
          </div>
        </Card>
        <StatCard title="System Events" value={logs.length} icon={Activity} color="from-orange-500 to-orange-600" sub="Audit log entries" onClick={() => navigate('/dashboard/logs')} />
      </div>
      <div className="mb-6">
        <h2 className="mb-3 text-sm font-semibold text-slate-700">Document Alerts</h2>
        <DocumentAlerts />
      </div>
      <Card title="Recent Activity">
        <div className="space-y-2">
          {logs.slice(0, 8).map((l) => (
            <div key={l.id} className="flex items-center justify-between rounded-lg bg-slate-50 px-3 py-2 text-sm">
              <div><span className="font-medium text-slate-900">{l.user_name}</span> <span className="text-slate-600">{l.action}</span></div>
              <span className="text-xs text-slate-400">{new Date(l.timestamp).toLocaleTimeString()}</span>
            </div>
          ))}
          {logs.length === 0 && <EmptyState message="No activity" />}
        </div>
      </Card>
    </div>
  );
}

// ---------- PRINCIPAL ----------
export function PrincipalHome() {
  const navigate = useNavigate();
  const students = useCollection<any>('students');
  const staff = useCollection<any>('staff');
  const leaves = useCollection<any>('leaveRequests').filter((l) => l.status === 'pending');
  const expenses = useCollection<any>('expenses').filter((e) => !e.approved_by);
  const attendance = useCollection<any>('studentAttendance');
  const presentToday = attendance.filter((a) => a.date === new Date().toISOString().slice(0, 10) && a.status === 'present').length;
  const todayTotal = attendance.filter((a) => a.date === new Date().toISOString().slice(0, 10)).length || 1;

  return (
    <div>
      <PageHeader title="Principal Dashboard" subtitle="School oversight and approvals" />
      <div className="mb-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard title="Enrollment" value={students.length} icon={GraduationCap} color="from-blue-500 to-blue-600" onClick={() => navigate('/dashboard/students')} />
        <StatCard title="Today Attendance" value={`${Math.round((presentToday / todayTotal) * 100)}%`} icon={CheckSquare} color="from-green-500 to-green-600" onClick={() => navigate('/dashboard/attendance')} />
        <StatCard title="Staff" value={staff.length} icon={Users} color="from-purple-500 to-purple-600" onClick={() => navigate('/dashboard/staff')} />
        <StatCard title="Pending Approvals" value={leaves.length + expenses.length} icon={ClipboardCheck} color="from-orange-500 to-orange-600" onClick={() => navigate('/dashboard/approvals')} />
      </div>
      <div className="grid gap-6 lg:grid-cols-2">
        <Card title="Pending Approvals" action={<Btn size="sm" variant="secondary" onClick={() => navigate('/dashboard/approvals')}>View All</Btn>}>
          <div className="space-y-2">
            {leaves.slice(0, 3).map((l) => (
              <div key={l.id} className="rounded-lg bg-slate-50 px-3 py-2 text-sm">
                <span className="font-medium text-slate-900">{l.staff_name}</span> · {l.leave_type}
              </div>
            ))}
            {expenses.slice(0, 2).map((e) => (
              <div key={e.id} className="rounded-lg bg-slate-50 px-3 py-2 text-sm">
                <span className="font-medium text-slate-900">Expense</span> · {e.description} ({money(e.amount)})
              </div>
            ))}
            {leaves.length + expenses.length === 0 && <EmptyState message="All caught up" />}
          </div>
        </Card>
        <Card title="Quick Actions">
          <div className="grid grid-cols-2 gap-2">
            <Btn variant="secondary" onClick={() => navigate('/dashboard/notices')}>Post Notice</Btn>
            <Btn variant="secondary" onClick={() => navigate('/dashboard/reports')}>View Reports</Btn>
            <Btn variant="secondary" onClick={() => navigate('/dashboard/exams')}>Manage Exams</Btn>
            <Btn variant="secondary" onClick={() => navigate('/dashboard/students')}>Students</Btn>
          </div>
        </Card>
      </div>
    </div>
  );
}

// ---------- HR ----------
export function HRHome() {
  const navigate = useNavigate();
  const staff = useCollection<any>('staff');
  const leaves = useCollection<any>('leaveRequests');
  const payroll = useCollection<any>('payroll');
  const pending = leaves.filter((l) => l.status === 'pending');

  return (
    <div>
      <PageHeader title="HR Dashboard" subtitle="Staff lifecycle management" />
      <div className="mb-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard title="Total Staff" value={staff.length} icon={Users} color="from-blue-500 to-blue-600" onClick={() => navigate('/dashboard/staff')} />
        <StatCard title="Pending Leaves" value={pending.length} icon={FileText} color="from-yellow-500 to-yellow-600" onClick={() => navigate('/dashboard/leave')} />
        <StatCard title="Payroll Records" value={payroll.length} icon={CreditCard} color="from-green-500 to-green-600" onClick={() => navigate('/dashboard/payroll')} />
        <StatCard title="Departments" value={new Set(staff.map((s) => s.department)).size} icon={Activity} color="from-purple-500 to-purple-600" onClick={() => navigate('/dashboard/staff')} />
      </div>
      <div className="grid gap-6 lg:grid-cols-2">
        <Card title="Pending Leave Requests" action={<Btn size="sm" variant="secondary" onClick={() => navigate('/dashboard/leave')}>Review</Btn>}>
          <div className="space-y-2">
            {pending.map((l) => (
              <div key={l.id} className="flex items-center justify-between rounded-lg bg-slate-50 px-3 py-2 text-sm">
                <span className="font-medium text-slate-900">{l.staff_name}</span>
                <span className="text-slate-500">{l.leave_type}</span>
              </div>
            ))}
            {pending.length === 0 && <EmptyState message="No pending requests" />}
          </div>
        </Card>
        <Card title="Quick Actions">
          <div className="grid grid-cols-2 gap-2">
            <Btn variant="secondary" onClick={() => navigate('/dashboard/staff')}>Manage Staff</Btn>
            <Btn variant="secondary" onClick={() => navigate('/dashboard/payroll')}>Run Payroll</Btn>
            <Btn variant="secondary" onClick={() => navigate('/dashboard/staff-attendance')}>Attendance</Btn>
            <Btn variant="secondary" onClick={() => navigate('/dashboard/documents')}>Documents</Btn>
          </div>
        </Card>
      </div>
      <div className="mt-6">
        <h2 className="mb-3 text-sm font-semibold text-slate-700">Document Alerts</h2>
        <DocumentAlerts />
      </div>
    </div>
  );
}

// ---------- TEACHER ----------
export function TeacherHome() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const assignments = useCollection<any>('assignments');
  const subjects = useCollection<any>('subjects');
  const timetable = useCollection<any>('timetable');
  const today = new Date().toLocaleDateString('en-US', { weekday: 'long' });
  const subName = (id: string) => subjects.find((s) => s.id === id)?.name || '-';
  const todays = timetable.filter((t) => t.day_of_week === today);

  return (
    <div>
      <PageHeader title="Teacher Dashboard" subtitle={`Welcome ${user?.name}`} />
      <MyDocumentAlerts userId={user!.id} role="teacher" />
      <div className="mb-6 grid gap-4 sm:grid-cols-3">
        <StatCard title="My Assignments" value={assignments.length} icon={BookOpen} color="from-blue-500 to-blue-600" />
        <StatCard title="Today's Classes" value={todays.length} icon={CheckSquare} color="from-green-500 to-green-600" />
        <StatCard title="Subjects" value={subjects.length} icon={FileText} color="from-purple-500 to-purple-600" />
      </div>
      <div className="grid gap-6 lg:grid-cols-2">
        <Card title={`Today's Schedule (${today})`}>
          <div className="space-y-2">
            {todays.map((t) => (
              <div key={t.id} className="flex items-center justify-between rounded-lg bg-slate-50 px-3 py-2 text-sm">
                <span className="font-medium text-slate-900">{subName(t.subject_id)}</span>
                <span className="text-slate-500">{t.start_time}-{t.end_time} · {t.room}</span>
              </div>
            ))}
            {todays.length === 0 && <EmptyState message="No classes scheduled today" />}
          </div>
        </Card>
        <Card title="Quick Actions">
          <div className="grid grid-cols-2 gap-2">
            <Btn variant="secondary" onClick={() => navigate('/dashboard/attendance')}>Mark Attendance</Btn>
            <Btn variant="secondary" onClick={() => navigate('/dashboard/marks')}>Enter Marks</Btn>
            <Btn variant="secondary" onClick={() => navigate('/dashboard/assignments')}>Assignments</Btn>
            <Btn variant="secondary" onClick={() => navigate('/dashboard/leave')}>Apply Leave</Btn>
          </div>
        </Card>
      </div>
    </div>
  );
}

// Helper: resolve the student record for a logged-in student
export function useMyStudent() {
  const { user } = useAuth();
  const students = useCollection<any>('students');
  return students.find((s) => s.user_id === user?.id) || students[0];
}

// ---------- STUDENT ----------
export function StudentHome() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const student = useMyStudent();
  const classes = useCollection<any>('classes');
  const marks = useCollection<any>('marks').filter((m) => m.student_id === student?.id);
  const attendance = useCollection<any>('studentAttendance').filter((a) => a.student_id === student?.id);
  const vouchers = useCollection<any>('feeVouchers').filter((v) => v.student_id === student?.id);
  const present = attendance.filter((a) => a.status === 'present').length;
  const pct = attendance.length ? Math.round((present / attendance.length) * 100) : 0;
  const cls = classes.find((c) => c.id === student?.class_id);
  const latestFee = vouchers[vouchers.length - 1];

  const idCard = () => {
    const barcode = barcodeSvgString(student.student_code, 300, 64);
    printDocument(`ID Card - ${student.name}`, `
      <div class="title">Student ID Card</div>
      <div style="max-width:360px; border:1px solid #cbd5e1; border-radius:14px; overflow:hidden;">
        <div style="background:linear-gradient(to right,#2563eb,#4f46e5); color:#fff; text-align:center; padding:10px;">
          <div style="font-size:15px; font-weight:bold;">${getSettings().school_name}</div>
          <div style="font-size:10px; color:#dbeafe;">STUDENT ID CARD</div>
        </div>
        <div style="display:flex; gap:12px; padding:16px; align-items:center;">
          <div style="width:64px; height:80px; background:#dbeafe; border-radius:8px; display:flex; align-items:center; justify-content:center; font-size:34px;">🎓</div>
          <div style="font-size:12px; color:#475569;">
            <div style="font-size:15px; font-weight:bold; color:#0f172a;">${student.name}</div>
            <div>${cls?.name || ''} - ${student.section}</div>
            <div>Roll: ${student.roll_no}</div>
            <div style="color:#94a3b8;">${student.student_code}</div>
          </div>
        </div>
        <div style="border-top:1px solid #e2e8f0; padding:8px; text-align:center;">${barcode}</div>
      </div>
    `);
  };

  if (!student) return <EmptyState message="No student profile linked" />;

  return (
    <div>
      <PageHeader title="Student Dashboard" subtitle={`${cls?.name || ''} - Roll ${student.roll_no}`} />
      {user && <MyDocumentAlerts userId={user.id} role="student" />}
      <Card>
        <div className="flex flex-wrap items-center gap-4">
          <div className="flex h-20 w-20 items-center justify-center rounded-full bg-slate-200 text-3xl">🎓</div>
          <div>
            <h2 className="text-xl font-semibold text-slate-900">{student.name}</h2>
            <p className="text-slate-600">{student.student_code}</p>
            <p className="text-sm text-slate-500">Admitted {fmtDate(student.admission_date)}</p>
          </div>
          <Btn className="ml-auto" onClick={idCard}>Download ID Card</Btn>
        </div>
      </Card>

      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        <Card title="Attendance">
          <div className="flex items-center justify-center">
            <div className="relative h-28 w-28">
              <svg className="h-full w-full -rotate-90">
                <circle cx="56" cy="56" r="48" stroke="#e2e8f0" strokeWidth="10" fill="none" />
                <circle cx="56" cy="56" r="48" stroke="#6366f1" strokeWidth="10" strokeLinecap="round" fill="none" strokeDasharray="301.6" strokeDashoffset={301.6 - (301.6 * pct) / 100} />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center text-xl font-bold text-slate-900">{pct}%</div>
            </div>
          </div>
        </Card>
        <Card title="Fee Status">
          {latestFee ? (
            <div className="space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-slate-600">Amount</span><span className="font-medium">{money(latestFee.amount)}</span></div>
              <div className="flex justify-between"><span className="text-slate-600">Due</span><span>{fmtDate(latestFee.due_date)}</span></div>
              <div className="flex justify-between"><span className="text-slate-600">Status</span><StatusBadge status={latestFee.status} /></div>
            </div>
          ) : <EmptyState message="No fee vouchers" />}
        </Card>
        <Card title="Latest Results" action={<Btn size="sm" variant="secondary" onClick={() => navigate('/dashboard/results')}>All</Btn>}>
          <div className="space-y-2 text-sm">
            {marks.slice(0, 4).map((m) => {
              const sub = getAll('subjects').find((s: any) => s.id === m.subject_id);
              return (
                <div key={m.id} className="flex items-center justify-between">
                  <span className="text-slate-700">{sub?.name || '-'}</span>
                  <span className="rounded-full bg-blue-100 px-2 py-0.5 text-xs font-medium text-blue-700">{m.grade || calcGrade((m.marks_obtained / m.total_marks) * 100)}</span>
                </div>
              );
            })}
            {marks.length === 0 && <EmptyState message="No results yet" />}
          </div>
        </Card>
      </div>
    </div>
  );
}

// ---------- PARENT ----------
export function ParentHome() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const students = useCollection<any>('students').filter((s) => s.guardian_id === user?.id);
  const classes = useCollection<any>('classes');
  const child = students[0];
  const attendance = useCollection<any>('studentAttendance').filter((a) => a.student_id === child?.id);
  const present = attendance.filter((a) => a.status === 'present').length;
  const pct = attendance.length ? Math.round((present / attendance.length) * 100) : 0;

  return (
    <div>
      <PageHeader title="Parent Dashboard" subtitle="Monitor your children" />
      {user && <MyDocumentAlerts userId={user.id} role="parent" />}
      <div className="mb-6 grid gap-4 sm:grid-cols-3">
        <StatCard title="Children" value={students.length} icon={GraduationCap} color="from-blue-500 to-blue-600" />
        <StatCard title="Attendance" value={`${pct}%`} icon={CheckSquare} color="from-green-500 to-green-600" />
        <StatCard title="Class" value={classes.find((c) => c.id === child?.class_id)?.name || '-'} icon={BookOpen} color="from-purple-500 to-purple-600" />
      </div>
      <Card title="Children">
        <div className="space-y-2">
          {students.map((s) => (
            <div key={s.id} className="flex items-center justify-between rounded-lg bg-slate-50 px-3 py-2 text-sm">
              <div><span className="font-medium text-slate-900">{s.name}</span> · {classes.find((c) => c.id === s.class_id)?.name}</div>
              <span className="text-slate-500">Roll {s.roll_no}</span>
            </div>
          ))}
          {students.length === 0 && <EmptyState message="No children linked" />}
        </div>
      </Card>
      <div className="mt-6">
        <Card title="Quick Actions">
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            <Btn variant="secondary" onClick={() => navigate('/dashboard/progress')}>Progress</Btn>
            <Btn variant="secondary" onClick={() => navigate('/dashboard/attendance')}>Attendance</Btn>
            <Btn variant="secondary" onClick={() => navigate('/dashboard/fee')}>Fee</Btn>
            <Btn variant="secondary" onClick={() => navigate('/dashboard/messages')}>Message Teacher</Btn>
          </div>
        </Card>
      </div>
    </div>
  );
}
