import { useState } from 'react';
import { Plus, Trash2, FileText, AlertTriangle } from 'lucide-react';
import { useCollection } from '../../hooks/useDB';
import { insert, remove, logActivity } from '../../lib/db';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../components/ui/Toast';
import { Modal } from '../../components/ui/Modal';
import { Field, Select } from '../../components/ui/Field';
import { Input } from '../../components/ui/Field';
import { FileUpload } from '../../components/ui/FileUpload';
import { PageHeader, Card, Btn, EmptyState } from '../../components/ui/Shared';
import { fmtDate } from '../../lib/utils';

export function StaffPageDocuments() {
  const documents = useCollection<any>('staffDocuments');
  const staff = useCollection<any>('staff');
  const { user } = useAuth();
  const { notify } = useToast();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<any>({ staff_id: '', doc_type: 'Contract', file_name: '', file_data: '', file_type: '', expiry_date: '' });

  const staffName = (id: string) => staff.find((s) => s.id === id)?.name || '-';
  const today = new Date().toISOString().slice(0, 10);
  const expiringSoon = (d: any) => d.expiry_date && d.expiry_date < new Date(Date.now() + 30 * 86400000).toISOString().slice(0, 10);

  const save = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.staff_id || !form.file_name) return notify('Please select staff and upload a file', 'error');
    insert('staffDocuments', { ...form, uploaded_at: new Date().toISOString() });
    logActivity(user!, `Uploaded ${form.doc_type} for ${staffName(form.staff_id)}`, 'document');
    notify('Document uploaded');
    setOpen(false);
    setForm({ staff_id: '', doc_type: 'Contract', file_name: '', file_data: '', file_type: '', expiry_date: '' });
  };

  return (
    <div>
      <PageHeader title="Staff Documents" subtitle="Manage contracts, certificates and expiry alerts"
        action={<Btn onClick={() => setOpen(true)}><span className="flex items-center gap-2"><Plus className="h-4 w-4" /> Upload Document</span></Btn>} />
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-left text-slate-600">
                <th className="pb-3 font-medium">Staff</th><th className="pb-3 font-medium">Type</th>
                <th className="pb-3 font-medium">File</th><th className="pb-3 font-medium">Uploaded</th>
                <th className="pb-3 font-medium">Expiry</th><th className="pb-3 font-medium">Action</th>
              </tr>
            </thead>
            <tbody>
              {documents.map((d) => (
                <tr key={d.id} className="border-b border-slate-100">
                  <td className="py-3 font-medium text-slate-900">{staffName(d.staff_id)}</td>
                  <td className="py-3 text-slate-600"><span className="flex items-center gap-1"><FileText className="h-4 w-4 text-slate-400" />{d.doc_type}</span></td>
                  <td className="py-3 text-slate-600">{d.file_name}</td>
                  <td className="py-3 text-slate-500">{fmtDate(d.uploaded_at)}</td>
                  <td className="py-3">
                    {d.expiry_date ? (
                      <span className={`flex items-center gap-1 ${d.expiry_date < today ? 'text-red-600' : expiringSoon(d) ? 'text-yellow-600' : 'text-slate-500'}`}>
                        {(d.expiry_date < today || expiringSoon(d)) && <AlertTriangle className="h-3 w-3" />}
                        {fmtDate(d.expiry_date)}
                      </span>
                    ) : '-'}
                  </td>
                  <td className="py-3"><button onClick={() => { remove('staffDocuments', d.id); notify('Document removed'); }} className="rounded p-1.5 text-red-600 hover:bg-red-50"><Trash2 className="h-4 w-4" /></button></td>
                </tr>
              ))}
            </tbody>
          </table>
          {documents.length === 0 && <EmptyState message="No documents uploaded" />}
        </div>
      </Card>

      <Modal open={open} onClose={() => setOpen(false)} title="Upload Document">
        <form onSubmit={save} className="space-y-4">
          <Field label="Staff" required>
            <Select value={form.staff_id} onChange={(e) => setForm({ ...form, staff_id: e.target.value })}>
              <option value="">Select staff...</option>
              {staff.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </Select>
          </Field>
          <Field label="Document Type">
            <Select value={form.doc_type} onChange={(e) => setForm({ ...form, doc_type: e.target.value })}>
              <option>Contract</option><option>Certificate</option><option>CNIC Copy</option><option>Degree</option><option>Other</option>
            </Select>
          </Field>
          <FileUpload
            label="Upload File"
            value={form.file_name ? { file_name: form.file_name, file_data: form.file_data, file_type: form.file_type } : null}
            onChange={(f) => setForm({ ...form, file_name: f?.file_name || '', file_data: f?.file_data || '', file_type: f?.file_type || '' })}
            onError={(m) => notify(m, 'error')}
          />
          <Field label="Expiry Date"><Input type="date" value={form.expiry_date} onChange={(e) => setForm({ ...form, expiry_date: e.target.value })} /></Field>
          <div className="flex justify-end gap-2 pt-2"><Btn variant="secondary" onClick={() => setOpen(false)}>Cancel</Btn><Btn type="submit">Upload</Btn></div>
        </form>
      </Modal>
    </div>
  );
}
