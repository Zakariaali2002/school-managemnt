import { useState } from 'react';
import { Upload, Download, Eye, RefreshCw, AlertTriangle, FileText } from 'lucide-react';
import { useCollection } from '../../hooks/useDB';
import { insert, update, logActivity, getSettings } from '../../lib/db';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../components/ui/Toast';
import { Modal } from '../../components/ui/Modal';
import { Field, Input } from '../../components/ui/Field';
import { PageHeader, Card, Btn, EmptyState } from '../../components/ui/Shared';
import { fmtDate } from '../../lib/utils';
import { DOC_STATUS, daysUntil } from '../../lib/documents';

export function MyDocumentsPage() {
  const { user } = useAuth();
  const categories = useCollection<any>('documentCategories').filter((c) => c.role === user?.role);
  const documents = useCollection<any>('documents').filter((d) => d.user_id === user?.id);
  const { notify } = useToast();
  const [open, setOpen] = useState(false);
  const [activeCat, setActiveCat] = useState<any>(null);
  const [form, setForm] = useState({ file_name: '', expiry_date: '', file_data: '', file_type: '' });
  const maxMb = getSettings().max_doc_size_mb || 5;

  const docFor = (catId: string) => documents.find((d) => d.category_id === catId);

  const openUpload = (cat: any, existing?: any) => {
    setActiveCat(cat);
    setForm({ file_name: existing?.file_name || '', expiry_date: existing?.expiry_date || '', file_data: '', file_type: '' });
    setOpen(true);
  };

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const at = activeCat?.allowed_types || 'all';
    const pdfTypes = ['application/pdf'];
    const imgTypes = ['image/jpeg', 'image/png', 'image/jpg'];
    const allowed = at === 'pdf' ? pdfTypes : at === 'image' ? imgTypes : [...pdfTypes, ...imgTypes];
    if (!allowed.includes(file.type)) {
      const label = at === 'pdf' ? 'PDF only' : at === 'image' ? 'JPG/PNG only' : 'PDF, JPG, PNG';
      return notify(`Allowed types: ${label}`, 'error');
    }
    if (file.size > maxMb * 1024 * 1024) return notify(`File exceeds ${maxMb}MB limit`, 'error');
    const reader = new FileReader();
    reader.onload = () => setForm((f) => ({ ...f, file_name: file.name, file_data: reader.result as string, file_type: file.type }));
    reader.readAsDataURL(file);
  };

  const save = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.file_name) return notify('Please choose a file', 'error');
    const existing = docFor(activeCat.id);
    if (existing) {
      update('documents', existing.id, { ...form, status: 'pending', uploaded_at: new Date().toISOString(), remarks: '', verified_by: '' });
      logActivity(user!, `Replaced document ${activeCat.name}`, 'document', existing.id);
      notify('Document replaced — pending review');
    } else {
      insert('documents', { user_id: user!.id, category_id: activeCat.id, ...form, status: 'pending', uploaded_at: new Date().toISOString(), verified_by: '', remarks: '' });
      logActivity(user!, `Uploaded document ${activeCat.name}`, 'document');
      notify('Document uploaded — pending review');
    }
    setOpen(false);
  };

  const viewDoc = (d: any) => {
    if (d.file_data) {
      const w = window.open();
      if (w) {
        if (d.file_type === 'application/pdf') w.document.write(`<iframe src="${d.file_data}" style="width:100%;height:100%;border:none;"></iframe>`);
        else w.document.write(`<img src="${d.file_data}" style="max-width:100%;"/>`);
      }
    } else {
      notify('Sample document (no file data stored)', 'info');
    }
  };

  const downloadDoc = (d: any) => {
    if (d.file_data) {
      const a = document.createElement('a');
      a.href = d.file_data;
      a.download = d.file_name;
      a.click();
    } else {
      notify('Sample document — no downloadable file', 'info');
    }
  };

  return (
    <div>
      <PageHeader title="My Documents" subtitle="Upload and manage your documents" />
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-left text-slate-600">
                <th className="pb-3 font-medium">Document</th>
                <th className="pb-3 font-medium">File</th>
                <th className="pb-3 font-medium">Uploaded</th>
                <th className="pb-3 font-medium">Expiry</th>
                <th className="pb-3 font-medium">Status</th>
                <th className="pb-3 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {categories.map((cat) => {
                const d = docFor(cat.id);
                const expDays = d?.expiry_date ? daysUntil(d.expiry_date) : null;
                return (
                  <tr key={cat.id} className="border-b border-slate-100">
                    <td className="py-3 font-medium text-slate-900">
                      {cat.name}
                      {cat.required && <span className="ml-1 text-red-500">*</span>}
                    </td>
                    <td className="py-3 text-slate-600">
                      {d ? <span className="flex items-center gap-1"><FileText className="h-4 w-4 text-slate-400" />{d.file_name}</span> : <span className="text-slate-400">Not uploaded</span>}
                    </td>
                    <td className="py-3 text-slate-500">{d ? fmtDate(d.uploaded_at) : '-'}</td>
                    <td className="py-3">
                      {d?.expiry_date ? (
                        <span className={expDays !== null && expDays < 0 ? 'text-red-600' : expDays !== null && expDays <= 30 ? 'text-orange-600' : 'text-slate-500'}>
                          {(expDays !== null && expDays <= 30) && <AlertTriangle className="mr-1 inline h-3 w-3" />}
                          {fmtDate(d.expiry_date)}
                        </span>
                      ) : '-'}
                    </td>
                    <td className="py-3">
                      {d ? <span className={`rounded-full px-2 py-1 text-xs font-medium ${DOC_STATUS[d.status as keyof typeof DOC_STATUS]?.color}`}>{DOC_STATUS[d.status as keyof typeof DOC_STATUS]?.dot} {DOC_STATUS[d.status as keyof typeof DOC_STATUS]?.label}</span> : <span className="rounded-full bg-slate-100 px-2 py-1 text-xs text-slate-500">Missing</span>}
                    </td>
                    <td className="py-3">
                      <div className="flex gap-1">
                        {d ? (
                          <>
                            <button onClick={() => viewDoc(d)} className="rounded p-1.5 text-blue-600 hover:bg-blue-50" title="View"><Eye className="h-4 w-4" /></button>
                            <button onClick={() => downloadDoc(d)} className="rounded p-1.5 text-green-600 hover:bg-green-50" title="Download"><Download className="h-4 w-4" /></button>
                            <button onClick={() => openUpload(cat, d)} className="rounded p-1.5 text-orange-600 hover:bg-orange-50" title="Replace"><RefreshCw className="h-4 w-4" /></button>
                          </>
                        ) : (
                          <Btn size="sm" onClick={() => openUpload(cat)}><span className="flex items-center gap-1"><Upload className="h-3 w-3" /> Upload</span></Btn>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {categories.length === 0 && <EmptyState message="No document categories defined for your role" />}
        </div>
        {d_rejected(documents) && (
          <div className="mt-4 rounded-lg bg-red-50 p-3 text-sm text-red-700">
            <AlertTriangle className="mr-1 inline h-4 w-4" /> Some documents were rejected. Please review remarks and re-upload.
          </div>
        )}
      </Card>

      <Modal open={open} onClose={() => setOpen(false)} title={`Upload: ${activeCat?.name || ''}`}>
        <form onSubmit={save} className="space-y-4">
          {activeCat && (
            <span className={`inline-block rounded px-2 py-0.5 text-xs font-medium ${activeCat.required ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'}`}>
              {activeCat.required ? '⚠️ Mandatory document' : '✓ Optional document'}
            </span>
          )}
          <Field label={`Select File (${activeCat?.allowed_types === 'pdf' ? 'PDF only' : activeCat?.allowed_types === 'image' ? 'JPG / PNG' : 'PDF / JPG / PNG'})`} required>
            <input type="file"
              accept={activeCat?.allowed_types === 'pdf' ? '.pdf' : activeCat?.allowed_types === 'image' ? '.jpg,.jpeg,.png' : '.pdf,.jpg,.jpeg,.png'}
              onChange={handleFile}
              className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm file:mr-3 file:rounded file:border-0 file:bg-blue-50 file:px-3 file:py-1 file:text-blue-700" />
            {form.file_name && <p className="mt-1 text-xs text-green-600">Selected: {form.file_name}</p>}
          </Field>
          {activeCat?.has_expiry && (
            <Field label="Expiry Date" required>
              <Input type="date" value={form.expiry_date} onChange={(e) => setForm({ ...form, expiry_date: e.target.value })} />
            </Field>
          )}
          <p className="text-xs text-slate-400">Max size: {maxMb}MB. Document will be marked "Pending Review" until verified.</p>
          <div className="flex justify-end gap-2 pt-2">
            <Btn variant="secondary" onClick={() => setOpen(false)}>Cancel</Btn>
            <Btn type="submit">Upload</Btn>
          </div>
        </form>
      </Modal>
    </div>
  );
}

function d_rejected(docs: any[]) {
  return docs.some((d) => d.status === 'rejected');
}
