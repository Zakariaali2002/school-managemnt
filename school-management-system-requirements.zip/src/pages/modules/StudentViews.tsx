import { useCollection } from '../../hooks/useDB';
import { getAll } from '../../lib/db';
import { useAuth } from '../../contexts/AuthContext';
import { PageHeader, Card, Btn, EmptyState } from '../../components/ui/Shared';
import { StatusBadge, money, fmtDate, calcGrade, printDocument } from '../../lib/utils';
import { useMyStudent } from '../Dashboards';

export function ResultsPage() {
  const student = useMyStudent();
  const marks = useCollection<any>('marks').filter((m) => m.student_id === student?.id);
  const subjects = useCollection<any>('subjects');
  const exams = useCollection<any>('exams');

  const subName = (id: string) => subjects.find((s) => s.id === id)?.name || '-';
  const examName = (id: string) => exams.find((e) => e.id === id)?.name || '-';

  const total = marks.reduce((a, m) => a + m.marks_obtained, 0);
  const max = marks.reduce((a, m) => a + m.total_marks, 0) || 1;
  const overall = ((total / max) * 100).toFixed(1);

  const download = () => {
    const rows = marks.map((m) => `<tr><td>${examName(m.exam_id)}</td><td>${subName(m.subject_id)}</td><td>${m.marks_obtained}/${m.total_marks}</td><td>${m.grade}</td></tr>`).join('');
    printDocument(`Result Card - ${student.name}`, `
      <div class="title">Result Card - ${student.name}</div>
      <table><thead><tr><th>Exam</th><th>Subject</th><th>Marks</th><th>Grade</th></tr></thead><tbody>${rows}</tbody></table>
      <div class="row"><span class="label">Overall</span><span class="value">${overall}% (${calcGrade(Number(overall))})</span></div>
    `);
  };

  return (
    <div>
      <PageHeader title="My Results" subtitle={`Overall: ${overall}% (Grade ${calcGrade(Number(overall))})`}
        action={marks.length > 0 && <Btn onClick={download}>Download Result Card</Btn>} />
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-left text-slate-600">
                <th className="pb-3 font-medium">Exam</th><th className="pb-3 font-medium">Subject</th>
                <th className="pb-3 font-medium">Marks</th><th className="pb-3 font-medium">Percentage</th><th className="pb-3 font-medium">Grade</th>
              </tr>
            </thead>
            <tbody>
              {marks.map((m) => (
                <tr key={m.id} className="border-b border-slate-100">
                  <td className="py-3 text-slate-600">{examName(m.exam_id)}</td>
                  <td className="py-3 font-medium text-slate-900">{subName(m.subject_id)}</td>
                  <td className="py-3 text-slate-600">{m.marks_obtained}/{m.total_marks}</td>
                  <td className="py-3 text-slate-600">{((m.marks_obtained / m.total_marks) * 100).toFixed(0)}%</td>
                  <td className="py-3"><span className="rounded-full bg-blue-100 px-2 py-1 text-xs font-medium text-blue-700">{m.grade}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
          {marks.length === 0 && <EmptyState message="No results recorded yet" />}
        </div>
      </Card>
    </div>
  );
}

export function StudentFeePage() {
  const student = useMyStudent();
  const vouchers = useCollection<any>('feeVouchers').filter((v) => v.student_id === student?.id);

  const download = (v: any) => {
    printDocument(`Fee Voucher - ${v.voucher_no}`, `
      <div class="title">Fee Voucher</div>
      <div class="row"><span class="label">Voucher</span><span class="value">${v.voucher_no}</span></div>
      <div class="row"><span class="label">Student</span><span class="value">${student.name}</span></div>
      <div class="row"><span class="label">Period</span><span class="value">${v.month}/${v.year}</span></div>
      <div class="row"><span class="label">Amount</span><span class="value">${money(v.amount)}</span></div>
      <div class="row"><span class="label">Due Date</span><span class="value">${fmtDate(v.due_date)}</span></div>
      <div class="row"><span class="label">Status</span><span class="value">${v.status.toUpperCase()}</span></div>
    `);
  };

  return (
    <div>
      <PageHeader title="Fee Status" subtitle="Your fee vouchers and history" />
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-left text-slate-600">
                <th className="pb-3 font-medium">Voucher</th><th className="pb-3 font-medium">Period</th>
                <th className="pb-3 font-medium">Amount</th><th className="pb-3 font-medium">Due</th>
                <th className="pb-3 font-medium">Status</th><th className="pb-3 font-medium">Action</th>
              </tr>
            </thead>
            <tbody>
              {vouchers.map((v) => (
                <tr key={v.id} className="border-b border-slate-100">
                  <td className="py-3 text-slate-600">{v.voucher_no}</td>
                  <td className="py-3 text-slate-600">{v.month}/{v.year}</td>
                  <td className="py-3 text-slate-600">{money(v.amount)}</td>
                  <td className="py-3 text-slate-500">{fmtDate(v.due_date)}</td>
                  <td className="py-3"><StatusBadge status={v.status} /></td>
                  <td className="py-3"><Btn size="sm" variant="secondary" onClick={() => download(v)}>Download</Btn></td>
                </tr>
              ))}
            </tbody>
          </table>
          {vouchers.length === 0 && <EmptyState message="No fee vouchers" />}
        </div>
      </Card>
    </div>
  );
}

// ---------- PARENT PROGRESS ----------
export function ParentProgressPage() {
  const { user } = useAuth();
  const children = useCollection<any>('students').filter((s) => s.guardian_id === user?.id);
  const marksAll = useCollection<any>('marks');
  const subjects = useCollection<any>('subjects');
  const classes = useCollection<any>('classes');
  const subName = (id: string) => subjects.find((s) => s.id === id)?.name || '-';

  return (
    <div>
      <PageHeader title="Child Progress" subtitle="Academic performance overview" />
      {children.map((child) => {
        const marks = marksAll.filter((m) => m.student_id === child.id);
        return (
          <Card key={child.id} title={`${child.name} · ${classes.find((c) => c.id === child.class_id)?.name || ''}`}>
            <div className="space-y-3">
              {marks.map((m) => {
                const pct = (m.marks_obtained / m.total_marks) * 100;
                return (
                  <div key={m.id}>
                    <div className="mb-1 flex justify-between text-sm">
                      <span className="font-medium text-slate-700">{subName(m.subject_id)}</span>
                      <span className="text-slate-600">{m.marks_obtained}/{m.total_marks} · {m.grade}</span>
                    </div>
                    <div className="h-2 w-full rounded-full bg-slate-200">
                      <div className="h-2 rounded-full bg-blue-600" style={{ width: `${pct}%` }} />
                    </div>
                  </div>
                );
              })}
              {marks.length === 0 && <EmptyState message="No results recorded" />}
            </div>
          </Card>
        );
      })}
      {children.length === 0 && <Card><EmptyState message="No children linked to your account" /></Card>}
    </div>
  );
}

// ---------- PARENT/STUDENT ATTENDANCE & FEE WRAPPERS ----------
export function ParentAttendancePage() {
  const { user } = useAuth();
  const children = getAll('students').filter((s: any) => s.guardian_id === user?.id);
  const records = useCollection<any>('studentAttendance');
  const classes = useCollection<any>('classes');

  return (
    <div>
      <PageHeader title="Children's Attendance" subtitle="Monitor each child's attendance record" />
      <div className="grid gap-6">
        {children.map((child: any) => {
          const recs = records.filter((r) => r.student_id === child.id);
          const present = recs.filter((r) => r.status === 'present' || r.status === 'late').length;
          const absent = recs.filter((r) => r.status === 'absent').length;
          const leave = recs.filter((r) => r.status === 'leave').length;
          const pct = recs.length ? Math.round((present / recs.length) * 100) : 0;
          const cls = classes.find((c) => c.id === child.class_id);
          return (
            <div key={child.id} className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
              {/* child header */}
              <div className="flex items-center gap-3 border-b border-slate-100 bg-gradient-to-r from-indigo-50 to-violet-50 p-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-indigo-500 to-violet-500 text-lg font-bold text-white">
                  {child.name.charAt(0)}
                </div>
                <div>
                  <p className="font-semibold text-slate-900">{child.name}</p>
                  <p className="text-sm text-slate-500">{cls?.name || ''}{child.section ? ' - ' + child.section : ''} · Roll {child.roll_no}</p>
                </div>
              </div>

              <div className="grid gap-4 p-5 md:grid-cols-3">
                {/* donut */}
                <div className="flex items-center gap-4">
                  <div className="relative h-24 w-24 shrink-0">
                    <svg className="h-full w-full -rotate-90">
                      <circle cx="48" cy="48" r="38" stroke="#eef2ff" strokeWidth="11" fill="none" />
                      <circle cx="48" cy="48" r="38" stroke="#6366f1" strokeWidth="11" strokeLinecap="round" fill="none"
                        strokeDasharray={238.7} strokeDashoffset={238.7 - (238.7 * pct) / 100} />
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center text-xl font-bold text-slate-900">{pct}%</div>
                  </div>
                  <div className="space-y-1 text-sm">
                    <p className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-full bg-emerald-500" /> Present <b className="ml-1">{present}</b></p>
                    <p className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-full bg-rose-500" /> Absent <b className="ml-1">{absent}</b></p>
                    <p className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-full bg-sky-500" /> Leave <b className="ml-1">{leave}</b></p>
                  </div>
                </div>

                {/* recent */}
                <div className="md:col-span-2">
                  <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-400">Recent</p>
                  <div className="grid max-h-40 grid-cols-1 gap-1.5 overflow-y-auto sm:grid-cols-2">
                    {recs.slice(-8).reverse().map((r) => (
                      <div key={r.id} className="flex items-center justify-between rounded-lg bg-slate-50 px-3 py-1.5 text-sm">
                        <span className="text-slate-700">{fmtDate(r.date)}</span><StatusBadge status={r.status} />
                      </div>
                    ))}
                    {recs.length === 0 && <p className="text-sm text-slate-400">No records yet</p>}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
        {children.length === 0 && <Card><EmptyState message="No children linked" /></Card>}
      </div>
    </div>
  );
}

export function ParentFeePage() {
  const { user } = useAuth();
  const children = getAll('students').filter((s: any) => s.guardian_id === user?.id);
  const vouchers = useCollection<any>('feeVouchers');

  const download = (v: any, name: string) => {
    printDocument(`Fee Voucher - ${v.voucher_no}`, `
      <div class="title">Fee Voucher</div>
      <div class="row"><span class="label">Student</span><span class="value">${name}</span></div>
      <div class="row"><span class="label">Voucher</span><span class="value">${v.voucher_no}</span></div>
      <div class="row"><span class="label">Amount</span><span class="value">${money(v.amount)}</span></div>
      <div class="row"><span class="label">Status</span><span class="value">${v.status.toUpperCase()}</span></div>
    `);
  };

  return (
    <div>
      <PageHeader title="Fee" subtitle="Children's fee vouchers" />
      {children.map((child: any) => {
        const vs = vouchers.filter((v) => v.student_id === child.id);
        return (
          <Card key={child.id} title={child.name}>
            <div className="space-y-2">
              {vs.map((v) => (
                <div key={v.id} className="flex items-center justify-between rounded-lg bg-slate-50 px-3 py-2 text-sm">
                  <span className="text-slate-700">{v.voucher_no} · {money(v.amount)}</span>
                  <div className="flex items-center gap-2"><StatusBadge status={v.status} /><Btn size="sm" variant="secondary" onClick={() => download(v, child.name)}>Download</Btn></div>
                </div>
              ))}
              {vs.length === 0 && <EmptyState message="No vouchers" />}
            </div>
          </Card>
        );
      })}
      {children.length === 0 && <Card><EmptyState message="No children linked" /></Card>}
    </div>
  );
}
