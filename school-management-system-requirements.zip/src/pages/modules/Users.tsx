import { useState } from 'react';
import { Plus, Pencil, Power } from 'lucide-react';
import { useCollection } from '../../hooks/useDB';
import { insert, update, logActivity } from '../../lib/db';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../components/ui/Toast';
import { useConfirm } from '../../components/ui/Confirm';
import { Modal } from '../../components/ui/Modal';
import { Field, Input, Select } from '../../components/ui/Field';
import { PageHeader, Card, Btn, EmptyState } from '../../components/ui/Shared';
import { StatusBadge, fmtDate } from '../../lib/utils';

const roles = ['super_admin', 'principal', 'hr', 'accounts', 'teacher', 'student', 'parent'];

export function UsersPage() {
  const users = useCollection<any>('users');
  const { user } = useAuth();
  const { notify } = useToast();
  const confirm = useConfirm();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [filter, setFilter] = useState('all');
  const [form, setForm] = useState({ name: '', email: '', password: '', role: 'teacher', phone: '' });

  const openNew = () => {
    setEditing(null);
    setForm({ name: '', email: '', password: 'admin123', role: 'teacher', phone: '' });
    setOpen(true);
  };
  const openEdit = (u: any) => {
    setEditing(u);
    setForm({ name: u.name, email: u.email, password: u.password, role: u.role, phone: u.phone || '' });
    setOpen(true);
  };

  const save = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.email) return notify('Name and email are required', 'error');
    const dupe = users.find((u) => u.email.toLowerCase() === form.email.toLowerCase() && u.id !== editing?.id);
    if (dupe) return notify('Email already in use', 'error');
    if (editing) {
      update('users', editing.id, form);
      logActivity(user!, `Updated user ${form.name}`, 'user', editing.id);
      notify('User updated');
    } else {
      const created = insert('users', { ...form, is_active: true });
      logActivity(user!, `Created user ${form.name}`, 'user', created.id);
      notify('User created');
    }
    setOpen(false);
  };

  const toggleActive = async (u: any) => {
    const ok = await confirm({
      message: `${u.is_active ? 'Deactivate' : 'Activate'} ${u.name}?`,
      danger: u.is_active,
      confirmText: u.is_active ? 'Deactivate' : 'Activate',
    });
    if (!ok) return;
    update('users', u.id, { is_active: !u.is_active });
    logActivity(user!, `${u.is_active ? 'Deactivated' : 'Activated'} user ${u.name}`, 'user', u.id);
    notify('User status updated');
  };

  const filtered = filter === 'all' ? users : users.filter((u) => u.role === filter);

  return (
    <div>
      <PageHeader
        title="User Management"
        subtitle="Create accounts and manage roles"
        action={
          <Btn onClick={openNew}>
            <span className="flex items-center gap-2"><Plus className="h-4 w-4" /> Add User</span>
          </Btn>
        }
      />

      <Card>
        <div className="mb-4 flex flex-wrap gap-2">
          {['all', ...roles].map((r) => (
            <button
              key={r}
              onClick={() => setFilter(r)}
              className={`rounded-full px-3 py-1 text-xs font-medium capitalize ${
                filter === r ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {r.replace('_', ' ')}
            </button>
          ))}
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-left text-slate-600">
                <th className="pb-3 font-medium">Name</th>
                <th className="pb-3 font-medium">Email</th>
                <th className="pb-3 font-medium">Role</th>
                <th className="pb-3 font-medium">Phone</th>
                <th className="pb-3 font-medium">Status</th>
                <th className="pb-3 font-medium">Created</th>
                <th className="pb-3 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((u) => (
                <tr key={u.id} className="border-b border-slate-100">
                  <td className="py-3 font-medium text-slate-900">{u.name}</td>
                  <td className="py-3 text-slate-600">{u.email}</td>
                  <td className="py-3 capitalize text-slate-600">{u.role.replace('_', ' ')}</td>
                  <td className="py-3 text-slate-600">{u.phone || '-'}</td>
                  <td className="py-3"><StatusBadge status={u.is_active ? 'active' : 'inactive'} /></td>
                  <td className="py-3 text-slate-500">{fmtDate(u.created_at)}</td>
                  <td className="py-3">
                    <div className="flex gap-1">
                      <button onClick={() => openEdit(u)} className="rounded p-1.5 text-blue-600 hover:bg-blue-50" title="Edit">
                        <Pencil className="h-4 w-4" />
                      </button>
                      {u.id !== user?.id && (
                        <button onClick={() => toggleActive(u)} className="rounded p-1.5 text-red-600 hover:bg-red-50" title="Toggle active">
                          <Power className="h-4 w-4" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filtered.length === 0 && <EmptyState message="No users found" />}
        </div>
      </Card>

      <Modal open={open} onClose={() => setOpen(false)} title={editing ? 'Edit User' : 'Add User'}>
        <form onSubmit={save} className="space-y-4">
          <Field label="Full Name" required>
            <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          </Field>
          <Field label="Email" required>
            <Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          </Field>
          <Field label="Password" required>
            <Input value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
          </Field>
          <Field label="Role" required>
            <Select value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })}>
              {roles.map((r) => (
                <option key={r} value={r}>{r.replace('_', ' ')}</option>
              ))}
            </Select>
          </Field>
          <Field label="Phone">
            <Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
          </Field>
          <div className="flex justify-end gap-2 pt-2">
            <Btn variant="secondary" onClick={() => setOpen(false)}>Cancel</Btn>
            <Btn type="submit">{editing ? 'Update' : 'Create'}</Btn>
          </div>
        </form>
      </Modal>
    </div>
  );
}
