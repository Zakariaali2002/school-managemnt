import { useState } from 'react';
import { Search, UserPlus } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useCollection } from '../../hooks/useDB';
import { PageHeader, Card, Btn, EmptyState, StatCard } from '../../components/ui/Shared';
import { fmtDate } from '../../lib/utils';
import { Users2, GraduationCap, UserCog } from 'lucide-react';

// ---------------- TEACHERS (staff filtered to teaching roles) ----------------
export function TeachersPage() {
  const staff = useCollection<any>('staff');
  const [search, setSearch] = useState('');
  const teachers = staff.filter((s) =>
    /teacher|faculty|lecturer/i.test(s.designation || '') &&
    (!search || s.name.toLowerCase().includes(search.toLowerCase())),
  );
  // fallback: if none match, show all staff in academic departments
  const list = teachers.length ? teachers : staff.filter((s) => !search || s.name.toLowerCase().includes(search.toLowerCase()));

  return (
    <div>
      <PageHeader title="Teachers" subtitle="Teaching faculty directory" />
      <div className="mb-6"><StatCard title="Total Teachers" value={list.length} icon={UserCog} color="from-indigo-500 to-indigo-600" /></div>
      <Card>
        <div className="relative mb-4 max-w-xs">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search teacher..."
            className="w-full rounded-md border border-slate-300 py-2 pl-9 pr-3 text-sm focus:border-indigo-500 focus:outline-none" />
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="border-b border-slate-200 text-left text-slate-600">
              <th className="pb-3 font-medium">Code</th><th className="pb-3 font-medium">Name</th>
              <th className="pb-3 font-medium">Designation</th><th className="pb-3 font-medium">Department</th>
              <th className="pb-3 font-medium">Joined</th>
            </tr></thead>
            <tbody>
              {list.map((t) => (
                <tr key={t.id} className="border-b border-slate-100">
                  <td className="py-3 text-slate-600">{t.employee_code}</td>
                  <td className="py-3 font-medium text-slate-900">{t.name}</td>
                  <td className="py-3 text-slate-600">{t.designation}</td>
                  <td className="py-3 text-slate-600">{t.department || '-'}</td>
                  <td className="py-3 text-slate-500">{fmtDate(t.join_date)}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {list.length === 0 && <EmptyState message="No teachers found" />}
        </div>
      </Card>
    </div>
  );
}

// ---------------- PARENTS (users with role parent + their children) ----------------
export function ParentsPage() {
  const users = useCollection<any>('users');
  const students = useCollection<any>('students');
  const [search, setSearch] = useState('');
  const parents = users.filter((u) => u.role === 'parent' && (!search || u.name.toLowerCase().includes(search.toLowerCase())));

  const childrenOf = (parentId: string) =>
    students.filter((s) => s.guardian_id === parentId).map((s) => s.name).join(', ') || '-';

  return (
    <div>
      <PageHeader title="Parents" subtitle="Registered parents and their children" />
      <div className="mb-6"><StatCard title="Total Parents" value={parents.length} icon={Users2} color="from-violet-500 to-violet-600" /></div>
      <Card>
        <div className="relative mb-4 max-w-xs">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search parent..."
            className="w-full rounded-md border border-slate-300 py-2 pl-9 pr-3 text-sm focus:border-indigo-500 focus:outline-none" />
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="border-b border-slate-200 text-left text-slate-600">
              <th className="pb-3 font-medium">Name</th><th className="pb-3 font-medium">Email</th>
              <th className="pb-3 font-medium">Phone</th><th className="pb-3 font-medium">Children</th>
            </tr></thead>
            <tbody>
              {parents.map((p) => (
                <tr key={p.id} className="border-b border-slate-100">
                  <td className="py-3 font-medium text-slate-900">{p.name}</td>
                  <td className="py-3 text-slate-600">{p.email}</td>
                  <td className="py-3 text-slate-600">{p.phone || '-'}</td>
                  <td className="py-3 text-slate-600">{childrenOf(p.id)}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {parents.length === 0 && <EmptyState message="No parents registered" />}
        </div>
      </Card>
    </div>
  );
}

// ---------------- RESULTS (admin/principal overview) ----------------
export function ResultsAdminPage() {
  const marks = useCollection<any>('marks');
  const students = useCollection<any>('students');
  const subjects = useCollection<any>('subjects');
  const exams = useCollection<any>('exams');
  const [examId, setExamId] = useState('all');

  const studentName = (id: string) => students.find((s) => s.id === id)?.name || '-';
  const subName = (id: string) => subjects.find((s) => s.id === id)?.name || '-';
  const examName = (id: string) => exams.find((e) => e.id === id)?.name || '-';
  const filtered = examId === 'all' ? marks : marks.filter((m) => m.exam_id === examId);

  return (
    <div>
      <PageHeader title="Results" subtitle="Examination results overview" />
      <Card>
        <div className="mb-4 max-w-xs">
          <select value={examId} onChange={(e) => setExamId(e.target.value)} className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm">
            <option value="all">All Exams</option>
            {exams.map((e) => <option key={e.id} value={e.id}>{e.name}</option>)}
          </select>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="border-b border-slate-200 text-left text-slate-600">
              <th className="pb-3 font-medium">Student</th><th className="pb-3 font-medium">Exam</th>
              <th className="pb-3 font-medium">Subject</th><th className="pb-3 font-medium">Marks</th>
              <th className="pb-3 font-medium">Grade</th>
            </tr></thead>
            <tbody>
              {filtered.map((m) => (
                <tr key={m.id} className="border-b border-slate-100">
                  <td className="py-3 font-medium text-slate-900">{studentName(m.student_id)}</td>
                  <td className="py-3 text-slate-600">{examName(m.exam_id)}</td>
                  <td className="py-3 text-slate-600">{subName(m.subject_id)}</td>
                  <td className="py-3 text-slate-600">{m.marks_obtained}{m.total_marks ? `/${m.total_marks}` : ''}</td>
                  <td className="py-3"><span className="rounded-full bg-indigo-100 px-2 py-0.5 text-xs font-medium text-indigo-700">{m.grade || '-'}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
          {filtered.length === 0 && <EmptyState message="No results recorded yet" />}
        </div>
      </Card>
    </div>
  );
}

// ---------------- ADMISSIONS (recent admissions + quick link) ----------------
export function AdmissionsPage() {
  const students = useCollection<any>('students');
  const classes = useCollection<any>('classes');
  const navigate = useNavigate();
  const className = (id: string) => classes.find((c) => c.id === id)?.name || '-';
  const recent = students.slice().sort((a, b) => (b.admission_date || '').localeCompare(a.admission_date || '')).slice(0, 15);
  const thisYear = new Date().getFullYear();
  const thisYearCount = students.filter((s) => (s.admission_date || '').startsWith(String(thisYear))).length;

  return (
    <div>
      <PageHeader title="Admissions" subtitle="New student admissions"
        action={<Btn onClick={() => navigate('/dashboard/students')}><span className="flex items-center gap-2"><UserPlus className="h-4 w-4" /> New Admission</span></Btn>} />
      <div className="mb-6 grid gap-4 sm:grid-cols-2">
        <StatCard title="Total Students" value={students.length} icon={GraduationCap} color="from-blue-500 to-blue-600" onClick={() => navigate('/dashboard/students')} />
        <StatCard title={`Admitted in ${thisYear}`} value={thisYearCount} icon={UserPlus} color="from-emerald-500 to-emerald-600" />
      </div>
      <Card title="Recent Admissions">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="border-b border-slate-200 text-left text-slate-600">
              <th className="pb-3 font-medium">Code</th><th className="pb-3 font-medium">Name</th>
              <th className="pb-3 font-medium">Class</th><th className="pb-3 font-medium">Admission Date</th>
            </tr></thead>
            <tbody>
              {recent.map((s) => (
                <tr key={s.id} className="cursor-pointer border-b border-slate-100 hover:bg-slate-50" onClick={() => navigate('/dashboard/students')}>
                  <td className="py-3 text-slate-600">{s.student_code}</td>
                  <td className="py-3 font-medium text-slate-900">{s.name}</td>
                  <td className="py-3 text-slate-600">{className(s.class_id)} - {s.section}</td>
                  <td className="py-3 text-slate-500">{fmtDate(s.admission_date)}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {recent.length === 0 && <EmptyState message="No admissions yet" />}
        </div>
      </Card>
    </div>
  );
}
