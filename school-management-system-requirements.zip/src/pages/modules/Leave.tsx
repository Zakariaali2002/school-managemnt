import { useState } from 'react';
import { Plus, Check, X } from 'lucide-react';
import { useCollection } from '../../hooks/useDB';
import { insert, update, logActivity, getAll } from '../../lib/db';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../components/ui/Toast';
import { Modal } from '../../components/ui/Modal';
import { Field, Input, Select, Textarea } from '../../components/ui/Field';
import { PageHeader, Card, Btn, EmptyState } from '../../components/ui/Shared';
import { StatusBadge, fmtDate } from '../../lib/utils';

const LEAVE_TYPES = ['Annual Leave', 'Sick Leave', 'Casual Leave', 'Emergency Leave'];

// canReview = HR/Principal can approve/reject. ownStaffId set for teacher applying.
export function LeavePage({ canReview = false, ownStaffId = '' }: { canReview?: boolean; ownStaffId?: string }) {
  const leaves = useCollection<any>('leaveRequests');
  const { user } = useAuth();
  const { notify } = useToast();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ leave_type: 'Sick Leave', from_date: '', to_date: '', reason: '' });

  const myStaff = getAll('staff').find((s: any) => s.user_id === user?.id);
  const staffId = ownStaffId || myStaff?.id;

  const apply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.from_date || !form.to_date) return notify('Select dates', 'error');
    insert('leaveRequests', { staff_id: staffId, staff_name: user!.name, ...form, status: 'pending', reviewed_by: '' });
    logActivity(user!, `Applied for ${form.leave_type}`, 'leave');
    notify('Leave request submitted');
    setOpen(false);
    setForm({ leave_type: 'Sick Leave', from_date: '', to_date: '', reason: '' });
  };

  const review = (lr: any, status: 'approved' | 'rejected') => {
    update('leaveRequests', lr.id, { status, reviewed_by: user!.id });
    logActivity(user!, `${status === 'approved' ? 'Approved' : 'Rejected'} leave for ${lr.staff_name}`, 'leave', lr.id);
    notify(`Leave ${status}`);
  };

  const list = canReview ? leaves : leaves.filter((l) => l.staff_id === staffId);

  return (
    <div>
      <PageHeader title="Leave Requests" subtitle={canReview ? 'Review and approve staff leave' : 'Apply and track your leave'}
        action={!canReview && <Btn onClick={() => setOpen(true)}><span className="flex items-center gap-2"><Plus className="h-4 w-4" /> Apply Leave</span></Btn>} />
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-left text-slate-600">
                <th className="pb-3 font-medium">Staff</th><th className="pb-3 font-medium">Type</th>
                <th className="pb-3 font-medium">From</th><th className="pb-3 font-medium">To</th>
                <th className="pb-3 font-medium">Reason</th><th className="pb-3 font-medium">Status</th>
                {canReview && <th className="pb-3 font-medium">Actions</th>}
              </tr>
            </thead>
            <tbody>
              {list.slice().reverse().map((lr) => (
                <tr key={lr.id} className="border-b border-slate-100">
                  <td className="py-3 font-medium text-slate-900">{lr.staff_name}</td>
                  <td className="py-3 text-slate-600">{lr.leave_type}</td>
                  <td className="py-3 text-slate-500">{fmtDate(lr.from_date)}</td>
                  <td className="py-3 text-slate-500">{fmtDate(lr.to_date)}</td>
                  <td className="py-3 text-slate-600">{lr.reason}</td>
                  <td className="py-3"><StatusBadge status={lr.status} /></td>
                  {canReview && (
                    <td className="py-3">
                      {lr.status === 'pending' ? (
                        <div className="flex gap-1">
                          <button onClick={() => review(lr, 'approved')} className="rounded bg-green-100 p-1.5 text-green-700 hover:bg-green-200" title="Approve"><Check className="h-4 w-4" /></button>
                          <button onClick={() => review(lr, 'rejected')} className="rounded bg-red-100 p-1.5 text-red-700 hover:bg-red-200" title="Reject"><X className="h-4 w-4" /></button>
                        </div>
                      ) : <span className="text-xs text-slate-400">Reviewed</span>}
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
          {list.length === 0 && <EmptyState message="No leave requests" />}
        </div>
      </Card>

      <Modal open={open} onClose={() => setOpen(false)} title="Apply for Leave">
        <form onSubmit={apply} className="space-y-4">
          <Field label="Leave Type"><Select value={form.leave_type} onChange={(e) => setForm({ ...form, leave_type: e.target.value })}>{LEAVE_TYPES.map((t) => <option key={t}>{t}</option>)}</Select></Field>
          <div className="grid grid-cols-2 gap-4">
            <Field label="From Date" required><Input type="date" value={form.from_date} onChange={(e) => setForm({ ...form, from_date: e.target.value })} /></Field>
            <Field label="To Date" required><Input type="date" value={form.to_date} onChange={(e) => setForm({ ...form, to_date: e.target.value })} /></Field>
          </div>
          <Field label="Reason"><Textarea rows={3} value={form.reason} onChange={(e) => setForm({ ...form, reason: e.target.value })} /></Field>
          <div className="flex justify-end gap-2 pt-2"><Btn variant="secondary" onClick={() => setOpen(false)}>Cancel</Btn><Btn type="submit">Submit</Btn></div>
        </form>
      </Modal>
    </div>
  );
}
