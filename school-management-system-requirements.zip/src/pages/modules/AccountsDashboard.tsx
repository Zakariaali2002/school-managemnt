import { useNavigate } from 'react-router-dom';
import { useCollection } from '../../hooks/useDB';
import { getSettings } from '../../lib/db';
import { PageHeader, Card, Btn, EmptyState } from '../../components/ui/Shared';
import { DonutChart, BarChart, BreakdownBars, IncomeExpenseChart } from '../../components/ui/Charts';
import { money, fmtDate } from '../../lib/utils';
import { Target, TrendingDown, AlertTriangle, UserCheck, UserX } from 'lucide-react';

export function AccountsDashboard() {
  const navigate = useNavigate();
  const vouchers = useCollection<any>('feeVouchers');
  const payments = useCollection<any>('feePayments');
  const expenses = useCollection<any>('expenses');
  const students = useCollection<any>('students');
  const settings = getSettings();

  const target = settings.monthly_target || 2000000;
  const collected = payments.reduce((a, p) => a + (p.amount_paid || 0), 0);
  const totalExpense = expenses.reduce((a, e) => a + (e.amount || 0), 0);
  const outstanding = vouchers.filter((v) => v.status !== 'paid').reduce((a, v) => a + v.amount, 0);

  const paidStudentIds = new Set(
    payments.map((p) => vouchers.find((v) => v.id === p.voucher_id)?.student_id).filter(Boolean),
  );
  const studentsPaid = paidStudentIds.size;
  const studentsUnpaid = students.length - studentsPaid;

  const studentName = (id: string) => students.find((s) => s.id === id)?.name || '-';

  // Today / week collection
  const today = new Date().toISOString().slice(0, 10);
  const weekAgo = new Date(Date.now() - 7 * 86400000).toISOString().slice(0, 10);
  const dailyCollection = payments.filter((p) => (p.paid_at || '').slice(0, 10) === today).reduce((a, p) => a + p.amount_paid, 0);
  const weeklyCollection = payments.filter((p) => (p.paid_at || '') >= weekAgo).reduce((a, p) => a + p.amount_paid, 0);

  // Monthly trend (last 6 months) from payments + vouchers
  const monthLabels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const now = new Date();
  const trend: { label: string; income: number; expense: number }[] = [];
  for (let i = 5; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const m = d.getMonth();
    const y = d.getFullYear();
    const inc = payments.filter((p) => {
      const pd = new Date(p.paid_at || p.created_at);
      return pd.getMonth() === m && pd.getFullYear() === y;
    }).reduce((a, p) => a + p.amount_paid, 0);
    const exp = expenses.filter((e) => {
      const ed = new Date(e.date || e.created_at);
      return ed.getMonth() === m && ed.getFullYear() === y;
    }).reduce((a, e) => a + e.amount, 0);
    trend.push({ label: monthLabels[m], income: inc, expense: exp });
  }

  // Expense breakdown by category
  const catMap: Record<string, number> = {};
  expenses.forEach((e) => { catMap[e.category] = (catMap[e.category] || 0) + e.amount; });
  const expenseBreakdown = Object.entries(catMap).map(([label, value]) => ({ label, value })).sort((a, b) => b.value - a.value);

  // Top defaulters
  const defaulters = vouchers.filter((v) => v.status === 'overdue').sort((a, b) => b.amount - a.amount).slice(0, 5);
  // Upcoming due
  const upcoming = vouchers.filter((v) => v.status === 'unpaid' && v.due_date >= today).sort((a, b) => a.due_date.localeCompare(b.due_date)).slice(0, 5);

  return (
    <div>
      <PageHeader title="Accounts Dashboard" subtitle="Financial overview & KPIs"
        action={<div className="flex flex-wrap gap-2">
          <Btn variant="secondary" onClick={() => navigate('/dashboard/payments')}>Collect Fee</Btn>
          <Btn onClick={() => navigate('/dashboard/reports')}>Reports</Btn>
        </div>} />

      {/* Circular KPI cards (clickable) */}
      <div className="mb-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
        <KpiCard onClick={() => navigate('/dashboard/fee-structure')}>
          <DonutChart value={target} max={target} color="#0891b2"
            centerText={<><Target className="mb-1 h-5 w-5 text-cyan-600" /><span className="text-sm font-bold text-slate-900">{abbrMoney(target)}</span></>} />
          <p className="mt-2 text-center text-xs font-medium text-slate-600">🎯 Monthly Target</p>
        </KpiCard>
        <KpiCard onClick={() => navigate('/dashboard/income')}>
          <DonutChart value={collected} max={target} color="#16a34a"
            centerText={<><span className="text-xl font-bold text-green-600">{target ? Math.round((collected / target) * 100) : 0}%</span><span className="text-[10px] text-slate-500">{abbrMoney(collected)}</span></>} />
          <p className="mt-2 text-center text-xs font-medium text-slate-600">💰 Collection Received</p>
        </KpiCard>
        <KpiCard onClick={() => navigate('/dashboard/expenses')}>
          <DonutChart value={totalExpense} max={Math.max(target, totalExpense)} color="#dc2626"
            centerText={<><TrendingDown className="mb-1 h-5 w-5 text-red-600" /><span className="text-sm font-bold text-slate-900">{abbrMoney(totalExpense)}</span></>} />
          <p className="mt-2 text-center text-xs font-medium text-slate-600">📉 Total Expenses</p>
        </KpiCard>
        <KpiCard onClick={() => navigate('/dashboard/outstanding')}>
          <DonutChart value={outstanding} max={Math.max(target, outstanding)} color="#ea580c"
            centerText={<><AlertTriangle className="mb-1 h-5 w-5 text-orange-600" /><span className="text-sm font-bold text-slate-900">{abbrMoney(outstanding)}</span></>} />
          <p className="mt-2 text-center text-xs font-medium text-slate-600">⚠️ Outstanding Dues</p>
        </KpiCard>
        <KpiCard onClick={() => navigate('/dashboard/payments')}>
          <DonutChart value={studentsPaid} max={students.length || 1} color="#2563eb"
            centerText={<><UserCheck className="mb-1 h-5 w-5 text-blue-600" /><span className="text-lg font-bold text-slate-900">{studentsPaid}</span></>} />
          <p className="mt-2 text-center text-xs font-medium text-slate-600">👨‍🎓 Students Paid</p>
        </KpiCard>
        <KpiCard onClick={() => navigate('/dashboard/defaulters')}>
          <DonutChart value={studentsUnpaid} max={students.length || 1} color="#9333ea"
            centerText={<><UserX className="mb-1 h-5 w-5 text-purple-600" /><span className="text-lg font-bold text-slate-900">{studentsUnpaid}</span></>} />
          <p className="mt-2 text-center text-xs font-medium text-slate-600">❌ Students Unpaid</p>
        </KpiCard>
      </div>

      {/* Collection summary widgets (clickable) */}
      <div className="mb-6 grid gap-4 sm:grid-cols-3">
        <KpiCard onClick={() => navigate('/dashboard/daily-collection')}><p className="text-sm text-slate-600">Daily Collection</p><p className="mt-1 text-2xl font-bold text-green-600">{money(dailyCollection)}</p><p className="text-xs text-slate-400">Today →</p></KpiCard>
        <KpiCard onClick={() => navigate('/dashboard/monthly-collection')}><p className="text-sm text-slate-600">Weekly Collection</p><p className="mt-1 text-2xl font-bold text-blue-600">{money(weeklyCollection)}</p><p className="text-xs text-slate-400">Last 7 days →</p></KpiCard>
        <KpiCard onClick={() => navigate('/dashboard/ledger')}><p className="text-sm text-slate-600">Net Balance</p><p className={`mt-1 text-2xl font-bold ${collected - totalExpense >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>{money(collected - totalExpense)}</p><p className="text-xs text-slate-400">General Ledger →</p></KpiCard>
      </div>

      {/* Trend & breakdown charts */}
      <div className="mb-6 grid gap-6 lg:grid-cols-2">
        <Card title="Income vs Expense (6 months)">
          <IncomeExpenseChart data={trend} />
        </Card>
        <Card title="Monthly Collection Trend">
          <BarChart data={trend.map((t) => ({ label: t.label, value: t.income }))} color="#16a34a" valuePrefix="" />
        </Card>
      </div>

      <div className="mb-6 grid gap-6 lg:grid-cols-2">
        <Card title="Expense Breakdown">
          <BreakdownBars data={expenseBreakdown} />
        </Card>
        <Card title="Top Defaulters" action={<Btn size="sm" variant="secondary" onClick={() => navigate('/dashboard/fee-vouchers')}>View All</Btn>}>
          <div className="space-y-2">
            {defaulters.map((v) => (
              <div key={v.id} className="flex items-center justify-between rounded-lg bg-red-50 px-3 py-2 text-sm">
                <span className="font-medium text-slate-900">{studentName(v.student_id)}</span>
                <span className="font-semibold text-red-600">{money(v.amount)}</span>
              </div>
            ))}
            {defaulters.length === 0 && <EmptyState message="No defaulters 🎉" />}
          </div>
        </Card>
      </div>

      {/* Upcoming due */}
      <Card title="Upcoming Fee Due">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-left text-slate-600">
                <th className="pb-2 font-medium">Student</th><th className="pb-2 font-medium">Voucher</th>
                <th className="pb-2 font-medium">Amount</th><th className="pb-2 font-medium">Due Date</th>
              </tr>
            </thead>
            <tbody>
              {upcoming.map((v) => (
                <tr key={v.id} className="border-b border-slate-100">
                  <td className="py-2 font-medium text-slate-900">{studentName(v.student_id)}</td>
                  <td className="py-2 text-slate-600">{v.voucher_no}</td>
                  <td className="py-2 text-slate-600">{money(v.amount)}</td>
                  <td className="py-2 text-orange-600">{fmtDate(v.due_date)}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {upcoming.length === 0 && <EmptyState message="No upcoming dues" />}
        </div>
      </Card>

      {/* Quick links to accounts modules */}
      <div className="mt-6">
        <Card title="Accounts Modules">
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            <Btn variant="secondary" onClick={() => navigate('/dashboard/fee-vouchers')}>Fee Collection</Btn>
            <Btn variant="secondary" onClick={() => navigate('/dashboard/expenses')}>Expenses</Btn>
            <Btn variant="secondary" onClick={() => navigate('/dashboard/payroll')}>Salary Mgmt</Btn>
            <Btn variant="secondary" onClick={() => navigate('/dashboard/cashbook')}>Cash Book</Btn>
            <Btn variant="secondary" onClick={() => navigate('/dashboard/vouchers')}>Vouchers</Btn>
            <Btn variant="secondary" onClick={() => navigate('/dashboard/reconciliation')}>Bank Reconcile</Btn>
            <Btn variant="secondary" onClick={() => navigate('/dashboard/reports')}>Reports</Btn>
            <Btn variant="secondary" onClick={() => navigate('/dashboard/documents')}>Documents</Btn>
          </div>
        </Card>
      </div>
    </div>
  );
}

function abbrMoney(n: number): string {
  const s = getSettings();
  const cur = s.currency || 'PKR';
  if (n >= 1000000) return `${cur} ${(n / 1000000).toFixed(1)}M`;
  if (n >= 1000) return `${cur} ${(n / 1000).toFixed(0)}k`;
  return `${cur} ${n}`;
}

// Clickable KPI card wrapper for the accounts dashboard.
function KpiCard({ children, onClick }: { children: React.ReactNode; onClick?: () => void }) {
  return (
    <div
      onClick={onClick}
      className="cursor-pointer rounded-xl border border-slate-200 bg-white p-6 shadow-sm transition hover:-translate-y-0.5 hover:border-indigo-300 hover:shadow-md"
    >
      {children}
    </div>
  );
}
