import { useState } from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { useCollection } from '../../hooks/useDB';
import { insert, remove, getAll, logActivity } from '../../lib/db';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../components/ui/Toast';
import { useConfirm } from '../../components/ui/Confirm';
import { Modal } from '../../components/ui/Modal';
import { Field, Input, Select } from '../../components/ui/Field';
import { PageHeader, Card, Btn, EmptyState, StatCard } from '../../components/ui/Shared';
import { money, fmtDate, printDocument } from '../../lib/utils';
import { TrendingUp, AlertCircle, Users2, Wallet, CalendarDays } from 'lucide-react';

// ---------------- PENDING FEES ----------------
export function PendingFeesPage() {
  const vouchers = useCollection<any>('feeVouchers').filter((v) => v.status !== 'paid');
  const students = useCollection<any>('students');
  const studentName = (id: string) => students.find((s) => s.id === id)?.name || '-';
  const total = vouchers.reduce((a, v) => a + v.amount, 0);
  return (
    <div>
      <PageHeader title="Pending Fees" subtitle="All unpaid and partially paid vouchers" />
      <div className="mb-6 grid gap-4 sm:grid-cols-2">
        <StatCard title="Pending Vouchers" value={vouchers.length} icon={AlertCircle} color="from-amber-500 to-amber-600" />
        <StatCard title="Total Pending Amount" value={money(total)} icon={Wallet} color="from-rose-500 to-rose-600" />
      </div>
      <Card title="Pending Voucher List">
        <Table head={['Voucher', 'Student', 'Amount', 'Due Date', 'Status']}
          rows={vouchers.map((v) => [v.voucher_no, studentName(v.student_id), money(v.amount), fmtDate(v.due_date), v.status])} />
        {vouchers.length === 0 && <EmptyState message="No pending fees 🎉" />}
      </Card>
    </div>
  );
}

// ---------------- FEE DEFAULTERS ----------------
export function DefaultersPage() {
  const vouchers = useCollection<any>('feeVouchers').filter((v) => v.status === 'overdue');
  const students = useCollection<any>('students');
  const studentName = (id: string) => students.find((s) => s.id === id)?.name || '-';
  const studentPhone = (id: string) => students.find((s) => s.id === id)?.phone || '-';
  return (
    <div>
      <PageHeader title="Fee Defaulters" subtitle="Students with overdue fees" />
      <Card title={`${vouchers.length} Defaulters`}>
        <Table head={['Student', 'Phone', 'Amount', 'Due Date']}
          rows={vouchers.map((v) => [studentName(v.student_id), studentPhone(v.student_id), money(v.amount), fmtDate(v.due_date)])} />
        {vouchers.length === 0 && <EmptyState message="No defaulters" />}
      </Card>
    </div>
  );
}

// ---------------- FEE STRUCTURE ----------------
export function FeeStructurePage() {
  const feeTypes = useCollection<any>('feeTypes');
  const classes = useCollection<any>('classes');
  const { user } = useAuth();
  const { notify } = useToast();
  const confirm = useConfirm();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<any>({ name: '', amount: 0, frequency: 'Monthly', class_id: '' });

  const className = (id: string) => classes.find((c) => c.id === id)?.name || 'All Classes';
  const save = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.amount) return notify('Name and amount required', 'error');
    insert('feeTypes', { ...form, amount: Number(form.amount) });
    logActivity(user!, `Added fee type ${form.name}`, 'fee_type');
    notify('Fee type added');
    setOpen(false);
    setForm({ name: '', amount: 0, frequency: 'Monthly', class_id: '' });
  };
  const del = async (f: any) => {
    if (!(await confirm({ message: `Delete fee "${f.name}"?`, danger: true, confirmText: 'Delete' }))) return;
    remove('feeTypes', f.id);
    notify('Deleted');
  };

  return (
    <div>
      <PageHeader title="Fee Structure" subtitle="Define fee types and amounts"
        action={<Btn onClick={() => setOpen(true)}><span className="flex items-center gap-2"><Plus className="h-4 w-4" /> Add Fee Type</span></Btn>} />
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="border-b border-slate-200 text-left text-slate-600">
              <th className="pb-3 font-medium">Fee Name</th><th className="pb-3 font-medium">Amount</th>
              <th className="pb-3 font-medium">Frequency</th><th className="pb-3 font-medium">Applies To</th><th className="pb-3"></th>
            </tr></thead>
            <tbody>
              {feeTypes.map((f) => (
                <tr key={f.id} className="border-b border-slate-100">
                  <td className="py-3 font-medium text-slate-900">{f.name}</td>
                  <td className="py-3 text-slate-600">{money(f.amount)}</td>
                  <td className="py-3 text-slate-600">{f.frequency}</td>
                  <td className="py-3 text-slate-600">{className(f.class_id)}</td>
                  <td className="py-3 text-right"><button onClick={() => del(f)} className="rounded p-1.5 text-rose-600 hover:bg-rose-50"><Trash2 className="h-4 w-4" /></button></td>
                </tr>
              ))}
            </tbody>
          </table>
          {feeTypes.length === 0 && <EmptyState message="No fee types defined" />}
        </div>
      </Card>
      <Modal open={open} onClose={() => setOpen(false)} title="Add Fee Type">
        <form onSubmit={save} className="space-y-4">
          <Field label="Fee Name" required><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Tuition, Lab, Transport" /></Field>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Amount (PKR)" required><Input type="number" value={form.amount} onChange={(e) => setForm({ ...form, amount: Number(e.target.value) })} /></Field>
            <Field label="Frequency"><Select value={form.frequency} onChange={(e) => setForm({ ...form, frequency: e.target.value })}><option>Monthly</option><option>Quarterly</option><option>Annually</option><option>One-time</option></Select></Field>
          </div>
          <Field label="Applies To Class"><Select value={form.class_id} onChange={(e) => setForm({ ...form, class_id: e.target.value })}><option value="">All Classes</option>{classes.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</Select></Field>
          <div className="flex justify-end gap-2 pt-2"><Btn variant="secondary" onClick={() => setOpen(false)}>Cancel</Btn><Btn type="submit">Add</Btn></div>
        </form>
      </Modal>
    </div>
  );
}

// ---------------- INCOME ----------------
export function IncomePage() {
  const payments = useCollection<any>('feePayments');
  const total = payments.reduce((a, p) => a + (p.amount_paid || 0), 0);
  return (
    <div>
      <PageHeader title="Income" subtitle="All income received (fee collections)" />
      <div className="mb-6"><StatCard title="Total Income" value={money(total)} icon={TrendingUp} color="from-emerald-500 to-emerald-600" /></div>
      <Card title="Income Transactions">
        <Table head={['Receipt', 'Amount', 'Late Fee', 'Discount', 'Date']}
          rows={payments.slice().reverse().map((p) => [p.receipt_no || '-', money(p.amount_paid), money(p.late_fee || 0), money(p.discount || 0), fmtDate(p.paid_at)])} />
        {payments.length === 0 && <EmptyState message="No income recorded" />}
      </Card>
    </div>
  );
}

// ---------------- GENERAL LEDGER ----------------
export function GeneralLedgerPage() {
  const payments = useCollection<any>('feePayments');
  const expenses = useCollection<any>('expenses');
  const entries = [
    ...payments.map((p) => ({ date: p.paid_at || p.created_at, desc: 'Fee Income ' + (p.receipt_no || ''), debit: 0, credit: p.amount_paid })),
    ...expenses.map((e) => ({ date: e.date || e.created_at, desc: e.description, debit: e.amount, credit: 0 })),
  ].sort((a, b) => (a.date < b.date ? -1 : 1));
  let balance = 0;
  const rows = entries.map((e) => { balance += e.credit - e.debit; return [fmtDate(e.date), e.desc, e.debit ? money(e.debit) : '-', e.credit ? money(e.credit) : '-', money(balance)]; });
  return (
    <div>
      <PageHeader title="General Ledger" subtitle="Complete debit/credit ledger with running balance" />
      <Card>
        <Table head={['Date', 'Description', 'Debit', 'Credit', 'Balance']} rows={rows} />
        {rows.length === 0 && <EmptyState message="No ledger entries" />}
      </Card>
    </div>
  );
}

// ---------------- BANK TRANSACTIONS ----------------
export function BankTransactionsPage() {
  const recon = useCollection<any>('bankReconciliation');
  return (
    <div>
      <PageHeader title="Bank Transactions" subtitle="Bank-related entries and reconciliation status" />
      <Card>
        <Table head={['Date', 'Description', 'Book Balance', 'Bank Balance', 'Status']}
          rows={recon.map((r) => [fmtDate(r.date), r.description, money(r.book_balance), money(r.bank_balance), r.status])} />
        {recon.length === 0 && <EmptyState message="No bank transactions. Add entries from Bank Reconciliation." />}
      </Card>
    </div>
  );
}

// ---------------- COLLECTION REPORTS ----------------
export function CollectionReportPage({ period }: { period: 'daily' | 'monthly' }) {
  const payments = useCollection<any>('feePayments');
  const today = new Date().toISOString().slice(0, 10);
  const monthStart = today.slice(0, 8) + '01';
  const filtered = period === 'daily'
    ? payments.filter((p) => (p.paid_at || p.created_at).slice(0, 10) === today)
    : payments.filter((p) => (p.paid_at || p.created_at) >= monthStart);
  const total = filtered.reduce((a, p) => a + p.amount_paid, 0);
  const title = period === 'daily' ? 'Daily Collection Report' : 'Monthly Collection Report';

  const print = () => {
    const rows = filtered.map((p) => `<tr><td>${p.receipt_no || '-'}</td><td>${money(p.amount_paid)}</td><td>${fmtDate(p.paid_at)}</td></tr>`).join('');
    printDocument(title, `<div class="title">${title}</div><table><thead><tr><th>Receipt</th><th>Amount</th><th>Date</th></tr></thead><tbody>${rows}</tbody></table><div class="row"><span class="label">Total</span><span class="value">${money(total)}</span></div>`);
  };

  return (
    <div>
      <PageHeader title={title} subtitle={period === 'daily' ? "Today's fee collection" : "This month's fee collection"}
        action={<Btn variant="secondary" onClick={print}>Print Report</Btn>} />
      <div className="mb-6 grid gap-4 sm:grid-cols-2">
        <StatCard title="Transactions" value={filtered.length} icon={Users2} color="from-indigo-500 to-indigo-600" />
        <StatCard title={period === 'daily' ? "Today's Total" : "Month Total"} value={money(total)} icon={CalendarDays} color="from-emerald-500 to-emerald-600" />
      </div>
      <Card>
        <Table head={['Receipt', 'Amount', 'Date']} rows={filtered.map((p) => [p.receipt_no || '-', money(p.amount_paid), fmtDate(p.paid_at)])} />
        {filtered.length === 0 && <EmptyState message="No collections in this period" />}
      </Card>
    </div>
  );
}

// ---------------- OUTSTANDING DUES REPORT ----------------
export function OutstandingDuesPage() {
  const vouchers = useCollection<any>('feeVouchers').filter((v) => v.status !== 'paid');
  const students = useCollection<any>('students');
  const studentName = (id: string) => students.find((s) => s.id === id)?.name || '-';
  const total = vouchers.reduce((a, v) => a + v.amount, 0);
  return (
    <div>
      <PageHeader title="Outstanding Dues Report" subtitle="Total receivables from students" />
      <div className="mb-6"><StatCard title="Total Outstanding" value={money(total)} icon={AlertCircle} color="from-rose-500 to-rose-600" /></div>
      <Card>
        <Table head={['Student', 'Voucher', 'Amount', 'Due Date', 'Status']}
          rows={vouchers.map((v) => [studentName(v.student_id), v.voucher_no, money(v.amount), fmtDate(v.due_date), v.status])} />
        {vouchers.length === 0 && <EmptyState message="No outstanding dues" />}
      </Card>
    </div>
  );
}

// ---------------- STUDENT FINANCIAL HISTORY ----------------
export function StudentFinancialHistoryPage() {
  const students = useCollection<any>('students');
  const vouchers = useCollection<any>('feeVouchers');
  const payments = useCollection<any>('feePayments');
  const [studentId, setStudentId] = useState(students[0]?.id || '');
  const myVouchers = vouchers.filter((v) => v.student_id === studentId);
  const myPayments = payments.filter((p) => myVouchers.some((v) => v.id === p.voucher_id));
  const paid = myPayments.reduce((a, p) => a + p.amount_paid, 0);
  const billed = myVouchers.reduce((a, v) => a + v.amount, 0);

  return (
    <div>
      <PageHeader title="Student Financial History" subtitle="Per-student billing and payment record" />
      <Card>
        <div className="mb-4 max-w-xs">
          <Select value={studentId} onChange={(e) => setStudentId(e.target.value)}>
            {students.map((s) => <option key={s.id} value={s.id}>{s.name} ({s.student_code})</option>)}
          </Select>
        </div>
        <div className="mb-4 grid gap-4 sm:grid-cols-3">
          <StatCard title="Total Billed" value={money(billed)} icon={Wallet} color="from-indigo-500 to-indigo-600" />
          <StatCard title="Total Paid" value={money(paid)} icon={TrendingUp} color="from-emerald-500 to-emerald-600" />
          <StatCard title="Balance" value={money(billed - paid)} icon={AlertCircle} color="from-amber-500 to-amber-600" />
        </div>
        <Table head={['Voucher', 'Amount', 'Due Date', 'Status']}
          rows={myVouchers.map((v) => [v.voucher_no, money(v.amount), fmtDate(v.due_date), v.status])} />
        {myVouchers.length === 0 && <EmptyState message="No financial records for this student" />}
      </Card>
    </div>
  );
}

// Shared compact table component -------------------------------------------------
function Table({ head, rows }: { head: string[]; rows: (string | number)[][] }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-slate-200 text-left text-slate-600">
            {head.map((h) => <th key={h} className="pb-3 font-medium">{h}</th>)}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i} className="border-b border-slate-100">
              {r.map((c, j) => <td key={j} className="py-3 text-slate-700">{c}</td>)}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

void getAll;
