import { useState } from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { useCollection } from '../../hooks/useDB';
import { insert, remove, logActivity } from '../../lib/db';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../components/ui/Toast';
import { Modal } from '../../components/ui/Modal';
import { Field, Input, Select } from '../../components/ui/Field';
import { PageHeader, Card, Btn, EmptyState } from '../../components/ui/Shared';

const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];

export function TimetablePage({ canEdit = false, classId = '' }: { canEdit?: boolean; classId?: string }) {
  const timetable = useCollection<any>('timetable');
  const classes = useCollection<any>('classes');
  const subjects = useCollection<any>('subjects');
  const { user } = useAuth();
  const { notify } = useToast();
  const [selClass, setSelClass] = useState(classId || classes[0]?.id || '');
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ class_id: selClass, subject_id: '', day_of_week: 'Monday', start_time: '08:00', end_time: '08:45', room: '' });

  const activeClass = classId || selClass;
  const subName = (id: string) => subjects.find((s) => s.id === id)?.name || '-';
  const entries = timetable.filter((t) => t.class_id === activeClass);

  const save = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.subject_id) return notify('Select a subject', 'error');
    insert('timetable', { ...form, class_id: activeClass, teacher_id: user!.id });
    logActivity(user!, 'Added timetable slot', 'timetable');
    notify('Slot added');
    setOpen(false);
  };

  return (
    <div>
      <PageHeader title="Timetable" subtitle="Weekly class schedule"
        action={canEdit && <Btn onClick={() => { setForm({ ...form, class_id: activeClass }); setOpen(true); }}><span className="flex items-center gap-2"><Plus className="h-4 w-4" /> Add Slot</span></Btn>} />

      <Card>
        {!classId && (
          <div className="mb-4">
            <Select value={selClass} onChange={(e) => setSelClass(e.target.value)} className="max-w-[220px]">
              {classes.map((c) => <option key={c.id} value={c.id}>{c.name} - {c.section}</option>)}
            </Select>
          </div>
        )}
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-left text-slate-600">
                <th className="pb-3 font-medium">Day</th><th className="pb-3 font-medium">Time</th>
                <th className="pb-3 font-medium">Subject</th><th className="pb-3 font-medium">Room</th>
                {canEdit && <th className="pb-3 font-medium">Action</th>}
              </tr>
            </thead>
            <tbody>
              {DAYS.flatMap((day) =>
                entries.filter((t) => t.day_of_week === day).sort((a, b) => a.start_time.localeCompare(b.start_time)).map((t) => (
                  <tr key={t.id} className="border-b border-slate-100">
                    <td className="py-2 font-medium text-slate-900">{t.day_of_week}</td>
                    <td className="py-2 text-slate-600">{t.start_time} - {t.end_time}</td>
                    <td className="py-2 text-slate-600">{subName(t.subject_id)}</td>
                    <td className="py-2 text-slate-600">{t.room || '-'}</td>
                    {canEdit && <td className="py-2"><button onClick={() => { remove('timetable', t.id); notify('Slot removed'); }} className="rounded p-1.5 text-red-600 hover:bg-red-50"><Trash2 className="h-4 w-4" /></button></td>}
                  </tr>
                )),
              )}
            </tbody>
          </table>
          {entries.length === 0 && <EmptyState message="No timetable slots for this class" />}
        </div>
      </Card>

      <Modal open={open} onClose={() => setOpen(false)} title="Add Timetable Slot">
        <form onSubmit={save} className="space-y-4">
          <Field label="Subject" required>
            <Select value={form.subject_id} onChange={(e) => setForm({ ...form, subject_id: e.target.value })}>
              <option value="">Select subject...</option>
              {subjects.filter((s) => s.class_id === activeClass).map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </Select>
          </Field>
          <Field label="Day"><Select value={form.day_of_week} onChange={(e) => setForm({ ...form, day_of_week: e.target.value })}>{DAYS.map((d) => <option key={d}>{d}</option>)}</Select></Field>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Start Time"><Input type="time" value={form.start_time} onChange={(e) => setForm({ ...form, start_time: e.target.value })} /></Field>
            <Field label="End Time"><Input type="time" value={form.end_time} onChange={(e) => setForm({ ...form, end_time: e.target.value })} /></Field>
          </div>
          <Field label="Room"><Input value={form.room} onChange={(e) => setForm({ ...form, room: e.target.value })} /></Field>
          <div className="flex justify-end gap-2 pt-2"><Btn variant="secondary" onClick={() => setOpen(false)}>Cancel</Btn><Btn type="submit">Add</Btn></div>
        </form>
      </Modal>
    </div>
  );
}
