import { useState } from 'react';
import { useCollection } from '../../hooks/useDB';
import { Input } from '../../components/ui/Field';
import { PageHeader, Card, EmptyState } from '../../components/ui/Shared';

export function LogsPage() {
  const logs = useCollection<any>('activityLogs');
  const [search, setSearch] = useState('');

  const filtered = logs.filter((l) => !search || l.user_name?.toLowerCase().includes(search.toLowerCase()) || l.action?.toLowerCase().includes(search.toLowerCase()));

  return (
    <div>
      <PageHeader title="Activity Logs" subtitle="Full audit trail of system actions" />
      <Card>
        <div className="mb-4 max-w-sm">
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search logs..." />
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-left text-slate-600">
                <th className="pb-3 font-medium">User</th><th className="pb-3 font-medium">Action</th>
                <th className="pb-3 font-medium">Entity</th><th className="pb-3 font-medium">IP Address</th>
                <th className="pb-3 font-medium">Timestamp</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((l) => (
                <tr key={l.id} className="border-b border-slate-100">
                  <td className="py-3 font-medium text-slate-900">{l.user_name}</td>
                  <td className="py-3 text-slate-600">{l.action}</td>
                  <td className="py-3 text-slate-500">{l.entity_type || '-'}</td>
                  <td className="py-3 text-slate-400">{l.ip_address}</td>
                  <td className="py-3 text-slate-500">{new Date(l.timestamp).toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {filtered.length === 0 && <EmptyState message="No activity logs" />}
        </div>
      </Card>
    </div>
  );
}
