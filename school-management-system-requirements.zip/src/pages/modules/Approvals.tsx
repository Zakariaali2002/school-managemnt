import { Check, X } from 'lucide-react';
import { useCollection } from '../../hooks/useDB';
import { update, logActivity } from '../../lib/db';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../components/ui/Toast';
import { PageHeader, Card, EmptyState } from '../../components/ui/Shared';
import { money, fmtDate } from '../../lib/utils';

export function ApprovalsPage() {
  const leaves = useCollection<any>('leaveRequests').filter((l) => l.status === 'pending');
  const expenses = useCollection<any>('expenses').filter((e) => !e.approved_by);
  const { user } = useAuth();
  const { notify } = useToast();

  const reviewLeave = (lr: any, status: 'approved' | 'rejected') => {
    update('leaveRequests', lr.id, { status, reviewed_by: user!.id });
    logActivity(user!, `${status} leave for ${lr.staff_name}`, 'leave', lr.id);
    notify(`Leave ${status}`);
  };

  const approveExpense = (ex: any) => {
    update('expenses', ex.id, { approved_by: user!.id });
    logActivity(user!, `Approved expense ${ex.description}`, 'expense', ex.id);
    notify('Expense approved');
  };

  const rejectExpense = (ex: any) => {
    update('expenses', ex.id, { approved_by: 'rejected' });
    logActivity(user!, `Rejected expense ${ex.description}`, 'expense', ex.id);
    notify('Expense rejected');
  };

  return (
    <div>
      <PageHeader title="Pending Approvals" subtitle="Review leave requests and expense approvals" />
      <div className="grid gap-6 lg:grid-cols-2">
        <Card title={`Leave Requests (${leaves.length})`}>
          <div className="space-y-3">
            {leaves.map((lr) => (
              <div key={lr.id} className="flex items-center justify-between rounded-lg bg-slate-50 p-3">
                <div>
                  <p className="text-sm font-medium text-slate-900">{lr.staff_name}</p>
                  <p className="text-xs text-slate-500">{lr.leave_type} · {fmtDate(lr.from_date)} → {fmtDate(lr.to_date)}</p>
                  <p className="text-xs text-slate-400">{lr.reason}</p>
                </div>
                <div className="flex gap-1">
                  <button onClick={() => reviewLeave(lr, 'approved')} className="rounded bg-green-100 p-1.5 text-green-700 hover:bg-green-200"><Check className="h-4 w-4" /></button>
                  <button onClick={() => reviewLeave(lr, 'rejected')} className="rounded bg-red-100 p-1.5 text-red-700 hover:bg-red-200"><X className="h-4 w-4" /></button>
                </div>
              </div>
            ))}
            {leaves.length === 0 && <EmptyState message="No pending leave requests" />}
          </div>
        </Card>

        <Card title={`Expense Approvals (${expenses.length})`}>
          <div className="space-y-3">
            {expenses.map((ex) => (
              <div key={ex.id} className="flex items-center justify-between rounded-lg bg-slate-50 p-3">
                <div>
                  <p className="text-sm font-medium text-slate-900">{ex.description}</p>
                  <p className="text-xs text-slate-500">{ex.category} · {money(ex.amount)} · {ex.paid_to}</p>
                </div>
                <div className="flex gap-1">
                  <button onClick={() => approveExpense(ex)} className="rounded bg-green-100 p-1.5 text-green-700 hover:bg-green-200"><Check className="h-4 w-4" /></button>
                  <button onClick={() => rejectExpense(ex)} className="rounded bg-red-100 p-1.5 text-red-700 hover:bg-red-200"><X className="h-4 w-4" /></button>
                </div>
              </div>
            ))}
            {expenses.length === 0 && <EmptyState message="No pending expenses" />}
          </div>
        </Card>
      </div>
    </div>
  );
}
