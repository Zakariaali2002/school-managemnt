import { useNavigate } from 'react-router-dom';
import { Construction, ArrowLeft } from 'lucide-react';
import { PageHeader, Btn } from '../../components/ui/Shared';

// Placeholder shown for modules that are not yet completed.
export function UnderDevelopment({ title, description }: { title?: string; description?: string }) {
  const navigate = useNavigate();
  return (
    <div>
      <PageHeader title={title || 'Module'} subtitle={description || 'This module is part of the system roadmap'} />
      <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-slate-300 bg-white py-20 text-center shadow-sm">
        <div className="mb-4 flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-amber-100 to-orange-100">
          <Construction className="h-10 w-10 text-amber-600" />
        </div>
        <h2 className="text-xl font-bold text-slate-800">Module Under Development</h2>
        <p className="mt-2 max-w-md px-4 text-sm text-slate-500">
          {title ? `The "${title}" module` : 'This module'} is currently being built and will be
          available soon. All navigation and structure are in place.
        </p>
        <Btn className="mt-6" variant="secondary" onClick={() => navigate(-1)}>
          <span className="flex items-center gap-2"><ArrowLeft className="h-4 w-4" /> Go Back</span>
        </Btn>
      </div>
    </div>
  );
}

// Helper factory so we can register many placeholder routes quickly.
export function makeUD(title: string, description?: string) {
  return <UnderDevelopment title={title} description={description} />;
}
