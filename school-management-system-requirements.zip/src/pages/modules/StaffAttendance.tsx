import { useState } from 'react';
import { useCollection } from '../../hooks/useDB';
import { insert, update, logActivity, getAll } from '../../lib/db';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../components/ui/Toast';
import { PageHeader, Card, Btn, EmptyState } from '../../components/ui/Shared';
import { printDocument } from '../../lib/utils';

export function StaffAttendancePage() {
  const staff = useCollection<any>('staff');
  const records = useCollection<any>('staffAttendance');
  const { user } = useAuth();
  const { notify } = useToast();
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [marks, setMarks] = useState<Record<string, { status: string; check_in: string; check_out: string }>>({});

  const existing = (sid: string) => records.find((r) => r.staff_id === sid && r.date === date);

  const get = (sid: string) => marks[sid] || {
    status: existing(sid)?.status || 'present',
    check_in: existing(sid)?.check_in || '08:00',
    check_out: existing(sid)?.check_out || '15:00',
  };

  const set = (sid: string, patch: any) => setMarks({ ...marks, [sid]: { ...get(sid), ...patch } });

  const submit = () => {
    staff.forEach((s) => {
      const data = get(s.id);
      const rec = existing(s.id);
      if (rec) update('staffAttendance', rec.id, data);
      else insert('staffAttendance', { staff_id: s.id, date, ...data });
    });
    logActivity(user!, `Marked staff attendance for ${staff.length} members`, 'staff_attendance');
    notify('Staff attendance saved');
    setMarks({});
  };

  const report = () => {
    const recs = getAll('staffAttendance');
    const rows = staff.map((s) => {
      const sr = recs.filter((r: any) => r.staff_id === s.id);
      const present = sr.filter((r: any) => r.status === 'present').length;
      return `<tr><td>${s.employee_code}</td><td>${s.name}</td><td>${present}</td><td>${sr.length}</td></tr>`;
    }).join('');
    printDocument('Staff Attendance Report', `
      <div class="title">Staff Attendance Report</div>
      <table><thead><tr><th>Code</th><th>Name</th><th>Days Present</th><th>Total Days</th></tr></thead><tbody>${rows}</tbody></table>
    `);
  };

  return (
    <div>
      <PageHeader title="Staff Attendance" subtitle="Daily check-in / check-out tracking" />
      <Card title="Mark Staff Attendance" action={<Btn variant="secondary" size="sm" onClick={report}>Report</Btn>}>
        <div className="mb-4">
          <input type="date" value={date} onChange={(e) => { setDate(e.target.value); setMarks({}); }} className="rounded-md border border-slate-300 px-3 py-2 text-sm" />
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-left text-slate-600">
                <th className="pb-3 font-medium">Staff</th>
                <th className="pb-3 font-medium">Status</th>
                <th className="pb-3 font-medium">Check In</th>
                <th className="pb-3 font-medium">Check Out</th>
              </tr>
            </thead>
            <tbody>
              {staff.map((s) => {
                const d = get(s.id);
                return (
                  <tr key={s.id} className="border-b border-slate-100">
                    <td className="py-2 font-medium text-slate-900">{s.name}</td>
                    <td className="py-2">
                      <select value={d.status} onChange={(e) => set(s.id, { status: e.target.value })} className="rounded border border-slate-300 px-2 py-1 text-xs">
                        <option value="present">Present</option><option value="absent">Absent</option><option value="leave">Leave</option><option value="late">Late</option>
                      </select>
                    </td>
                    <td className="py-2"><input type="time" value={d.check_in} onChange={(e) => set(s.id, { check_in: e.target.value })} className="rounded border border-slate-300 px-2 py-1 text-xs" /></td>
                    <td className="py-2"><input type="time" value={d.check_out} onChange={(e) => set(s.id, { check_out: e.target.value })} className="rounded border border-slate-300 px-2 py-1 text-xs" /></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {staff.length === 0 && <EmptyState message="No staff" />}
        </div>
        <div className="mt-4 flex justify-end"><Btn onClick={submit}>Submit</Btn></div>
      </Card>
    </div>
  );
}
