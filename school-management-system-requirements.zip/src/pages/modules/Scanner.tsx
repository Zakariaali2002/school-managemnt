import { useState, useRef, useEffect } from 'react';
import { ScanLine, CheckCircle2, XCircle, Clock, UserCheck, GraduationCap } from 'lucide-react';
import { useCollection } from '../../hooks/useDB';
import { getAll, insert, update, logActivity } from '../../lib/db';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../components/ui/Toast';
import { PageHeader, Card, Btn, EmptyState } from '../../components/ui/Shared';
import { StatusBadge, fmtDate } from '../../lib/utils';

interface ScanResult {
  ok: boolean;
  name: string;
  type: 'student' | 'staff';
  code: string;
  status: string;
  time: string;
  message: string;
}

export function ScannerPage() {
  const { user } = useAuth();
  const { notify } = useToast();
  const studentAttendance = useCollection<any>('studentAttendance');
  const staffAttendance = useCollection<any>('staffAttendance');
  const [code, setCode] = useState('');
  const [lastResult, setLastResult] = useState<ScanResult | null>(null);
  const [history, setHistory] = useState<ScanResult[]>([]);
  const [lateAfter, setLateAfter] = useState('08:30');
  const inputRef = useRef<HTMLInputElement>(null);

  // Keep the scanner input focused (hardware barcode scanners type + Enter)
  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const today = new Date().toISOString().slice(0, 10);

  const processScan = (raw: string) => {
    const scanCode = raw.trim();
    if (!scanCode) return;

    const nowTime = new Date();
    const hhmm = nowTime.toTimeString().slice(0, 5);
    const isLate = hhmm > lateAfter;
    const status = isLate ? 'late' : 'present';

    // Try student first
    const student = getAll('students').find(
      (s: any) => s.student_code?.toLowerCase() === scanCode.toLowerCase() || s.barcode?.toLowerCase() === scanCode.toLowerCase(),
    );
    if (student) {
      const existing = getAll('studentAttendance').find((r: any) => r.student_id === student.id && r.date === today);
      if (existing) {
        const res: ScanResult = { ok: false, name: student.name, type: 'student', code: scanCode, status: existing.status, time: hhmm, message: 'Already marked today' };
        setLastResult(res); setHistory((h) => [res, ...h].slice(0, 30));
        notify(`${student.name} already marked`, 'info');
        return;
      }
      insert('studentAttendance', { student_id: student.id, class_id: student.class_id, date: today, status, marked_by: user!.id, remarks: 'Barcode scan', check_in: hhmm });
      logActivity(user!, `Scanned attendance for ${student.name} (${status})`, 'attendance', student.id);
      const res: ScanResult = { ok: true, name: student.name, type: 'student', code: scanCode, status, time: hhmm, message: 'Attendance marked' };
      setLastResult(res); setHistory((h) => [res, ...h].slice(0, 30));
      notify(`✓ ${student.name} marked ${status}`, 'success');
      return;
    }

    // Then staff
    const staff = getAll('staff').find(
      (s: any) => s.employee_code?.toLowerCase() === scanCode.toLowerCase() || s.barcode?.toLowerCase() === scanCode.toLowerCase(),
    );
    if (staff) {
      const existing = getAll('staffAttendance').find((r: any) => r.staff_id === staff.id && r.date === today);
      if (existing && existing.check_in) {
        // second scan = check out
        update('staffAttendance', existing.id, { check_out: hhmm });
        logActivity(user!, `Scanned check-out for ${staff.name}`, 'staff_attendance', staff.id);
        const res: ScanResult = { ok: true, name: staff.name, type: 'staff', code: scanCode, status: 'checked out', time: hhmm, message: 'Check-out recorded' };
        setLastResult(res); setHistory((h) => [res, ...h].slice(0, 30));
        notify(`✓ ${staff.name} checked out`, 'success');
        return;
      }
      insert('staffAttendance', { staff_id: staff.id, date: today, status, check_in: hhmm, check_out: '', remarks: 'Barcode scan' });
      logActivity(user!, `Scanned attendance for ${staff.name} (${status})`, 'staff_attendance', staff.id);
      const res: ScanResult = { ok: true, name: staff.name, type: 'staff', code: scanCode, status, time: hhmm, message: 'Check-in recorded' };
      setLastResult(res); setHistory((h) => [res, ...h].slice(0, 30));
      notify(`✓ ${staff.name} checked in (${status})`, 'success');
      return;
    }

    // not found
    const res: ScanResult = { ok: false, name: 'Unknown', type: 'student', code: scanCode, status: '-', time: hhmm, message: 'No matching ID card found' };
    setLastResult(res); setHistory((h) => [res, ...h].slice(0, 30));
    notify('No matching ID found for ' + scanCode, 'error');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    processScan(code);
    setCode('');
    inputRef.current?.focus();
  };

  const todayStudents = studentAttendance.filter((r) => r.date === today);
  const todayStaff = staffAttendance.filter((r) => r.date === today);
  const studentName = (id: string) => getAll('students').find((s: any) => s.id === id)?.name || '-';
  const staffName = (id: string) => getAll('staff').find((s: any) => s.id === id)?.name || '-';

  return (
    <div>
      <PageHeader title="Barcode Attendance Scanner" subtitle="Scan an ID card barcode to mark attendance automatically" />

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Scanner panel */}
        <Card>
          <div className="text-center">
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-600 to-indigo-600">
              <ScanLine className="h-8 w-8 text-white" />
            </div>
            <h3 className="text-lg font-semibold text-slate-900">Scan ID Card</h3>
            <p className="mb-4 text-sm text-slate-500">Use a barcode scanner or type the code, then press Enter</p>

            <form onSubmit={handleSubmit} className="space-y-3">
              <input
                ref={inputRef}
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="Scan or enter ID code (e.g. STU-2024-0001)"
                className="w-full rounded-lg border-2 border-blue-200 px-4 py-3 text-center text-lg font-mono shadow-sm focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-200"
                autoComplete="off"
              />
              <Btn type="submit" className="w-full">Mark Attendance</Btn>
            </form>

            <div className="mt-4 flex items-center justify-center gap-2 text-sm">
              <Clock className="h-4 w-4 text-slate-400" />
              <span className="text-slate-500">Mark as late after:</span>
              <input type="time" value={lateAfter} onChange={(e) => setLateAfter(e.target.value)} className="rounded border border-slate-300 px-2 py-1 text-sm" />
            </div>
          </div>

          {/* Last result */}
          {lastResult && (
            <div className={`mt-6 rounded-xl border-2 p-4 ${lastResult.ok ? 'border-green-200 bg-green-50' : 'border-red-200 bg-red-50'}`}>
              <div className="flex items-center gap-3">
                {lastResult.ok ? <CheckCircle2 className="h-8 w-8 text-green-600" /> : <XCircle className="h-8 w-8 text-red-600" />}
                <div className="flex-1">
                  <p className="font-semibold text-slate-900">{lastResult.name}</p>
                  <p className="text-sm text-slate-600">{lastResult.message} · {lastResult.time}</p>
                </div>
                {lastResult.status !== '-' && <StatusBadge status={lastResult.status} />}
              </div>
            </div>
          )}
        </Card>

        {/* Scan history */}
        <Card title="Recent Scans">
          <div className="max-h-96 space-y-2 overflow-y-auto">
            {history.map((h, i) => (
              <div key={i} className={`flex items-center gap-3 rounded-lg p-2.5 ${h.ok ? 'bg-slate-50' : 'bg-red-50'}`}>
                {h.type === 'student' ? <GraduationCap className="h-5 w-5 text-blue-500" /> : <UserCheck className="h-5 w-5 text-purple-500" />}
                <div className="flex-1">
                  <p className="text-sm font-medium text-slate-900">{h.name}</p>
                  <p className="text-xs text-slate-500">{h.code} · {h.time}</p>
                </div>
                {h.status !== '-' ? <StatusBadge status={h.status} /> : <span className="text-xs text-red-500">Not found</span>}
              </div>
            ))}
            {history.length === 0 && <EmptyState message="No scans yet. Scan an ID card to begin." />}
          </div>
        </Card>
      </div>

      {/* Today summary */}
      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <Card title={`Today's Student Attendance (${todayStudents.length})`}>
          <div className="max-h-64 space-y-1 overflow-y-auto">
            {todayStudents.slice().reverse().map((r) => (
              <div key={r.id} className="flex items-center justify-between rounded bg-slate-50 px-3 py-1.5 text-sm">
                <span className="text-slate-700">{studentName(r.student_id)} {r.check_in && <span className="text-xs text-slate-400">· {r.check_in}</span>}</span>
                <StatusBadge status={r.status} />
              </div>
            ))}
            {todayStudents.length === 0 && <EmptyState message="No student attendance today" />}
          </div>
        </Card>
        <Card title={`Today's Staff Attendance (${todayStaff.length})`}>
          <div className="max-h-64 space-y-1 overflow-y-auto">
            {todayStaff.slice().reverse().map((r) => (
              <div key={r.id} className="flex items-center justify-between rounded bg-slate-50 px-3 py-1.5 text-sm">
                <span className="text-slate-700">{staffName(r.staff_id)} <span className="text-xs text-slate-400">· in {r.check_in}{r.check_out ? ` / out ${r.check_out}` : ''}</span></span>
                <StatusBadge status={r.status} />
              </div>
            ))}
            {todayStaff.length === 0 && <EmptyState message="No staff attendance today" />}
          </div>
        </Card>
      </div>
    </div>
  );
}

void fmtDate;
