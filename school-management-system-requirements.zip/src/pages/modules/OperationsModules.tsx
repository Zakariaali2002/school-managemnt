import { useState } from 'react';
import { Plus, Trash2, Pencil, Search, BookOpen, Bus, Building2, Boxes, AlertTriangle } from 'lucide-react';
import { useCollection } from '../../hooks/useDB';
import { insert, update, remove, logActivity } from '../../lib/db';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../components/ui/Toast';
import { useConfirm } from '../../components/ui/Confirm';
import { Modal } from '../../components/ui/Modal';
import { Field, Input, Select } from '../../components/ui/Field';
import { PageHeader, Card, Btn, EmptyState, StatCard } from '../../components/ui/Shared';
import { money } from '../../lib/utils';

// ============================ LIBRARY ============================
export function LibraryPage() {
  const books = useCollection<any>('library');
  const { user } = useAuth();
  const { notify } = useToast();
  const confirm = useConfirm();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [search, setSearch] = useState('');
  const [form, setForm] = useState<any>({ title: '', author: '', isbn: '', category: 'Textbook', total_copies: 1, available: 1 });

  const openNew = () => { setEditing(null); setForm({ title: '', author: '', isbn: '', category: 'Textbook', total_copies: 1, available: 1 }); setOpen(true); };
  const openEdit = (b: any) => { setEditing(b); setForm({ ...b }); setOpen(true); };
  const save = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.title) return notify('Book title required', 'error');
    const data = { ...form, total_copies: Number(form.total_copies), available: Number(form.available) };
    if (editing) { update('library', editing.id, data); notify('Book updated'); }
    else { const c = insert('library', data); logActivity(user!, `Added book ${form.title}`, 'library', c.id); notify('Book added'); }
    setOpen(false);
  };
  const del = async (b: any) => { if (!(await confirm({ message: `Delete "${b.title}"?`, danger: true, confirmText: 'Delete' }))) return; remove('library', b.id); notify('Deleted'); };

  const list = books.filter((b) => !search || b.title.toLowerCase().includes(search.toLowerCase()) || (b.author || '').toLowerCase().includes(search.toLowerCase()));
  const totalBooks = books.reduce((a, b) => a + (b.total_copies || 0), 0);
  const issued = books.reduce((a, b) => a + ((b.total_copies || 0) - (b.available || 0)), 0);

  return (
    <div>
      <PageHeader title="Library" subtitle="Book catalog, issue & return"
        action={<Btn onClick={openNew}><span className="flex items-center gap-2"><Plus className="h-4 w-4" /> Add Book</span></Btn>} />
      <div className="mb-6 grid gap-4 sm:grid-cols-3">
        <StatCard title="Total Titles" value={books.length} icon={BookOpen} color="from-indigo-500 to-indigo-600" />
        <StatCard title="Total Copies" value={totalBooks} icon={BookOpen} color="from-blue-500 to-blue-600" />
        <StatCard title="Issued" value={issued} icon={BookOpen} color="from-amber-500 to-amber-600" />
      </div>
      <Card>
        <div className="relative mb-4 max-w-xs">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search books..." className="w-full rounded-md border border-slate-300 py-2 pl-9 pr-3 text-sm focus:border-indigo-500 focus:outline-none" />
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="border-b border-slate-200 text-left text-slate-600">
              <th className="pb-3 font-medium">Title</th><th className="pb-3 font-medium">Author</th><th className="pb-3 font-medium">Category</th>
              <th className="pb-3 font-medium">Available</th><th className="pb-3 font-medium">Total</th><th className="pb-3"></th>
            </tr></thead>
            <tbody>
              {list.map((b) => (
                <tr key={b.id} className="border-b border-slate-100">
                  <td className="py-3 font-medium text-slate-900">{b.title}</td>
                  <td className="py-3 text-slate-600">{b.author || '-'}</td>
                  <td className="py-3 text-slate-600">{b.category}</td>
                  <td className="py-3"><span className={`rounded-full px-2 py-0.5 text-xs font-medium ${b.available > 0 ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'}`}>{b.available}</span></td>
                  <td className="py-3 text-slate-600">{b.total_copies}</td>
                  <td className="py-3 text-right"><div className="flex justify-end gap-1">
                    <button onClick={() => openEdit(b)} className="rounded p-1.5 text-blue-600 hover:bg-blue-50"><Pencil className="h-4 w-4" /></button>
                    <button onClick={() => del(b)} className="rounded p-1.5 text-rose-600 hover:bg-rose-50"><Trash2 className="h-4 w-4" /></button>
                  </div></td>
                </tr>
              ))}
            </tbody>
          </table>
          {list.length === 0 && <EmptyState message="No books in catalog" />}
        </div>
      </Card>
      <Modal open={open} onClose={() => setOpen(false)} title={editing ? 'Edit Book' : 'Add Book'}>
        <form onSubmit={save} className="space-y-4">
          <Field label="Title" required><Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} /></Field>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Author"><Input value={form.author} onChange={(e) => setForm({ ...form, author: e.target.value })} /></Field>
            <Field label="ISBN"><Input value={form.isbn} onChange={(e) => setForm({ ...form, isbn: e.target.value })} /></Field>
          </div>
          <Field label="Category"><Select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}><option>Textbook</option><option>Reference</option><option>Fiction</option><option>Magazine</option></Select></Field>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Total Copies"><Input type="number" value={form.total_copies} onChange={(e) => setForm({ ...form, total_copies: Number(e.target.value) })} /></Field>
            <Field label="Available"><Input type="number" value={form.available} onChange={(e) => setForm({ ...form, available: Number(e.target.value) })} /></Field>
          </div>
          <div className="flex justify-end gap-2 pt-2"><Btn variant="secondary" onClick={() => setOpen(false)}>Cancel</Btn><Btn type="submit">{editing ? 'Update' : 'Add'}</Btn></div>
        </form>
      </Modal>
    </div>
  );
}

// ============================ TRANSPORT ============================
export function TransportPage() {
  const routes = useCollection<any>('transport');
  const { user } = useAuth();
  const { notify } = useToast();
  const confirm = useConfirm();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [form, setForm] = useState<any>({ route_name: '', vehicle_no: '', driver_name: '', driver_phone: '', capacity: 30, students_assigned: 0, fee: 0 });

  const openNew = () => { setEditing(null); setForm({ route_name: '', vehicle_no: '', driver_name: '', driver_phone: '', capacity: 30, students_assigned: 0, fee: 0 }); setOpen(true); };
  const openEdit = (r: any) => { setEditing(r); setForm({ ...r }); setOpen(true); };
  const save = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.route_name) return notify('Route name required', 'error');
    const data = { ...form, capacity: Number(form.capacity), students_assigned: Number(form.students_assigned), fee: Number(form.fee) };
    if (editing) { update('transport', editing.id, data); notify('Route updated'); }
    else { const c = insert('transport', data); logActivity(user!, `Added route ${form.route_name}`, 'transport', c.id); notify('Route added'); }
    setOpen(false);
  };
  const del = async (r: any) => { if (!(await confirm({ message: `Delete "${r.route_name}"?`, danger: true, confirmText: 'Delete' }))) return; remove('transport', r.id); notify('Deleted'); };

  return (
    <div>
      <PageHeader title="Transport" subtitle="Routes, vehicles & drivers"
        action={<Btn onClick={openNew}><span className="flex items-center gap-2"><Plus className="h-4 w-4" /> Add Route</span></Btn>} />
      <div className="mb-6 grid gap-4 sm:grid-cols-3">
        <StatCard title="Total Routes" value={routes.length} icon={Bus} color="from-indigo-500 to-indigo-600" />
        <StatCard title="Students" value={routes.reduce((a, r) => a + (r.students_assigned || 0), 0)} icon={Bus} color="from-emerald-500 to-emerald-600" />
        <StatCard title="Capacity" value={routes.reduce((a, r) => a + (r.capacity || 0), 0)} icon={Bus} color="from-blue-500 to-blue-600" />
      </div>
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="border-b border-slate-200 text-left text-slate-600">
              <th className="pb-3 font-medium">Route</th><th className="pb-3 font-medium">Vehicle</th><th className="pb-3 font-medium">Driver</th>
              <th className="pb-3 font-medium">Phone</th><th className="pb-3 font-medium">Students</th><th className="pb-3 font-medium">Fee</th><th className="pb-3"></th>
            </tr></thead>
            <tbody>
              {routes.map((r) => (
                <tr key={r.id} className="border-b border-slate-100">
                  <td className="py-3 font-medium text-slate-900">{r.route_name}</td>
                  <td className="py-3 text-slate-600">{r.vehicle_no}</td>
                  <td className="py-3 text-slate-600">{r.driver_name}</td>
                  <td className="py-3 text-slate-600">{r.driver_phone}</td>
                  <td className="py-3 text-slate-600">{r.students_assigned}/{r.capacity}</td>
                  <td className="py-3 text-slate-600">{money(r.fee)}</td>
                  <td className="py-3 text-right"><div className="flex justify-end gap-1">
                    <button onClick={() => openEdit(r)} className="rounded p-1.5 text-blue-600 hover:bg-blue-50"><Pencil className="h-4 w-4" /></button>
                    <button onClick={() => del(r)} className="rounded p-1.5 text-rose-600 hover:bg-rose-50"><Trash2 className="h-4 w-4" /></button>
                  </div></td>
                </tr>
              ))}
            </tbody>
          </table>
          {routes.length === 0 && <EmptyState message="No routes configured" />}
        </div>
      </Card>
      <Modal open={open} onClose={() => setOpen(false)} title={editing ? 'Edit Route' : 'Add Route'}>
        <form onSubmit={save} className="space-y-4">
          <Field label="Route Name" required><Input value={form.route_name} onChange={(e) => setForm({ ...form, route_name: e.target.value })} /></Field>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Vehicle No"><Input value={form.vehicle_no} onChange={(e) => setForm({ ...form, vehicle_no: e.target.value })} /></Field>
            <Field label="Capacity"><Input type="number" value={form.capacity} onChange={(e) => setForm({ ...form, capacity: Number(e.target.value) })} /></Field>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Driver Name"><Input value={form.driver_name} onChange={(e) => setForm({ ...form, driver_name: e.target.value })} /></Field>
            <Field label="Driver Phone"><Input value={form.driver_phone} onChange={(e) => setForm({ ...form, driver_phone: e.target.value })} /></Field>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Students Assigned"><Input type="number" value={form.students_assigned} onChange={(e) => setForm({ ...form, students_assigned: Number(e.target.value) })} /></Field>
            <Field label="Monthly Fee (PKR)"><Input type="number" value={form.fee} onChange={(e) => setForm({ ...form, fee: Number(e.target.value) })} /></Field>
          </div>
          <div className="flex justify-end gap-2 pt-2"><Btn variant="secondary" onClick={() => setOpen(false)}>Cancel</Btn><Btn type="submit">{editing ? 'Update' : 'Add'}</Btn></div>
        </form>
      </Modal>
    </div>
  );
}

// ============================ HOSTEL ============================
export function HostelPage() {
  const rooms = useCollection<any>('hostel');
  const { user } = useAuth();
  const { notify } = useToast();
  const confirm = useConfirm();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [form, setForm] = useState<any>({ room_no: '', block: 'Block A', capacity: 4, occupied: 0, type: 'Boys', warden: '' });

  const openNew = () => { setEditing(null); setForm({ room_no: '', block: 'Block A', capacity: 4, occupied: 0, type: 'Boys', warden: '' }); setOpen(true); };
  const openEdit = (r: any) => { setEditing(r); setForm({ ...r }); setOpen(true); };
  const save = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.room_no) return notify('Room number required', 'error');
    const data = { ...form, capacity: Number(form.capacity), occupied: Number(form.occupied) };
    if (editing) { update('hostel', editing.id, data); notify('Room updated'); }
    else { const c = insert('hostel', data); logActivity(user!, `Added hostel room ${form.room_no}`, 'hostel', c.id); notify('Room added'); }
    setOpen(false);
  };
  const del = async (r: any) => { if (!(await confirm({ message: `Delete room ${r.room_no}?`, danger: true, confirmText: 'Delete' }))) return; remove('hostel', r.id); notify('Deleted'); };

  return (
    <div>
      <PageHeader title="Hostel" subtitle="Rooms & boarder management"
        action={<Btn onClick={openNew}><span className="flex items-center gap-2"><Plus className="h-4 w-4" /> Add Room</span></Btn>} />
      <div className="mb-6 grid gap-4 sm:grid-cols-3">
        <StatCard title="Total Rooms" value={rooms.length} icon={Building2} color="from-indigo-500 to-indigo-600" />
        <StatCard title="Occupied" value={rooms.reduce((a, r) => a + (r.occupied || 0), 0)} icon={Building2} color="from-emerald-500 to-emerald-600" />
        <StatCard title="Capacity" value={rooms.reduce((a, r) => a + (r.capacity || 0), 0)} icon={Building2} color="from-blue-500 to-blue-600" />
      </div>
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="border-b border-slate-200 text-left text-slate-600">
              <th className="pb-3 font-medium">Room</th><th className="pb-3 font-medium">Block</th><th className="pb-3 font-medium">Type</th>
              <th className="pb-3 font-medium">Occupancy</th><th className="pb-3 font-medium">Warden</th><th className="pb-3"></th>
            </tr></thead>
            <tbody>
              {rooms.map((r) => (
                <tr key={r.id} className="border-b border-slate-100">
                  <td className="py-3 font-medium text-slate-900">{r.room_no}</td>
                  <td className="py-3 text-slate-600">{r.block}</td>
                  <td className="py-3 text-slate-600">{r.type}</td>
                  <td className="py-3"><span className={`rounded-full px-2 py-0.5 text-xs font-medium ${r.occupied >= r.capacity ? 'bg-rose-100 text-rose-700' : 'bg-emerald-100 text-emerald-700'}`}>{r.occupied}/{r.capacity}</span></td>
                  <td className="py-3 text-slate-600">{r.warden || '-'}</td>
                  <td className="py-3 text-right"><div className="flex justify-end gap-1">
                    <button onClick={() => openEdit(r)} className="rounded p-1.5 text-blue-600 hover:bg-blue-50"><Pencil className="h-4 w-4" /></button>
                    <button onClick={() => del(r)} className="rounded p-1.5 text-rose-600 hover:bg-rose-50"><Trash2 className="h-4 w-4" /></button>
                  </div></td>
                </tr>
              ))}
            </tbody>
          </table>
          {rooms.length === 0 && <EmptyState message="No hostel rooms" />}
        </div>
      </Card>
      <Modal open={open} onClose={() => setOpen(false)} title={editing ? 'Edit Room' : 'Add Room'}>
        <form onSubmit={save} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <Field label="Room No" required><Input value={form.room_no} onChange={(e) => setForm({ ...form, room_no: e.target.value })} /></Field>
            <Field label="Block"><Select value={form.block} onChange={(e) => setForm({ ...form, block: e.target.value })}><option>Block A</option><option>Block B</option><option>Block C</option></Select></Field>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Type"><Select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}><option>Boys</option><option>Girls</option></Select></Field>
            <Field label="Warden"><Input value={form.warden} onChange={(e) => setForm({ ...form, warden: e.target.value })} /></Field>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Capacity"><Input type="number" value={form.capacity} onChange={(e) => setForm({ ...form, capacity: Number(e.target.value) })} /></Field>
            <Field label="Occupied"><Input type="number" value={form.occupied} onChange={(e) => setForm({ ...form, occupied: Number(e.target.value) })} /></Field>
          </div>
          <div className="flex justify-end gap-2 pt-2"><Btn variant="secondary" onClick={() => setOpen(false)}>Cancel</Btn><Btn type="submit">{editing ? 'Update' : 'Add'}</Btn></div>
        </form>
      </Modal>
    </div>
  );
}

// ============================ INVENTORY ============================
export function InventoryPage() {
  const items = useCollection<any>('inventory');
  const { user } = useAuth();
  const { notify } = useToast();
  const confirm = useConfirm();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [form, setForm] = useState<any>({ item_name: '', category: 'Stationery', quantity: 0, unit: 'pcs', reorder_level: 10, location: '' });

  const openNew = () => { setEditing(null); setForm({ item_name: '', category: 'Stationery', quantity: 0, unit: 'pcs', reorder_level: 10, location: '' }); setOpen(true); };
  const openEdit = (i: any) => { setEditing(i); setForm({ ...i }); setOpen(true); };
  const save = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.item_name) return notify('Item name required', 'error');
    const data = { ...form, quantity: Number(form.quantity), reorder_level: Number(form.reorder_level) };
    if (editing) { update('inventory', editing.id, data); notify('Item updated'); }
    else { const c = insert('inventory', data); logActivity(user!, `Added inventory ${form.item_name}`, 'inventory', c.id); notify('Item added'); }
    setOpen(false);
  };
  const del = async (i: any) => { if (!(await confirm({ message: `Delete "${i.item_name}"?`, danger: true, confirmText: 'Delete' }))) return; remove('inventory', i.id); notify('Deleted'); };

  const lowStock = items.filter((i) => i.quantity <= i.reorder_level).length;

  return (
    <div>
      <PageHeader title="Inventory" subtitle="Assets & stock management"
        action={<Btn onClick={openNew}><span className="flex items-center gap-2"><Plus className="h-4 w-4" /> Add Item</span></Btn>} />
      <div className="mb-6 grid gap-4 sm:grid-cols-3">
        <StatCard title="Total Items" value={items.length} icon={Boxes} color="from-indigo-500 to-indigo-600" />
        <StatCard title="Total Units" value={items.reduce((a, i) => a + (i.quantity || 0), 0)} icon={Boxes} color="from-blue-500 to-blue-600" />
        <StatCard title="Low Stock" value={lowStock} icon={AlertTriangle} color="from-rose-500 to-rose-600" />
      </div>
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="border-b border-slate-200 text-left text-slate-600">
              <th className="pb-3 font-medium">Item</th><th className="pb-3 font-medium">Category</th><th className="pb-3 font-medium">Quantity</th>
              <th className="pb-3 font-medium">Location</th><th className="pb-3 font-medium">Status</th><th className="pb-3"></th>
            </tr></thead>
            <tbody>
              {items.map((i) => (
                <tr key={i.id} className="border-b border-slate-100">
                  <td className="py-3 font-medium text-slate-900">{i.item_name}</td>
                  <td className="py-3 text-slate-600">{i.category}</td>
                  <td className="py-3 text-slate-600">{i.quantity} {i.unit}</td>
                  <td className="py-3 text-slate-600">{i.location || '-'}</td>
                  <td className="py-3">{i.quantity <= i.reorder_level ? <span className="rounded-full bg-rose-100 px-2 py-0.5 text-xs font-medium text-rose-700">Low Stock</span> : <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-xs font-medium text-emerald-700">In Stock</span>}</td>
                  <td className="py-3 text-right"><div className="flex justify-end gap-1">
                    <button onClick={() => openEdit(i)} className="rounded p-1.5 text-blue-600 hover:bg-blue-50"><Pencil className="h-4 w-4" /></button>
                    <button onClick={() => del(i)} className="rounded p-1.5 text-rose-600 hover:bg-rose-50"><Trash2 className="h-4 w-4" /></button>
                  </div></td>
                </tr>
              ))}
            </tbody>
          </table>
          {items.length === 0 && <EmptyState message="No inventory items" />}
        </div>
      </Card>
      <Modal open={open} onClose={() => setOpen(false)} title={editing ? 'Edit Item' : 'Add Item'}>
        <form onSubmit={save} className="space-y-4">
          <Field label="Item Name" required><Input value={form.item_name} onChange={(e) => setForm({ ...form, item_name: e.target.value })} /></Field>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Category"><Select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}><option>Stationery</option><option>Electronics</option><option>Furniture</option><option>Medical</option><option>Sports</option><option>Other</option></Select></Field>
            <Field label="Location"><Input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} /></Field>
          </div>
          <div className="grid grid-cols-3 gap-4">
            <Field label="Quantity"><Input type="number" value={form.quantity} onChange={(e) => setForm({ ...form, quantity: Number(e.target.value) })} /></Field>
            <Field label="Unit"><Input value={form.unit} onChange={(e) => setForm({ ...form, unit: e.target.value })} /></Field>
            <Field label="Reorder At"><Input type="number" value={form.reorder_level} onChange={(e) => setForm({ ...form, reorder_level: Number(e.target.value) })} /></Field>
          </div>
          <div className="flex justify-end gap-2 pt-2"><Btn variant="secondary" onClick={() => setOpen(false)}>Cancel</Btn><Btn type="submit">{editing ? 'Update' : 'Add'}</Btn></div>
        </form>
      </Modal>
    </div>
  );
}
