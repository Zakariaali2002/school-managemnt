import { useState } from 'react';
import { Plus, FileText, Layers, Bell } from 'lucide-react';
import { useCollection } from '../../hooks/useDB';
import { insert, update, getAll, getSettings, logActivity, uid } from '../../lib/db';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../components/ui/Toast';
import { Modal } from '../../components/ui/Modal';
import { Field, Input, Select } from '../../components/ui/Field';
import { PageHeader, Card, Btn, EmptyState } from '../../components/ui/Shared';
import { StatusBadge, money, fmtDate, printDocument, qrSvgString, barcodeSvgString } from '../../lib/utils';
import { notifyParent } from '../../lib/messaging';

export function FeeVouchersPage() {
  const vouchers = useCollection<any>('feeVouchers');
  const students = useCollection<any>('students');
  const classes = useCollection<any>('classes');
  const { user } = useAuth();
  const { notify } = useToast();
  const [bulkOpen, setBulkOpen] = useState(false);
  const [oneOpen, setOneOpen] = useState(false);
  const [filterStatus, setFilterStatus] = useState('all');
  const [classFilter, setClassFilter] = useState('all');
  const [bulk, setBulk] = useState({ class_id: classes[0]?.id || '', amount: 12500, month: new Date().getMonth() + 1, year: new Date().getFullYear(), due_date: '' });
  const [one, setOne] = useState({ student_id: students[0]?.id || '', amount: 12500, month: new Date().getMonth() + 1, year: new Date().getFullYear(), due_date: '' });

  const studentName = (id: string) => students.find((s) => s.id === id)?.name || '-';
  const studentClass = (id: string) => { const st = students.find((s) => s.id === id); return classes.find((c) => c.id === st?.class_id)?.name || '-'; };

  const nextVoucherNo = () => 'V-' + new Date().getFullYear() + '-' + String(getAll('feeVouchers').length + 1).padStart(4, '0');

  const generateBulk = (e: React.FormEvent) => {
    e.preventDefault();
    const classStudents = students.filter((s) => s.class_id === bulk.class_id);
    if (classStudents.length === 0) return notify('No students in this class', 'error');
    let count = 0;
    classStudents.forEach((s) => {
      const dupe = vouchers.find((v) => v.student_id === s.id && v.month === Number(bulk.month) && v.year === Number(bulk.year));
      if (dupe) return;
      insert('feeVouchers', {
        id: uid(), student_id: s.id, fee_type_id: '', voucher_no: 'V-' + new Date().getFullYear() + '-' + uid().slice(0, 4),
        month: Number(bulk.month), year: Number(bulk.year), amount: Number(bulk.amount), due_date: bulk.due_date || `${bulk.year}-${String(bulk.month).padStart(2, '0')}-10`, status: 'unpaid',
      });
      count++;
    });
    logActivity(user!, `Generated ${count} fee vouchers for ${classes.find((c) => c.id === bulk.class_id)?.name}`, 'fee', bulk.class_id);
    notify(`${count} voucher(s) generated`);
    setBulkOpen(false);
  };

  const generateOne = (e: React.FormEvent) => {
    e.preventDefault();
    insert('feeVouchers', {
      student_id: one.student_id, fee_type_id: '', voucher_no: nextVoucherNo(),
      month: Number(one.month), year: Number(one.year), amount: Number(one.amount),
      due_date: one.due_date || `${one.year}-${String(one.month).padStart(2, '0')}-10`, status: 'unpaid',
    });
    logActivity(user!, `Generated voucher for ${studentName(one.student_id)}`, 'fee');
    notify('Voucher generated');
    setOneOpen(false);
  };

  const downloadVoucher = (v: any) => {
    const s = getSettings();
    const student = students.find((x) => x.id === v.student_id);
    // Fee breakdown: derive components from the amount (demo split) + outstanding
    const outstanding = vouchers
      .filter((x) => x.student_id === v.student_id && x.status === 'overdue' && x.id !== v.id)
      .reduce((a, x) => a + x.amount, 0);
    const isOverdue = v.status !== 'paid' && new Date(v.due_date) < new Date();
    const fine = isOverdue ? (s.late_fee || 500) : 0;
    const tuition = Math.round(v.amount * 0.7);
    const transport = Math.round(v.amount * 0.2);
    const examFee = v.amount - tuition - transport;
    const total = v.amount + fine + outstanding;
    const qr = qrSvgString(`PAY|${v.voucher_no}|${total}|${student?.student_code || ''}`, 96);
    const barcode = barcodeSvgString(v.voucher_no, 240, 50);

    printDocument(`Fee Voucher - ${v.voucher_no}`, `
      <div style="max-width:520px; border:2px solid #4f46e5; border-radius:12px; overflow:hidden;">
        <div style="background:linear-gradient(to right,#4f46e5,#7c3aed); color:#fff; padding:14px; display:flex; align-items:center; gap:12px;">
          <div style="width:46px;height:46px;border-radius:10px;background:rgba(255,255,255,.2);display:flex;align-items:center;justify-content:center;font-size:22px;">🎓</div>
          <div style="flex:1;">
            <div style="font-size:17px;font-weight:bold;">${s.school_name}</div>
            <div style="font-size:11px;opacity:.9;">${s.address || ''} · ${s.phone || ''}</div>
          </div>
          <div style="text-align:right;">
            <div style="font-size:13px;font-weight:bold;">FEE VOUCHER</div>
            <div style="font-size:11px;opacity:.9;">${v.voucher_no}</div>
          </div>
        </div>
        <div style="padding:16px;">
          <div style="display:flex;justify-content:space-between;">
            <div style="font-size:13px;">
              <div><b>Student:</b> ${studentName(v.student_id)}</div>
              <div><b>Class:</b> ${studentClass(v.student_id)}</div>
              <div><b>Code:</b> ${student?.student_code || '-'}</div>
              <div><b>Period:</b> ${v.month}/${v.year}</div>
              <div style="color:#dc2626;"><b>Due Date:</b> ${fmtDate(v.due_date)}</div>
            </div>
            <div style="text-align:center;">${qr}<div style="font-size:9px;color:#64748b;">Scan to pay</div></div>
          </div>
          <table style="width:100%;border-collapse:collapse;margin-top:14px;font-size:13px;">
            <tr style="background:#f1f5f9;"><th style="text-align:left;padding:6px 10px;">Description</th><th style="text-align:right;padding:6px 10px;">Amount</th></tr>
            <tr><td style="padding:6px 10px;border-bottom:1px solid #e2e8f0;">Tuition Fee</td><td style="text-align:right;padding:6px 10px;border-bottom:1px solid #e2e8f0;">${money(tuition)}</td></tr>
            <tr><td style="padding:6px 10px;border-bottom:1px solid #e2e8f0;">Transport Fee</td><td style="text-align:right;padding:6px 10px;border-bottom:1px solid #e2e8f0;">${money(transport)}</td></tr>
            <tr><td style="padding:6px 10px;border-bottom:1px solid #e2e8f0;">Exam Fee</td><td style="text-align:right;padding:6px 10px;border-bottom:1px solid #e2e8f0;">${money(examFee)}</td></tr>
            <tr><td style="padding:6px 10px;border-bottom:1px solid #e2e8f0;">Previous Outstanding</td><td style="text-align:right;padding:6px 10px;border-bottom:1px solid #e2e8f0;">${money(outstanding)}</td></tr>
            <tr><td style="padding:6px 10px;border-bottom:1px solid #e2e8f0;color:#dc2626;">Late Fine ${isOverdue ? '(applied)' : '(if paid after due date)'}</td><td style="text-align:right;padding:6px 10px;border-bottom:1px solid #e2e8f0;color:#dc2626;">${money(fine)}</td></tr>
            <tr style="background:#eef2ff;font-weight:bold;font-size:15px;"><td style="padding:8px 10px;">TOTAL PAYABLE</td><td style="text-align:right;padding:8px 10px;">${money(total)}</td></tr>
          </table>
          <div style="margin-top:14px;border:1px dashed #cbd5e1;border-radius:8px;padding:10px;font-size:12px;">
            <b style="color:#4f46e5;">💳 Payment Options</b>
            <div style="margin-top:4px;display:grid;grid-template-columns:1fr 1fr;gap:4px;">
              <div>📱 EasyPaisa: <b>${s.easypaisa_number || '-'}</b></div>
              <div>📱 JazzCash: <b>${s.jazzcash_number || '-'}</b></div>
              <div>🏦 Bank: <b>${s.bank_name || '-'}</b></div>
              <div>A/C: <b>${s.bank_account_number || '-'}</b></div>
              <div style="grid-column:span 2;">IBAN: <b>${s.bank_iban || '-'}</b></div>
            </div>
            <div style="margin-top:8px;text-align:center;">
              <span style="display:inline-block;background:#16a34a;color:#fff;padding:6px 18px;border-radius:6px;font-weight:bold;">PAY ONLINE</span>
            </div>
          </div>
          <div style="margin-top:12px;text-align:center;">${barcode}</div>
          <div style="margin-top:10px;display:flex;justify-content:space-between;font-size:11px;color:#64748b;">
            <div style="border-top:1px solid #475569;padding-top:4px;width:45%;text-align:center;">Bank Stamp</div>
            <div style="border-top:1px solid #475569;padding-top:4px;width:45%;text-align:center;">Accountant</div>
          </div>
        </div>
      </div>
    `);
  };

  // Send fee reminder to parent via SMS + WhatsApp.
  const sendReminder = (v: any) => {
    const student = students.find((x) => x.id === v.student_id);
    const days = Math.ceil((new Date(v.due_date).getTime() - Date.now()) / 86400000);
    const when = days > 0 ? `due in ${days} day(s)` : days === 0 ? 'due today' : `overdue by ${Math.abs(days)} day(s)`;
    notifyParent(
      studentName(v.student_id),
      student?.phone || '',
      'Fee Reminder',
      `Dear Parent, fee voucher ${v.voucher_no} (${money(v.amount)}) for ${studentName(v.student_id)} is ${when}. Due date: ${fmtDate(v.due_date)}. Please pay via EasyPaisa/JazzCash/Bank.`,
      'fee', v.id,
    );
    notify('Reminder sent via SMS + WhatsApp');
  };

  // Bulk auto-reminders to all unpaid/overdue vouchers.
  const sendAllReminders = () => {
    const pending = vouchers.filter((v) => v.status !== 'paid');
    if (pending.length === 0) return notify('No pending vouchers', 'info');
    pending.forEach((v) => sendReminder(v));
    logActivity(user!, `Sent ${pending.length} fee reminders (SMS + WhatsApp)`, 'fee');
    notify(`${pending.length} reminders sent`);
  };

  // auto-mark overdue
  const today = new Date().toISOString().slice(0, 10);
  vouchers.forEach((v) => { if (v.status === 'unpaid' && v.due_date < today) update('feeVouchers', v.id, { status: 'overdue' }); });

  const filtered = vouchers.filter((v) => {
    const ms = filterStatus === 'all' || v.status === filterStatus;
    const mc = classFilter === 'all' || students.find((s) => s.id === v.student_id)?.class_id === classFilter;
    return ms && mc;
  });

  return (
    <div>
      <PageHeader title="Fee Vouchers" subtitle="Generate vouchers, send reminders (SMS + WhatsApp)"
        action={<div className="flex flex-wrap gap-2">
          <Btn variant="secondary" onClick={sendAllReminders}><span className="flex items-center gap-2"><Bell className="h-4 w-4" /> Send Reminders</span></Btn>
          <Btn variant="secondary" onClick={() => setOneOpen(true)}><span className="flex items-center gap-2"><Plus className="h-4 w-4" /> Single</span></Btn>
          <Btn onClick={() => setBulkOpen(true)}><span className="flex items-center gap-2"><Layers className="h-4 w-4" /> Bulk Generate</span></Btn>
        </div>} />

      <Card>
        <div className="mb-4 flex flex-wrap gap-2">
          {['all', 'paid', 'unpaid', 'overdue'].map((st) => (
            <button key={st} onClick={() => setFilterStatus(st)}
              className={`rounded-full px-3 py-1 text-xs font-medium capitalize ${filterStatus === st ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}>{st}</button>
          ))}
          <Select value={classFilter} onChange={(e) => setClassFilter(e.target.value)} className="ml-auto max-w-[180px]">
            <option value="all">All Classes</option>
            {classes.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </Select>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-left text-slate-600">
                <th className="pb-3 font-medium">Voucher</th><th className="pb-3 font-medium">Student</th>
                <th className="pb-3 font-medium">Period</th><th className="pb-3 font-medium">Amount</th>
                <th className="pb-3 font-medium">Due</th><th className="pb-3 font-medium">Status</th><th className="pb-3 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((v) => (
                <tr key={v.id} className="border-b border-slate-100">
                  <td className="py-3 text-slate-600">{v.voucher_no}</td>
                  <td className="py-3 font-medium text-slate-900">{studentName(v.student_id)}</td>
                  <td className="py-3 text-slate-600">{v.month}/{v.year}</td>
                  <td className="py-3 text-slate-600">{money(v.amount)}</td>
                  <td className="py-3 text-slate-500">{fmtDate(v.due_date)}</td>
                  <td className="py-3"><StatusBadge status={v.status} /></td>
                  <td className="py-3">
                    <div className="flex gap-1">
                      <button onClick={() => downloadVoucher(v)} className="rounded p-1.5 text-green-600 hover:bg-green-50" title="Download Voucher PDF"><FileText className="h-4 w-4" /></button>
                      {v.status !== 'paid' && <button onClick={() => sendReminder(v)} className="rounded p-1.5 text-amber-600 hover:bg-amber-50" title="Send Reminder (SMS + WhatsApp)"><Bell className="h-4 w-4" /></button>}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filtered.length === 0 && <EmptyState message="No vouchers found" />}
        </div>
      </Card>

      <Modal open={bulkOpen} onClose={() => setBulkOpen(false)} title="Bulk Generate Vouchers">
        <form onSubmit={generateBulk} className="space-y-4">
          <Field label="Class" required>
            <Select value={bulk.class_id} onChange={(e) => setBulk({ ...bulk, class_id: e.target.value })}>
              {classes.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </Select>
          </Field>
          <Field label="Amount (PKR)" required><Input type="number" value={bulk.amount} onChange={(e) => setBulk({ ...bulk, amount: Number(e.target.value) })} /></Field>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Month"><Input type="number" min={1} max={12} value={bulk.month} onChange={(e) => setBulk({ ...bulk, month: Number(e.target.value) })} /></Field>
            <Field label="Year"><Input type="number" value={bulk.year} onChange={(e) => setBulk({ ...bulk, year: Number(e.target.value) })} /></Field>
          </div>
          <Field label="Due Date"><Input type="date" value={bulk.due_date} onChange={(e) => setBulk({ ...bulk, due_date: e.target.value })} /></Field>
          <div className="flex justify-end gap-2 pt-2"><Btn variant="secondary" onClick={() => setBulkOpen(false)}>Cancel</Btn><Btn type="submit">Generate</Btn></div>
        </form>
      </Modal>

      <Modal open={oneOpen} onClose={() => setOneOpen(false)} title="Single Voucher">
        <form onSubmit={generateOne} className="space-y-4">
          <Field label="Student" required>
            <Select value={one.student_id} onChange={(e) => setOne({ ...one, student_id: e.target.value })}>
              {students.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </Select>
          </Field>
          <Field label="Amount (PKR)" required><Input type="number" value={one.amount} onChange={(e) => setOne({ ...one, amount: Number(e.target.value) })} /></Field>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Month"><Input type="number" min={1} max={12} value={one.month} onChange={(e) => setOne({ ...one, month: Number(e.target.value) })} /></Field>
            <Field label="Year"><Input type="number" value={one.year} onChange={(e) => setOne({ ...one, year: Number(e.target.value) })} /></Field>
          </div>
          <Field label="Due Date"><Input type="date" value={one.due_date} onChange={(e) => setOne({ ...one, due_date: e.target.value })} /></Field>
          <div className="flex justify-end gap-2 pt-2"><Btn variant="secondary" onClick={() => setOneOpen(false)}>Cancel</Btn><Btn type="submit">Generate</Btn></div>
        </form>
      </Modal>
    </div>
  );
}

export function PaymentsPage() {
  const vouchers = useCollection<any>('feeVouchers');
  const payments = useCollection<any>('feePayments');
  const students = useCollection<any>('students');
  const { user } = useAuth();
  const { notify } = useToast();
  const settings = getSettings();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ voucher_id: '', amount_paid: 0, late_fee: 0, discount: 0 });

  const unpaid = vouchers.filter((v) => v.status !== 'paid');
  const studentName = (id: string) => students.find((s) => s.id === id)?.name || '-';

  const openPay = (voucherId?: string) => {
    const v = voucherId ? vouchers.find((x) => x.id === voucherId) : unpaid[0];
    setForm({ voucher_id: v?.id || '', amount_paid: v?.amount || 0, late_fee: 0, discount: 0 });
    setOpen(true);
  };

  const record = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.voucher_id) return notify('Select a voucher', 'error');
    const receiptNo = 'R-' + new Date().getFullYear() + '-' + String(payments.length + 1).padStart(4, '0');
    insert('feePayments', { ...form, amount_paid: Number(form.amount_paid), late_fee: Number(form.late_fee), discount: Number(form.discount), receipt_no: receiptNo, paid_at: new Date().toISOString().slice(0, 10) });
    update('feeVouchers', form.voucher_id, { status: 'paid' });
    const v = vouchers.find((x) => x.id === form.voucher_id);
    logActivity(user!, `Recorded payment for ${studentName(v?.student_id)}`, 'payment', form.voucher_id);
    notify('Payment recorded');
    setOpen(false);
  };

  const receipt = (p: any) => {
    const v = vouchers.find((x) => x.id === p.voucher_id);
    printDocument(`Receipt - ${p.receipt_no}`, `
      <div class="title">Fee Payment Receipt</div>
      <div class="row"><span class="label">Receipt No</span><span class="value">${p.receipt_no}</span></div>
      <div class="row"><span class="label">Student</span><span class="value">${studentName(v?.student_id)}</span></div>
      <div class="row"><span class="label">Voucher</span><span class="value">${v?.voucher_no || '-'}</span></div>
      <div class="row"><span class="label">Amount Paid</span><span class="value">${money(p.amount_paid)}</span></div>
      <div class="row"><span class="label">Late Fee</span><span class="value">${money(p.late_fee)}</span></div>
      <div class="row"><span class="label">Discount</span><span class="value">${money(p.discount)}</span></div>
      <div class="row"><span class="label">Paid On</span><span class="value">${fmtDate(p.paid_at)}</span></div>
      <div class="signature"><div class="sign-box">Received By</div><div class="sign-box">Authorized Signature</div></div>
    `);
  };

  return (
    <div>
      <PageHeader title="Fee Payments" subtitle="Record collections and print receipts"
        action={<Btn onClick={() => openPay()}><span className="flex items-center gap-2"><Plus className="h-4 w-4" /> Record Payment</span></Btn>} />

      <div className="grid gap-6 lg:grid-cols-2">
        <Card title="Pending Vouchers">
          <div className="space-y-2">
            {unpaid.map((v) => (
              <div key={v.id} className="flex items-center justify-between rounded-lg bg-slate-50 p-3">
                <div>
                  <p className="text-sm font-medium text-slate-900">{studentName(v.student_id)}</p>
                  <p className="text-xs text-slate-500">{v.voucher_no} · {money(v.amount)} · <StatusBadge status={v.status} /></p>
                </div>
                <Btn size="sm" onClick={() => openPay(v.id)}>Collect</Btn>
              </div>
            ))}
            {unpaid.length === 0 && <EmptyState message="All fees collected" />}
          </div>
        </Card>

        <Card title="Recent Payments">
          <div className="space-y-2">
            {payments.slice().reverse().map((p) => {
              const v = vouchers.find((x) => x.id === p.voucher_id);
              return (
                <div key={p.id} className="flex items-center justify-between rounded-lg bg-slate-50 p-3">
                  <div>
                    <p className="text-sm font-medium text-slate-900">{studentName(v?.student_id)}</p>
                    <p className="text-xs text-slate-500">{p.receipt_no} · {money(p.amount_paid)} · {fmtDate(p.paid_at)}</p>
                  </div>
                  <button onClick={() => receipt(p)} className="rounded p-1.5 text-green-600 hover:bg-green-50" title="Print receipt"><FileText className="h-4 w-4" /></button>
                </div>
              );
            })}
            {payments.length === 0 && <EmptyState message="No payments recorded" />}
          </div>
        </Card>
      </div>

      <Modal open={open} onClose={() => setOpen(false)} title="Record Fee Payment">
        <form onSubmit={record} className="space-y-4">
          <Field label="Voucher" required>
            <Select value={form.voucher_id} onChange={(e) => { const v = vouchers.find((x) => x.id === e.target.value); setForm({ ...form, voucher_id: e.target.value, amount_paid: v?.amount || 0 }); }}>
              <option value="">Select voucher...</option>
              {unpaid.map((v) => <option key={v.id} value={v.id}>{studentName(v.student_id)} - {v.voucher_no} ({money(v.amount)})</option>)}
            </Select>
          </Field>
          <Field label="Amount Paid (PKR)" required><Input type="number" value={form.amount_paid} onChange={(e) => setForm({ ...form, amount_paid: Number(e.target.value) })} /></Field>
          <div className="grid grid-cols-2 gap-4">
            <Field label={`Late Fee (default ${settings.late_fee})`}><Input type="number" value={form.late_fee} onChange={(e) => setForm({ ...form, late_fee: Number(e.target.value) })} /></Field>
            <Field label="Discount"><Input type="number" value={form.discount} onChange={(e) => setForm({ ...form, discount: Number(e.target.value) })} /></Field>
          </div>
          <div className="flex justify-end gap-2 pt-2"><Btn variant="secondary" onClick={() => setOpen(false)}>Cancel</Btn><Btn variant="success" type="submit">Record & Generate Receipt</Btn></div>
        </form>
      </Modal>
    </div>
  );
}
