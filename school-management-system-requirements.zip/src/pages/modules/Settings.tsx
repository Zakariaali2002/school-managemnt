import { useState } from 'react';
import { RotateCcw } from 'lucide-react';
import { getSettings, updateSettings, resetDB, logActivity } from '../../lib/db';
import { useDBVersion } from '../../hooks/useDB';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../components/ui/Toast';
import { useConfirm } from '../../components/ui/Confirm';
import { Field, Input } from '../../components/ui/Field';
import { PageHeader, Card, Btn } from '../../components/ui/Shared';

export function SettingsPage() {
  useDBVersion();
  const { user } = useAuth();
  const { notify } = useToast();
  const confirm = useConfirm();
  const [form, setForm] = useState({ ...getSettings() });

  const save = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings({ ...form, late_fee: Number(form.late_fee), monthly_target: Number(form.monthly_target), max_doc_size_mb: Number(form.max_doc_size_mb) });
    logActivity(user!, 'Updated system settings', 'settings');
    notify('Settings saved');
  };

  const reset = async () => {
    const ok = await confirm({ message: 'Reset all data to defaults? This will erase all changes and cannot be undone.', danger: true, confirmText: 'Reset Everything' });
    if (!ok) return;
    resetDB();
    notify('Database reset to defaults');
    setTimeout(() => window.location.reload(), 600);
  };

  return (
    <div>
      <PageHeader title="System Settings" subtitle="Configure school information and defaults" />
      <div className="grid gap-6 lg:grid-cols-2">
        <Card title="School Information">
          <form onSubmit={save} className="space-y-4">
            <Field label="School Name"><Input value={form.school_name} onChange={(e) => setForm({ ...form, school_name: e.target.value })} /></Field>
            <Field label="Academic Year"><Input value={form.academic_year} onChange={(e) => setForm({ ...form, academic_year: e.target.value })} /></Field>
            <Field label="Address"><Input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} /></Field>
            <div className="grid grid-cols-2 gap-4">
              <Field label="Phone"><Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></Field>
              <Field label="Email"><Input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></Field>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <Field label="Currency"><Input value={form.currency} onChange={(e) => setForm({ ...form, currency: e.target.value })} /></Field>
              <Field label="Default Late Fee"><Input type="number" value={form.late_fee} onChange={(e) => setForm({ ...form, late_fee: e.target.value })} /></Field>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <Field label="Monthly Fee Target (PKR)"><Input type="number" value={form.monthly_target || 0} onChange={(e) => setForm({ ...form, monthly_target: e.target.value })} /></Field>
              <Field label="Max Document Size (MB)"><Input type="number" value={form.max_doc_size_mb || 5} onChange={(e) => setForm({ ...form, max_doc_size_mb: e.target.value })} /></Field>
            </div>
            <Btn type="submit">Save Settings</Btn>
          </form>
        </Card>

        <Card title="Data Management">
          <p className="text-sm text-slate-600">All data is stored locally in your browser. You can reset everything back to the seeded demo data.</p>
          <div className="mt-4">
            <Btn variant="danger" onClick={reset}><span className="flex items-center gap-2"><RotateCcw className="h-4 w-4" /> Reset All Data</span></Btn>
          </div>
        </Card>
      </div>
    </div>
  );
}
