import { useState } from 'react';
import { Plus, Trash2, Send, Bell, GitBranch, MessageSquare, Check, CheckCheck } from 'lucide-react';
import { useCollection } from '../../hooks/useDB';
import { insert, update, remove, logActivity } from '../../lib/db';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../components/ui/Toast';
import { useConfirm } from '../../components/ui/Confirm';
import { Modal } from '../../components/ui/Modal';
import { Field, Input, Select, Textarea } from '../../components/ui/Field';
import { PageHeader, Card, Btn, EmptyState, StatCard } from '../../components/ui/Shared';
import { fmtDate } from '../../lib/utils';

// ============================ COMMUNICATION / SMS ============================
export function CommunicationPage() {
  const messages = useCollection<any>('communication');
  const { user } = useAuth();
  const { notify } = useToast();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<any>({ title: '', message: '', audience: 'parent', channel: 'SMS' });

  const audienceCounts: Record<string, number> = { parent: 320, student: 845, teacher: 42, all: 1207 };

  const send = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.title || !form.message) return notify('Title and message required', 'error');
    const recipients = audienceCounts[form.audience] || 0;
    insert('communication', { ...form, sent_by: user!.id, sent_at: new Date().toISOString(), recipients });
    logActivity(user!, `Sent ${form.channel} "${form.title}" to ${form.audience}`, 'communication');
    notify(`${form.channel} sent to ${recipients} recipients`);
    setOpen(false);
    setForm({ title: '', message: '', audience: 'parent', channel: 'SMS' });
  };

  return (
    <div>
      <PageHeader title="Communication / SMS" subtitle="Send bulk SMS & email campaigns"
        action={<Btn onClick={() => setOpen(true)}><span className="flex items-center gap-2"><Send className="h-4 w-4" /> New Campaign</span></Btn>} />
      <div className="mb-6 grid gap-4 sm:grid-cols-3">
        <StatCard title="Campaigns Sent" value={messages.length} icon={MessageSquare} color="from-indigo-500 to-indigo-600" />
        <StatCard title="Total Reach" value={messages.reduce((a, m) => a + (m.recipients || 0), 0)} icon={Send} color="from-emerald-500 to-emerald-600" />
        <StatCard title="SMS Sent" value={messages.filter((m) => m.channel === 'SMS').length} icon={MessageSquare} color="from-blue-500 to-blue-600" />
      </div>
      <Card title="Sent Campaigns">
        <div className="space-y-3">
          {messages.slice().reverse().map((m) => (
            <div key={m.id} className="rounded-xl border border-slate-100 bg-slate-50/50 p-4">
              <div className="flex items-center justify-between">
                <p className="font-semibold text-slate-900">{m.title}</p>
                <span className="rounded-full bg-indigo-100 px-2 py-0.5 text-xs font-medium text-indigo-700">{m.channel}</span>
              </div>
              <p className="mt-1 text-sm text-slate-600">{m.message}</p>
              <p className="mt-2 text-xs text-slate-400">To: {m.audience} · {m.recipients} recipients · {fmtDate(m.sent_at)}</p>
            </div>
          ))}
          {messages.length === 0 && <EmptyState message="No campaigns sent yet" />}
        </div>
      </Card>
      <Modal open={open} onClose={() => setOpen(false)} title="New Communication">
        <form onSubmit={send} className="space-y-4">
          <Field label="Title" required><Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} /></Field>
          <Field label="Message" required><Textarea rows={4} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} /></Field>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Audience"><Select value={form.audience} onChange={(e) => setForm({ ...form, audience: e.target.value })}><option value="parent">Parents</option><option value="student">Students</option><option value="teacher">Teachers</option><option value="all">Everyone</option></Select></Field>
            <Field label="Channel"><Select value={form.channel} onChange={(e) => setForm({ ...form, channel: e.target.value })}><option>SMS</option><option>Email</option><option>App Push</option></Select></Field>
          </div>
          <p className="text-xs text-slate-400">Will reach approx {audienceCounts[form.audience]} recipients.</p>
          <div className="flex justify-end gap-2 pt-2"><Btn variant="secondary" onClick={() => setOpen(false)}>Cancel</Btn><Btn type="submit"><span className="flex items-center gap-2"><Send className="h-4 w-4" /> Send</span></Btn></div>
        </form>
      </Modal>
    </div>
  );
}

// ============================ NOTIFICATIONS ============================
export function NotificationsPage() {
  const notifications = useCollection<any>('notifications');
  const { notify } = useToast();

  const markRead = (n: any) => update('notifications', n.id, { is_read: true });
  const markAllRead = () => {
    notifications.filter((n) => !n.is_read).forEach((n) => update('notifications', n.id, { is_read: true }));
    notify('All marked as read');
  };
  const tones: Record<string, string> = { info: 'bg-blue-100 text-blue-700', success: 'bg-emerald-100 text-emerald-700', warning: 'bg-amber-100 text-amber-700', error: 'bg-rose-100 text-rose-700' };
  const unread = notifications.filter((n) => !n.is_read).length;

  return (
    <div>
      <PageHeader title="Notifications" subtitle="System notifications center"
        action={unread > 0 ? <Btn variant="secondary" onClick={markAllRead}><span className="flex items-center gap-2"><CheckCheck className="h-4 w-4" /> Mark all read</span></Btn> : undefined} />
      <div className="mb-6 grid gap-4 sm:grid-cols-2">
        <StatCard title="Total" value={notifications.length} icon={Bell} color="from-indigo-500 to-indigo-600" />
        <StatCard title="Unread" value={unread} icon={Bell} color="from-rose-500 to-rose-600" />
      </div>
      <Card>
        <div className="space-y-2">
          {notifications.slice().reverse().map((n) => (
            <div key={n.id} className={`flex items-center gap-3 rounded-xl p-4 ${n.is_read ? 'bg-slate-50' : 'bg-indigo-50/60 ring-1 ring-indigo-100'}`}>
              <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${tones[n.type] || tones.info}`}>{n.type}</span>
              <div className="flex-1">
                <p className="text-sm font-semibold text-slate-900">{n.title}</p>
                <p className="text-xs text-slate-500">{n.message}</p>
              </div>
              {!n.is_read && <button onClick={() => markRead(n)} className="rounded p-1.5 text-indigo-600 hover:bg-indigo-100" title="Mark read"><Check className="h-4 w-4" /></button>}
            </div>
          ))}
          {notifications.length === 0 && <EmptyState message="No notifications" />}
        </div>
      </Card>
    </div>
  );
}

// ============================ BRANCH MANAGEMENT ============================
export function BranchesPage() {
  const branches = useCollection<any>('branches');
  const { user } = useAuth();
  const { notify } = useToast();
  const confirm = useConfirm();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [form, setForm] = useState<any>({ name: '', address: '', phone: '', principal: '', students: 0, status: 'active' });

  const openNew = () => { setEditing(null); setForm({ name: '', address: '', phone: '', principal: '', students: 0, status: 'active' }); setOpen(true); };
  const openEdit = (b: any) => { setEditing(b); setForm({ ...b }); setOpen(true); };
  const save = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name) return notify('Branch name required', 'error');
    const data = { ...form, students: Number(form.students) };
    if (editing) { update('branches', editing.id, data); notify('Branch updated'); }
    else { const c = insert('branches', data); logActivity(user!, `Added branch ${form.name}`, 'branch', c.id); notify('Branch added'); }
    setOpen(false);
  };
  const del = async (b: any) => { if (!(await confirm({ message: `Delete branch "${b.name}"?`, danger: true, confirmText: 'Delete' }))) return; remove('branches', b.id); notify('Deleted'); };

  return (
    <div>
      <PageHeader title="Branch Management" subtitle="Multi-campus management"
        action={<Btn onClick={openNew}><span className="flex items-center gap-2"><Plus className="h-4 w-4" /> Add Branch</span></Btn>} />
      <div className="mb-6 grid gap-4 sm:grid-cols-2">
        <StatCard title="Total Branches" value={branches.length} icon={GitBranch} color="from-indigo-500 to-indigo-600" />
        <StatCard title="Total Students" value={branches.reduce((a, b) => a + (b.students || 0), 0)} icon={GitBranch} color="from-emerald-500 to-emerald-600" />
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        {branches.map((b) => (
          <Card key={b.id}>
            <div className="flex items-start justify-between">
              <div>
                <h3 className="text-lg font-bold text-slate-900">{b.name}</h3>
                <p className="text-sm text-slate-500">{b.address}</p>
              </div>
              <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${b.status === 'active' ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-600'}`}>{b.status}</span>
            </div>
            <div className="mt-3 grid grid-cols-2 gap-3 text-sm">
              <div><p className="text-slate-400">Principal</p><p className="font-medium text-slate-700">{b.principal || '-'}</p></div>
              <div><p className="text-slate-400">Phone</p><p className="font-medium text-slate-700">{b.phone || '-'}</p></div>
              <div><p className="text-slate-400">Students</p><p className="font-medium text-slate-700">{b.students}</p></div>
            </div>
            <div className="mt-4 flex gap-2">
              <Btn size="sm" variant="secondary" onClick={() => openEdit(b)}>Edit</Btn>
              <Btn size="sm" variant="danger" onClick={() => del(b)}>Delete</Btn>
            </div>
          </Card>
        ))}
        {branches.length === 0 && <Card><EmptyState message="No branches" /></Card>}
      </div>
      <Modal open={open} onClose={() => setOpen(false)} title={editing ? 'Edit Branch' : 'Add Branch'}>
        <form onSubmit={save} className="space-y-4">
          <Field label="Branch Name" required><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
          <Field label="Address"><Input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} /></Field>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Phone"><Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></Field>
            <Field label="Principal"><Input value={form.principal} onChange={(e) => setForm({ ...form, principal: e.target.value })} /></Field>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Students"><Input type="number" value={form.students} onChange={(e) => setForm({ ...form, students: Number(e.target.value) })} /></Field>
            <Field label="Status"><Select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })}><option value="active">Active</option><option value="inactive">Inactive</option></Select></Field>
          </div>
          <div className="flex justify-end gap-2 pt-2"><Btn variant="secondary" onClick={() => setOpen(false)}>Cancel</Btn><Btn type="submit">{editing ? 'Update' : 'Add'}</Btn></div>
        </form>
      </Modal>
    </div>
  );
}

// ============================ DISCOUNTS ============================
export function DiscountsPage() {
  const discounts = useCollection<any>('discounts');
  const { user } = useAuth();
  const { notify } = useToast();
  const confirm = useConfirm();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [form, setForm] = useState<any>({ name: '', type: 'percent', value: 0, applies_to: 'Tuition', reason: '', active: true });

  const openNew = () => { setEditing(null); setForm({ name: '', type: 'percent', value: 0, applies_to: 'Tuition', reason: '', active: true }); setOpen(true); };
  const openEdit = (d: any) => { setEditing(d); setForm({ ...d }); setOpen(true); };
  const save = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name) return notify('Name required', 'error');
    const data = { ...form, value: Number(form.value) };
    if (editing) { update('discounts', editing.id, data); notify('Discount updated'); }
    else { const c = insert('discounts', data); logActivity(user!, `Added discount ${form.name}`, 'discount', c.id); notify('Discount added'); }
    setOpen(false);
  };
  const del = async (d: any) => { if (!(await confirm({ message: `Delete "${d.name}"?`, danger: true, confirmText: 'Delete' }))) return; remove('discounts', d.id); notify('Deleted'); };

  return (
    <div>
      <PageHeader title="Discounts" subtitle="Scholarship & concession management"
        action={<Btn onClick={openNew}><span className="flex items-center gap-2"><Plus className="h-4 w-4" /> Add Discount</span></Btn>} />
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="border-b border-slate-200 text-left text-slate-600">
              <th className="pb-3 font-medium">Name</th><th className="pb-3 font-medium">Value</th><th className="pb-3 font-medium">Applies To</th>
              <th className="pb-3 font-medium">Reason</th><th className="pb-3 font-medium">Status</th><th className="pb-3"></th>
            </tr></thead>
            <tbody>
              {discounts.map((d) => (
                <tr key={d.id} className="border-b border-slate-100">
                  <td className="py-3 font-medium text-slate-900">{d.name}</td>
                  <td className="py-3 text-slate-600">{d.type === 'percent' ? `${d.value}%` : `PKR ${d.value}`}</td>
                  <td className="py-3 text-slate-600">{d.applies_to}</td>
                  <td className="py-3 text-slate-600">{d.reason || '-'}</td>
                  <td className="py-3">{d.active ? <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-xs font-medium text-emerald-700">Active</span> : <span className="rounded-full bg-slate-100 px-2 py-0.5 text-xs text-slate-600">Inactive</span>}</td>
                  <td className="py-3 text-right"><div className="flex justify-end gap-1">
                    <button onClick={() => openEdit(d)} className="rounded p-1.5 text-blue-600 hover:bg-blue-50"><Plus className="h-4 w-4 rotate-45" /></button>
                    <button onClick={() => del(d)} className="rounded p-1.5 text-rose-600 hover:bg-rose-50"><Trash2 className="h-4 w-4" /></button>
                  </div></td>
                </tr>
              ))}
            </tbody>
          </table>
          {discounts.length === 0 && <EmptyState message="No discounts defined" />}
        </div>
      </Card>
      <Modal open={open} onClose={() => setOpen(false)} title={editing ? 'Edit Discount' : 'Add Discount'}>
        <form onSubmit={save} className="space-y-4">
          <Field label="Name" required><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Sibling Discount" /></Field>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Type"><Select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}><option value="percent">Percentage (%)</option><option value="fixed">Fixed Amount</option></Select></Field>
            <Field label="Value"><Input type="number" value={form.value} onChange={(e) => setForm({ ...form, value: Number(e.target.value) })} /></Field>
          </div>
          <Field label="Applies To"><Select value={form.applies_to} onChange={(e) => setForm({ ...form, applies_to: e.target.value })}><option>Tuition</option><option>Transport</option><option>Lab</option><option>All</option></Select></Field>
          <Field label="Reason"><Input value={form.reason} onChange={(e) => setForm({ ...form, reason: e.target.value })} /></Field>
          <label className="flex items-center gap-2 text-sm text-slate-700"><input type="checkbox" checked={form.active} onChange={(e) => setForm({ ...form, active: e.target.checked })} /> Active</label>
          <div className="flex justify-end gap-2 pt-2"><Btn variant="secondary" onClick={() => setOpen(false)}>Cancel</Btn><Btn type="submit">{editing ? 'Update' : 'Add'}</Btn></div>
        </form>
      </Modal>
    </div>
  );
}

// ============================ FINES / PENALTIES ============================
export function FinesPage() {
  const fines = useCollection<any>('fines');
  const { user } = useAuth();
  const { notify } = useToast();
  const confirm = useConfirm();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [form, setForm] = useState<any>({ name: '', amount: 0, reason: '', applies_after_days: 0, active: true });

  const openNew = () => { setEditing(null); setForm({ name: '', amount: 0, reason: '', applies_after_days: 0, active: true }); setOpen(true); };
  const openEdit = (f: any) => { setEditing(f); setForm({ ...f }); setOpen(true); };
  const save = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name) return notify('Name required', 'error');
    const data = { ...form, amount: Number(form.amount), applies_after_days: Number(form.applies_after_days) };
    if (editing) { update('fines', editing.id, data); notify('Fine updated'); }
    else { const c = insert('fines', data); logActivity(user!, `Added fine ${form.name}`, 'fine', c.id); notify('Fine added'); }
    setOpen(false);
  };
  const del = async (f: any) => { if (!(await confirm({ message: `Delete "${f.name}"?`, danger: true, confirmText: 'Delete' }))) return; remove('fines', f.id); notify('Deleted'); };

  return (
    <div>
      <PageHeader title="Fines / Penalties" subtitle="Late-fee fines & penalties"
        action={<Btn onClick={openNew}><span className="flex items-center gap-2"><Plus className="h-4 w-4" /> Add Fine</span></Btn>} />
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="border-b border-slate-200 text-left text-slate-600">
              <th className="pb-3 font-medium">Fine Name</th><th className="pb-3 font-medium">Amount</th><th className="pb-3 font-medium">Applies After</th>
              <th className="pb-3 font-medium">Reason</th><th className="pb-3 font-medium">Status</th><th className="pb-3"></th>
            </tr></thead>
            <tbody>
              {fines.map((f) => (
                <tr key={f.id} className="border-b border-slate-100">
                  <td className="py-3 font-medium text-slate-900">{f.name}</td>
                  <td className="py-3 text-slate-600">PKR {f.amount}</td>
                  <td className="py-3 text-slate-600">{f.applies_after_days} day(s)</td>
                  <td className="py-3 text-slate-600">{f.reason || '-'}</td>
                  <td className="py-3">{f.active ? <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-xs font-medium text-emerald-700">Active</span> : <span className="rounded-full bg-slate-100 px-2 py-0.5 text-xs text-slate-600">Inactive</span>}</td>
                  <td className="py-3 text-right"><div className="flex justify-end gap-1">
                    <button onClick={() => openEdit(f)} className="rounded p-1.5 text-blue-600 hover:bg-blue-50"><Plus className="h-4 w-4 rotate-45" /></button>
                    <button onClick={() => del(f)} className="rounded p-1.5 text-rose-600 hover:bg-rose-50"><Trash2 className="h-4 w-4" /></button>
                  </div></td>
                </tr>
              ))}
            </tbody>
          </table>
          {fines.length === 0 && <EmptyState message="No fines defined" />}
        </div>
      </Card>
      <Modal open={open} onClose={() => setOpen(false)} title={editing ? 'Edit Fine' : 'Add Fine'}>
        <form onSubmit={save} className="space-y-4">
          <Field label="Fine Name" required><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Amount (PKR)"><Input type="number" value={form.amount} onChange={(e) => setForm({ ...form, amount: Number(e.target.value) })} /></Field>
            <Field label="Applies After (days)"><Input type="number" value={form.applies_after_days} onChange={(e) => setForm({ ...form, applies_after_days: Number(e.target.value) })} /></Field>
          </div>
          <Field label="Reason"><Input value={form.reason} onChange={(e) => setForm({ ...form, reason: e.target.value })} /></Field>
          <label className="flex items-center gap-2 text-sm text-slate-700"><input type="checkbox" checked={form.active} onChange={(e) => setForm({ ...form, active: e.target.checked })} /> Active</label>
          <div className="flex justify-end gap-2 pt-2"><Btn variant="secondary" onClick={() => setOpen(false)}>Cancel</Btn><Btn type="submit">{editing ? 'Update' : 'Add'}</Btn></div>
        </form>
      </Modal>
    </div>
  );
}
