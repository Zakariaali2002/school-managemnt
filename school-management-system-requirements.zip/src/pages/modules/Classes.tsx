import { useState } from 'react';
import { Plus, Pencil, Trash2, BookOpen } from 'lucide-react';
import { useCollection } from '../../hooks/useDB';
import { insert, update, remove, logActivity } from '../../lib/db';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../components/ui/Toast';
import { useConfirm } from '../../components/ui/Confirm';
import { Modal } from '../../components/ui/Modal';
import { Field, Input, Select } from '../../components/ui/Field';
import { PageHeader, Card, Btn, EmptyState } from '../../components/ui/Shared';

export function ClassesPage() {
  const classes = useCollection<any>('classes');
  const subjects = useCollection<any>('subjects');
  const staff = useCollection<any>('staff');
  const students = useCollection<any>('students');
  const { user } = useAuth();
  const { notify } = useToast();
  const confirm = useConfirm();
  const [open, setOpen] = useState(false);
  const [subOpen, setSubOpen] = useState<any>(null);
  const [editing, setEditing] = useState<any>(null);
  const [form, setForm] = useState<any>({});
  const [subForm, setSubForm] = useState({ name: '', code: '', teacher_id: '', credit_hours: 3 });

  const openNew = () => { setEditing(null); setForm({ name: '', level: '', section: 'A', max_students: 40, class_teacher_id: '' }); setOpen(true); };
  const openEdit = (c: any) => { setEditing(c); setForm({ ...c }); setOpen(true); };

  const save = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name) return notify('Class name required', 'error');
    if (editing) { update('classes', editing.id, form); notify('Class updated'); }
    else { const c = insert('classes', form); logActivity(user!, `Created class ${form.name}`, 'class', c.id); notify('Class created'); }
    setOpen(false);
  };

  const del = async (c: any) => {
    const ok = await confirm({ message: `Delete ${c.name}?`, danger: true, confirmText: 'Delete' });
    if (!ok) return;
    remove('classes', c.id);
    notify('Class deleted');
  };

  const addSubject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!subForm.name) return notify('Subject name required', 'error');
    insert('subjects', { ...subForm, class_id: subOpen.id, credit_hours: Number(subForm.credit_hours) });
    notify('Subject added');
    setSubForm({ name: '', code: '', teacher_id: '', credit_hours: 3 });
  };

  const teacherName = (id: string) => staff.find((s) => s.id === id)?.name || 'Unassigned';

  return (
    <div>
      <PageHeader title="Classes & Subjects" subtitle="Manage classes and their subjects"
        action={<Btn onClick={openNew}><span className="flex items-center gap-2"><Plus className="h-4 w-4" /> Add Class</span></Btn>} />

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {classes.map((c) => (
          <Card key={c.id}>
            <div className="flex items-start justify-between">
              <div>
                <p className="font-semibold text-slate-900">{c.name} - {c.section}</p>
                <p className="text-xs text-slate-500">Level {c.level} · Max {c.max_students}</p>
                <p className="mt-1 text-xs text-slate-500">Teacher: {teacherName(c.class_teacher_id)}</p>
                <p className="mt-1 text-xs text-slate-500">{students.filter((s) => s.class_id === c.id).length} students · {subjects.filter((s) => s.class_id === c.id).length} subjects</p>
              </div>
              <div className="flex gap-1">
                <button onClick={() => openEdit(c)} className="rounded p-1 text-blue-600 hover:bg-blue-50"><Pencil className="h-4 w-4" /></button>
                <button onClick={() => del(c)} className="rounded p-1 text-red-600 hover:bg-red-50"><Trash2 className="h-4 w-4" /></button>
              </div>
            </div>
            <Btn size="sm" variant="secondary" className="mt-3" onClick={() => setSubOpen(c)}>
              <span className="flex items-center gap-1"><BookOpen className="h-3 w-3" /> Manage Subjects</span>
            </Btn>
          </Card>
        ))}
        {classes.length === 0 && <Card><EmptyState message="No classes" /></Card>}
      </div>

      <Modal open={open} onClose={() => setOpen(false)} title={editing ? 'Edit Class' : 'Add Class'}>
        <form onSubmit={save} className="space-y-4">
          <Field label="Class Name" required><Input value={form.name || ''} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Class 9" /></Field>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Level"><Input value={form.level || ''} onChange={(e) => setForm({ ...form, level: e.target.value })} /></Field>
            <Field label="Section"><Input value={form.section || ''} onChange={(e) => setForm({ ...form, section: e.target.value })} /></Field>
          </div>
          <Field label="Max Students"><Input type="number" value={form.max_students || 40} onChange={(e) => setForm({ ...form, max_students: Number(e.target.value) })} /></Field>
          <Field label="Class Teacher">
            <Select value={form.class_teacher_id || ''} onChange={(e) => setForm({ ...form, class_teacher_id: e.target.value })}>
              <option value="">Unassigned</option>
              {staff.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </Select>
          </Field>
          <div className="flex justify-end gap-2 pt-2"><Btn variant="secondary" onClick={() => setOpen(false)}>Cancel</Btn><Btn type="submit">{editing ? 'Update' : 'Create'}</Btn></div>
        </form>
      </Modal>

      <Modal open={!!subOpen} onClose={() => setSubOpen(null)} title={`Subjects - ${subOpen?.name || ''}`}>
        <div className="space-y-4">
          <div className="space-y-2">
            {subjects.filter((s) => s.class_id === subOpen?.id).map((s) => (
              <div key={s.id} className="flex items-center justify-between rounded-lg bg-slate-50 p-3">
                <div>
                  <p className="text-sm font-medium text-slate-900">{s.name} <span className="text-xs text-slate-400">({s.code})</span></p>
                  <p className="text-xs text-slate-500">{teacherName(s.teacher_id)} · {s.credit_hours} credit hrs</p>
                </div>
                <button onClick={() => { remove('subjects', s.id); notify('Subject removed'); }} className="rounded p-1.5 text-red-600 hover:bg-red-50"><Trash2 className="h-4 w-4" /></button>
              </div>
            ))}
            {subjects.filter((s) => s.class_id === subOpen?.id).length === 0 && <EmptyState message="No subjects" />}
          </div>
          <form onSubmit={addSubject} className="space-y-3 border-t border-slate-200 pt-4">
            <div className="grid grid-cols-2 gap-3">
              <Field label="Subject Name" required><Input value={subForm.name} onChange={(e) => setSubForm({ ...subForm, name: e.target.value })} /></Field>
              <Field label="Code"><Input value={subForm.code} onChange={(e) => setSubForm({ ...subForm, code: e.target.value })} /></Field>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Teacher">
                <Select value={subForm.teacher_id} onChange={(e) => setSubForm({ ...subForm, teacher_id: e.target.value })}>
                  <option value="">Unassigned</option>
                  {staff.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
                </Select>
              </Field>
              <Field label="Credit Hours"><Input type="number" value={subForm.credit_hours} onChange={(e) => setSubForm({ ...subForm, credit_hours: Number(e.target.value) })} /></Field>
            </div>
            <div className="flex justify-end"><Btn type="submit">Add Subject</Btn></div>
          </form>
        </div>
      </Modal>
    </div>
  );
}
