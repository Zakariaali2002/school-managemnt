import { useCollection } from '../../hooks/useDB';
import { PageHeader, Card, StatCard } from '../../components/ui/Shared';
import { ShieldCheck, Check } from 'lucide-react';

const ROLES = [
  { key: 'super_admin', label: 'Super Admin' },
  { key: 'principal', label: 'Principal' },
  { key: 'hr', label: 'HR Manager' },
  { key: 'accounts', label: 'Accounts' },
  { key: 'teacher', label: 'Teacher' },
  { key: 'student', label: 'Student' },
  { key: 'parent', label: 'Parent' },
];

// Module access matrix (which role can access which area).
const MATRIX: { module: string; roles: string[] }[] = [
  { module: 'Dashboard', roles: ['super_admin', 'principal', 'hr', 'accounts', 'teacher', 'student', 'parent'] },
  { module: 'Students', roles: ['super_admin', 'principal'] },
  { module: 'Teachers / Staff', roles: ['super_admin', 'principal', 'hr'] },
  { module: 'Attendance', roles: ['super_admin', 'principal', 'teacher'] },
  { module: 'Examination & Results', roles: ['super_admin', 'principal', 'teacher'] },
  { module: 'Fees & Accounts', roles: ['super_admin', 'accounts'] },
  { module: 'Payroll', roles: ['super_admin', 'hr', 'accounts'] },
  { module: 'Documents', roles: ['super_admin', 'principal', 'hr'] },
  { module: 'Reports', roles: ['super_admin', 'principal', 'accounts'] },
  { module: 'User Management', roles: ['super_admin'] },
  { module: 'System Settings', roles: ['super_admin'] },
];

export function RolesPage() {
  const users = useCollection<any>('users');
  const count = (role: string) => users.filter((u) => u.role === role).length;

  return (
    <div>
      <PageHeader title="Roles & Permissions" subtitle="Role-based access control overview" />
      <div className="mb-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard title="Total Roles" value={ROLES.length} icon={ShieldCheck} color="from-indigo-500 to-indigo-600" />
        <StatCard title="Active Users" value={users.filter((u) => u.is_active).length} icon={ShieldCheck} color="from-emerald-500 to-emerald-600" />
        <StatCard title="Admins" value={count('super_admin')} icon={ShieldCheck} color="from-violet-500 to-violet-600" />
        <StatCard title="Modules" value={MATRIX.length} icon={ShieldCheck} color="from-amber-500 to-amber-600" />
      </div>

      <Card title="Permission Matrix">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-slate-600">
                <th className="pb-3 text-left font-medium">Module</th>
                {ROLES.map((r) => <th key={r.key} className="px-2 pb-3 text-center text-xs font-medium">{r.label}</th>)}
              </tr>
            </thead>
            <tbody>
              {MATRIX.map((m) => (
                <tr key={m.module} className="border-b border-slate-100">
                  <td className="py-3 font-medium text-slate-800">{m.module}</td>
                  {ROLES.map((r) => (
                    <td key={r.key} className="px-2 py-3 text-center">
                      {m.roles.includes(r.key)
                        ? <Check className="mx-auto h-4 w-4 text-emerald-600" />
                        : <span className="text-slate-300">—</span>}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-4 text-xs text-slate-400">
          Permissions are enforced via role-based routing. Each role only sees and accesses its assigned modules.
        </p>
      </Card>
    </div>
  );
}
