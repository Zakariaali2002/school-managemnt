import { useState } from 'react';
import { Plus, Trash2, Pencil } from 'lucide-react';
import { useCollection } from '../../hooks/useDB';
import { insert, update, remove, logActivity } from '../../lib/db';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../components/ui/Toast';
import { useConfirm } from '../../components/ui/Confirm';
import { Modal } from '../../components/ui/Modal';
import { Field, Input, Select } from '../../components/ui/Field';
import { PageHeader, Card, Btn, EmptyState } from '../../components/ui/Shared';

export function SubjectsPage() {
  const subjects = useCollection<any>('subjects');
  const classes = useCollection<any>('classes');
  const staff = useCollection<any>('staff');
  const { user } = useAuth();
  const { notify } = useToast();
  const confirm = useConfirm();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [form, setForm] = useState<any>({ name: '', code: '', class_id: '', teacher_id: '', credit_hours: 1 });

  const className = (id: string) => classes.find((c) => c.id === id)?.name || '-';
  const teacherName = (id: string) => staff.find((s) => s.id === id)?.name || '-';

  const openNew = () => { setEditing(null); setForm({ name: '', code: '', class_id: classes[0]?.id || '', teacher_id: '', credit_hours: 1 }); setOpen(true); };
  const openEdit = (s: any) => { setEditing(s); setForm({ ...s }); setOpen(true); };

  const save = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name) return notify('Subject name required', 'error');
    if (editing) { update('subjects', editing.id, { ...form, credit_hours: Number(form.credit_hours) }); notify('Subject updated'); }
    else { const c = insert('subjects', { ...form, credit_hours: Number(form.credit_hours) }); logActivity(user!, `Added subject ${form.name}`, 'subject', c.id); notify('Subject added'); }
    setOpen(false);
  };
  const del = async (s: any) => {
    if (!(await confirm({ message: `Delete subject "${s.name}"?`, danger: true, confirmText: 'Delete' }))) return;
    remove('subjects', s.id);
    notify('Subject deleted');
  };

  return (
    <div>
      <PageHeader title="Subjects" subtitle="Manage subjects, codes and teacher assignments"
        action={<Btn onClick={openNew}><span className="flex items-center gap-2"><Plus className="h-4 w-4" /> Add Subject</span></Btn>} />
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="border-b border-slate-200 text-left text-slate-600">
              <th className="pb-3 font-medium">Subject</th><th className="pb-3 font-medium">Code</th>
              <th className="pb-3 font-medium">Class</th><th className="pb-3 font-medium">Teacher</th>
              <th className="pb-3 font-medium">Credit Hrs</th><th className="pb-3"></th>
            </tr></thead>
            <tbody>
              {subjects.map((s) => (
                <tr key={s.id} className="border-b border-slate-100">
                  <td className="py-3 font-medium text-slate-900">{s.name}</td>
                  <td className="py-3 text-slate-600">{s.code || '-'}</td>
                  <td className="py-3 text-slate-600">{className(s.class_id)}</td>
                  <td className="py-3 text-slate-600">{teacherName(s.teacher_id)}</td>
                  <td className="py-3 text-slate-600">{s.credit_hours || '-'}</td>
                  <td className="py-3 text-right">
                    <div className="flex justify-end gap-1">
                      <button onClick={() => openEdit(s)} className="rounded p-1.5 text-blue-600 hover:bg-blue-50"><Pencil className="h-4 w-4" /></button>
                      <button onClick={() => del(s)} className="rounded p-1.5 text-rose-600 hover:bg-rose-50"><Trash2 className="h-4 w-4" /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {subjects.length === 0 && <EmptyState message="No subjects defined" />}
        </div>
      </Card>

      <Modal open={open} onClose={() => setOpen(false)} title={editing ? 'Edit Subject' : 'Add Subject'}>
        <form onSubmit={save} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <Field label="Subject Name" required><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
            <Field label="Code"><Input value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} placeholder="e.g. MATH-9" /></Field>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Class"><Select value={form.class_id} onChange={(e) => setForm({ ...form, class_id: e.target.value })}><option value="">Select...</option>{classes.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</Select></Field>
            <Field label="Teacher"><Select value={form.teacher_id} onChange={(e) => setForm({ ...form, teacher_id: e.target.value })}><option value="">Unassigned</option>{staff.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</Select></Field>
          </div>
          <Field label="Credit Hours"><Input type="number" value={form.credit_hours} onChange={(e) => setForm({ ...form, credit_hours: Number(e.target.value) })} /></Field>
          <div className="flex justify-end gap-2 pt-2"><Btn variant="secondary" onClick={() => setOpen(false)}>Cancel</Btn><Btn type="submit">{editing ? 'Update' : 'Add'}</Btn></div>
        </form>
      </Modal>
    </div>
  );
}
