import { useState } from 'react';
import { Plus, Pencil, Trash2 } from 'lucide-react';
import { useCollection } from '../../hooks/useDB';
import { insert, update, remove, logActivity } from '../../lib/db';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../components/ui/Toast';
import { useConfirm } from '../../components/ui/Confirm';
import { Modal } from '../../components/ui/Modal';
import { Field, Input, Select } from '../../components/ui/Field';
import { PageHeader, Card, Btn, EmptyState } from '../../components/ui/Shared';
import { fmtDate } from '../../lib/utils';

export function ExamsPage() {
  const exams = useCollection<any>('exams');
  const classes = useCollection<any>('classes');
  const { user } = useAuth();
  const { notify } = useToast();
  const confirm = useConfirm();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [form, setForm] = useState<any>({});

  const blank = () => ({ name: '', class_id: classes[0]?.id || '', academic_year: '2024', start_date: '', end_date: '' });
  const openNew = () => { setEditing(null); setForm(blank()); setOpen(true); };
  const openEdit = (x: any) => { setEditing(x); setForm({ ...x }); setOpen(true); };

  const save = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.class_id) return notify('Name and class required', 'error');
    if (editing) { update('exams', editing.id, form); notify('Exam updated'); logActivity(user!, `Updated exam ${form.name}`, 'exam', editing.id); }
    else { const c = insert('exams', { ...form, created_by: user!.id }); notify('Exam created'); logActivity(user!, `Created exam ${form.name}`, 'exam', c.id); }
    setOpen(false);
  };

  const del = async (x: any) => {
    const ok = await confirm({ message: `Delete exam ${x.name}?`, danger: true, confirmText: 'Delete' });
    if (!ok) return;
    remove('exams', x.id);
    logActivity(user!, `Deleted exam ${x.name}`, 'exam', x.id);
    notify('Exam deleted');
  };

  const className = (id: string) => classes.find((c) => c.id === id)?.name || '-';

  return (
    <div>
      <PageHeader title="Exams" subtitle="Schedule and manage examinations"
        action={<Btn onClick={openNew}><span className="flex items-center gap-2"><Plus className="h-4 w-4" /> Create Exam</span></Btn>} />
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-left text-slate-600">
                <th className="pb-3 font-medium">Exam</th><th className="pb-3 font-medium">Class</th>
                <th className="pb-3 font-medium">Year</th><th className="pb-3 font-medium">Start</th>
                <th className="pb-3 font-medium">End</th><th className="pb-3 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {exams.map((x) => (
                <tr key={x.id} className="border-b border-slate-100">
                  <td className="py-3 font-medium text-slate-900">{x.name}</td>
                  <td className="py-3 text-slate-600">{className(x.class_id)}</td>
                  <td className="py-3 text-slate-600">{x.academic_year}</td>
                  <td className="py-3 text-slate-500">{fmtDate(x.start_date)}</td>
                  <td className="py-3 text-slate-500">{fmtDate(x.end_date)}</td>
                  <td className="py-3">
                    <div className="flex gap-1">
                      <button onClick={() => openEdit(x)} className="rounded p-1.5 text-blue-600 hover:bg-blue-50"><Pencil className="h-4 w-4" /></button>
                      <button onClick={() => del(x)} className="rounded p-1.5 text-red-600 hover:bg-red-50"><Trash2 className="h-4 w-4" /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {exams.length === 0 && <EmptyState message="No exams scheduled" />}
        </div>
      </Card>

      <Modal open={open} onClose={() => setOpen(false)} title={editing ? 'Edit Exam' : 'Create Exam'}>
        <form onSubmit={save} className="space-y-4">
          <Field label="Exam Name" required><Input value={form.name || ''} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
          <Field label="Class" required>
            <Select value={form.class_id || ''} onChange={(e) => setForm({ ...form, class_id: e.target.value })}>
              {classes.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </Select>
          </Field>
          <Field label="Academic Year"><Input value={form.academic_year || ''} onChange={(e) => setForm({ ...form, academic_year: e.target.value })} /></Field>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Start Date"><Input type="date" value={form.start_date || ''} onChange={(e) => setForm({ ...form, start_date: e.target.value })} /></Field>
            <Field label="End Date"><Input type="date" value={form.end_date || ''} onChange={(e) => setForm({ ...form, end_date: e.target.value })} /></Field>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Btn variant="secondary" onClick={() => setOpen(false)}>Cancel</Btn>
            <Btn type="submit">{editing ? 'Update' : 'Create'}</Btn>
          </div>
        </form>
      </Modal>
    </div>
  );
}
