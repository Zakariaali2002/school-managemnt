import { useState } from 'react';
import { Plus, Check, Trash2 } from 'lucide-react';
import { useCollection } from '../../hooks/useDB';
import { insert, remove, update, logActivity } from '../../lib/db';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../components/ui/Toast';
import { useConfirm } from '../../components/ui/Confirm';
import { Modal } from '../../components/ui/Modal';
import { Field, Input, Select } from '../../components/ui/Field';
import { FileUpload } from '../../components/ui/FileUpload';
import { PageHeader, Card, Btn, EmptyState } from '../../components/ui/Shared';
import { money, fmtDate } from '../../lib/utils';
import { Paperclip } from 'lucide-react';

const CATEGORIES = ['Utilities', 'Supplies', 'Maintenance', 'Salaries', 'Transport', 'Events', 'Other'];
const blankExpense = () => ({ category: 'Utilities', description: '', amount: 0, date: new Date().toISOString().slice(0, 10), paid_to: '', receipt_name: '', receipt_data: '', receipt_type: '' });

export function ExpensesPage({ canApprove = false }: { canApprove?: boolean }) {
  const expenses = useCollection<any>('expenses');
  const { user } = useAuth();
  const { notify } = useToast();
  const confirm = useConfirm();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<any>(blankExpense());

  const save = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.description || !form.amount) return notify('Description and amount required', 'error');
    const c = insert('expenses', { ...form, amount: Number(form.amount), approved_by: canApprove ? user!.id : '' });
    logActivity(user!, `Added expense ${form.description}`, 'expense', c.id);
    notify('Expense added');
    setOpen(false);
    setForm(blankExpense());
  };

  const viewReceipt = (ex: any) => {
    if (!ex.receipt_data) return notify('No receipt attached', 'info');
    const w = window.open();
    if (!w) return;
    if (ex.receipt_type === 'application/pdf') w.document.write(`<iframe src="${ex.receipt_data}" style="width:100%;height:100%;border:none;"></iframe>`);
    else w.document.write(`<img src="${ex.receipt_data}" style="max-width:100%;"/>`);
  };

  const approve = (ex: any) => {
    update('expenses', ex.id, { approved_by: user!.id });
    logActivity(user!, `Approved expense ${ex.description}`, 'expense', ex.id);
    notify('Expense approved');
  };

  const del = async (ex: any) => {
    const ok = await confirm({ message: `Delete expense "${ex.description}"?`, danger: true, confirmText: 'Delete' });
    if (!ok) return;
    remove('expenses', ex.id);
    notify('Expense deleted');
  };

  const total = expenses.reduce((a, e) => a + e.amount, 0);

  return (
    <div>
      <PageHeader title="Expenses" subtitle={`Total recorded: ${money(total)}`}
        action={<Btn onClick={() => setOpen(true)}><span className="flex items-center gap-2"><Plus className="h-4 w-4" /> Add Expense</span></Btn>} />
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-left text-slate-600">
                <th className="pb-3 font-medium">Date</th><th className="pb-3 font-medium">Category</th>
                <th className="pb-3 font-medium">Description</th><th className="pb-3 font-medium">Paid To</th>
                <th className="pb-3 font-medium">Amount</th><th className="pb-3 font-medium">Approved</th><th className="pb-3 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {expenses.slice().reverse().map((ex) => (
                <tr key={ex.id} className="border-b border-slate-100">
                  <td className="py-3 text-slate-500">{fmtDate(ex.date)}</td>
                  <td className="py-3 text-slate-600">{ex.category}</td>
                  <td className="py-3 font-medium text-slate-900">{ex.description}</td>
                  <td className="py-3 text-slate-600">{ex.paid_to || '-'}</td>
                  <td className="py-3 text-slate-600">{money(ex.amount)}</td>
                  <td className="py-3">
                    {ex.approved_by ? <span className="rounded-full bg-green-100 px-2 py-1 text-xs font-medium text-green-700">Approved</span>
                      : <span className="rounded-full bg-yellow-100 px-2 py-1 text-xs font-medium text-yellow-700">Pending</span>}
                  </td>
                  <td className="py-3">
                    <div className="flex gap-1">
                      {ex.receipt_name && <button onClick={() => viewReceipt(ex)} className="rounded p-1.5 text-blue-600 hover:bg-blue-50" title="View Receipt"><Paperclip className="h-4 w-4" /></button>}
                      {canApprove && !ex.approved_by && <button onClick={() => approve(ex)} className="rounded p-1.5 text-green-600 hover:bg-green-50" title="Approve"><Check className="h-4 w-4" /></button>}
                      <button onClick={() => del(ex)} className="rounded p-1.5 text-red-600 hover:bg-red-50"><Trash2 className="h-4 w-4" /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {expenses.length === 0 && <EmptyState message="No expenses recorded" />}
        </div>
      </Card>

      <Modal open={open} onClose={() => setOpen(false)} title="Add Expense">
        <form onSubmit={save} className="space-y-4">
          <Field label="Category"><Select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>{CATEGORIES.map((c) => <option key={c}>{c}</option>)}</Select></Field>
          <Field label="Description" required><Input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></Field>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Amount (PKR)" required><Input type="number" value={form.amount} onChange={(e) => setForm({ ...form, amount: Number(e.target.value) })} /></Field>
            <Field label="Date"><Input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} /></Field>
          </div>
          <Field label="Paid To"><Input value={form.paid_to} onChange={(e) => setForm({ ...form, paid_to: e.target.value })} /></Field>
          <FileUpload
            label="Receipt / Bill (optional)"
            value={form.receipt_name ? { file_name: form.receipt_name, file_data: form.receipt_data, file_type: form.receipt_type } : null}
            onChange={(f) => setForm({ ...form, receipt_name: f?.file_name || '', receipt_data: f?.file_data || '', receipt_type: f?.file_type || '' })}
            onError={(m) => notify(m, 'error')}
          />
          <div className="flex justify-end gap-2 pt-2"><Btn variant="secondary" onClick={() => setOpen(false)}>Cancel</Btn><Btn type="submit">Add</Btn></div>
        </form>
      </Modal>
    </div>
  );
}
