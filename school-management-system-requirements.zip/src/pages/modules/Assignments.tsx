import { useState } from 'react';
import { Plus, Pencil, Trash2, Upload, FileCheck } from 'lucide-react';
import { useCollection } from '../../hooks/useDB';
import { insert, update, remove, logActivity } from '../../lib/db';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../components/ui/Toast';
import { useConfirm } from '../../components/ui/Confirm';
import { Modal } from '../../components/ui/Modal';
import { Field, Input, Select, Textarea } from '../../components/ui/Field';
import { FileUpload } from '../../components/ui/FileUpload';
import { PageHeader, Card, Btn, EmptyState } from '../../components/ui/Shared';
import { StatusBadge, fmtDate } from '../../lib/utils';

export function AssignmentsPage({ studentMode = false, studentId = '', classId = '' }: { studentMode?: boolean; studentId?: string; classId?: string }) {
  const assignments = useCollection<any>('assignments');
  const submissions = useCollection<any>('submissions');
  const subjects = useCollection<any>('subjects');
  const classes = useCollection<any>('classes');
  const { user } = useAuth();
  const { notify } = useToast();
  const confirm = useConfirm();
  const [open, setOpen] = useState(false);
  const [submitFor, setSubmitFor] = useState<any>(null);
  const [gradeFor, setGradeFor] = useState<any>(null);
  const [editing, setEditing] = useState<any>(null);
  const [form, setForm] = useState<any>({});
  const [subFile, setSubFile] = useState<any>(null);
  const [grades, setGrades] = useState<Record<string, string>>({});

  const blank = () => ({ title: '', subject_id: subjects[0]?.id || '', class_id: classes[0]?.id || '', due_date: '', max_marks: 50, description: '' });
  const openNew = () => { setEditing(null); setForm(blank()); setOpen(true); };
  const openEdit = (a: any) => { setEditing(a); setForm({ ...a }); setOpen(true); };

  const save = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.title) return notify('Title required', 'error');
    if (editing) { update('assignments', editing.id, { ...form, max_marks: Number(form.max_marks) }); notify('Assignment updated'); }
    else { const c = insert('assignments', { ...form, max_marks: Number(form.max_marks), teacher_id: user!.id }); logActivity(user!, `Created assignment ${form.title}`, 'assignment', c.id); notify('Assignment created'); }
    setOpen(false);
  };

  const del = async (a: any) => {
    const ok = await confirm({ message: `Delete assignment "${a.title}"?`, danger: true, confirmText: 'Delete' });
    if (!ok) return;
    remove('assignments', a.id);
    notify('Assignment deleted');
  };

  const submitWork = (e: React.FormEvent) => {
    e.preventDefault();
    if (!subFile) return notify('Please upload your work', 'error');
    insert('submissions', { assignment_id: submitFor.id, student_id: studentId, file_name: subFile.file_name, file_data: subFile.file_data, file_type: subFile.file_type, submitted_at: new Date().toISOString(), marks_obtained: null });
    logActivity(user!, `Submitted assignment ${submitFor.title}`, 'submission', submitFor.id);
    notify('Assignment submitted');
    setSubmitFor(null);
    setSubFile(null);
  };

  const viewFile = (item: any) => {
    if (!item.file_data) return notify('No file attached', 'info');
    const w = window.open();
    if (!w) return;
    if (item.file_type === 'application/pdf') w.document.write(`<iframe src="${item.file_data}" style="width:100%;height:100%;border:none;"></iframe>`);
    else w.document.write(`<img src="${item.file_data}" style="max-width:100%;"/>`);
  };

  const saveGrades = () => {
    submissions.filter((s) => s.assignment_id === gradeFor.id).forEach((sub) => {
      if (grades[sub.id] !== undefined && grades[sub.id] !== '') {
        update('submissions', sub.id, { marks_obtained: Number(grades[sub.id]) });
      }
    });
    notify('Grades saved');
    setGradeFor(null);
    setGrades({});
  };

  const subName = (id: string) => subjects.find((s) => s.id === id)?.name || '-';
  const studentSubmission = (aid: string) => submissions.find((s) => s.assignment_id === aid && s.student_id === studentId);

  const list = studentMode ? assignments.filter((a) => a.class_id === classId) : assignments;

  return (
    <div>
      <PageHeader title="Assignments" subtitle={studentMode ? 'Submit and track your homework' : 'Manage assignments and grade submissions'}
        action={!studentMode && <Btn onClick={openNew}><span className="flex items-center gap-2"><Plus className="h-4 w-4" /> New Assignment</span></Btn>} />

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {list.map((a) => {
          const subs = submissions.filter((s) => s.assignment_id === a.id);
          const mine = studentSubmission(a.id);
          return (
            <Card key={a.id}>
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-semibold text-slate-900">{a.title}</p>
                  <p className="text-xs text-slate-500">{subName(a.subject_id)} · Max {a.max_marks}</p>
                </div>
                {!studentMode && (
                  <div className="flex gap-1">
                    <button onClick={() => openEdit(a)} className="rounded p-1 text-blue-600 hover:bg-blue-50"><Pencil className="h-4 w-4" /></button>
                    <button onClick={() => del(a)} className="rounded p-1 text-red-600 hover:bg-red-50"><Trash2 className="h-4 w-4" /></button>
                  </div>
                )}
              </div>
              <p className="mt-2 text-sm text-slate-600">{a.description}</p>
              <p className="mt-2 text-xs text-slate-400">Due: {fmtDate(a.due_date)}</p>
              {a.file_name && (
                <button onClick={() => viewFile(a)} className="mt-1 text-xs text-blue-600 hover:underline">📎 {a.file_name}</button>
              )}
              {studentMode ? (
                <div className="mt-3">
                  {mine ? (
                    <div className="flex items-center justify-between">
                      <StatusBadge status="submitted" />
                      <span className="text-xs text-slate-500">{mine.marks_obtained != null ? `Marks: ${mine.marks_obtained}/${a.max_marks}` : 'Awaiting grade'}</span>
                    </div>
                  ) : (
                    <Btn size="sm" onClick={() => setSubmitFor(a)}><span className="flex items-center gap-1"><Upload className="h-3 w-3" /> Submit</span></Btn>
                  )}
                </div>
              ) : (
                <div className="mt-3 flex items-center justify-between">
                  <span className="text-xs text-slate-500">{subs.length} submission(s)</span>
                  <Btn size="sm" variant="secondary" onClick={() => { setGradeFor(a); setGrades({}); }}>
                    <span className="flex items-center gap-1"><FileCheck className="h-3 w-3" /> Review</span>
                  </Btn>
                </div>
              )}
            </Card>
          );
        })}
      </div>
      {list.length === 0 && <Card><EmptyState message="No assignments" /></Card>}

      <Modal open={open} onClose={() => setOpen(false)} title={editing ? 'Edit Assignment' : 'New Assignment'}>
        <form onSubmit={save} className="space-y-4">
          <Field label="Title" required><Input value={form.title || ''} onChange={(e) => setForm({ ...form, title: e.target.value })} /></Field>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Subject">
              <Select value={form.subject_id || ''} onChange={(e) => setForm({ ...form, subject_id: e.target.value })}>
                {subjects.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
              </Select>
            </Field>
            <Field label="Class">
              <Select value={form.class_id || ''} onChange={(e) => setForm({ ...form, class_id: e.target.value })}>
                {classes.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </Select>
            </Field>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Due Date"><Input type="date" value={form.due_date || ''} onChange={(e) => setForm({ ...form, due_date: e.target.value })} /></Field>
            <Field label="Max Marks"><Input type="number" value={form.max_marks || 0} onChange={(e) => setForm({ ...form, max_marks: e.target.value })} /></Field>
          </div>
          <Field label="Description"><Textarea rows={3} value={form.description || ''} onChange={(e) => setForm({ ...form, description: e.target.value })} /></Field>
          <FileUpload
            label="Attach Worksheet / Resource (optional)"
            value={form.file_name ? { file_name: form.file_name, file_data: form.file_data, file_type: form.file_type } : null}
            onChange={(f) => setForm({ ...form, file_name: f?.file_name || '', file_data: f?.file_data || '', file_type: f?.file_type || '' })}
            onError={(m) => notify(m, 'error')}
          />
          <div className="flex justify-end gap-2 pt-2"><Btn variant="secondary" onClick={() => setOpen(false)}>Cancel</Btn><Btn type="submit">{editing ? 'Update' : 'Create'}</Btn></div>
        </form>
      </Modal>

      <Modal open={!!submitFor} onClose={() => setSubmitFor(null)} title={`Submit: ${submitFor?.title || ''}`}>
        <form onSubmit={submitWork} className="space-y-4">
          <FileUpload label="Upload your work (PDF / Image)" value={subFile} onChange={setSubFile} onError={(m) => notify(m, 'error')} />
          <div className="flex justify-end gap-2"><Btn variant="secondary" onClick={() => setSubmitFor(null)}>Cancel</Btn><Btn type="submit">Submit</Btn></div>
        </form>
      </Modal>

      <Modal open={!!gradeFor} onClose={() => setGradeFor(null)} title={`Submissions: ${gradeFor?.title || ''}`}>
        <div className="space-y-3">
          {submissions.filter((s) => s.assignment_id === gradeFor?.id).map((sub) => {
            return (
              <div key={sub.id} className="flex items-center justify-between rounded-lg bg-slate-50 p-3">
                <div>
                  <p className="text-sm font-medium text-slate-900"><SubmitterName id={sub.student_id} /></p>
                  <button onClick={() => viewFile(sub)} className="text-xs text-blue-600 hover:underline">{sub.file_name}</button>
                  <span className="text-xs text-slate-500"> · {fmtDate(sub.submitted_at)}</span>
                </div>
                <input type="number" placeholder="Marks" defaultValue={sub.marks_obtained ?? ''} onChange={(e) => setGrades({ ...grades, [sub.id]: e.target.value })}
                  className="w-20 rounded border border-slate-300 px-2 py-1 text-sm" />
              </div>
            );
          })}
          {submissions.filter((s) => s.assignment_id === gradeFor?.id).length === 0 && <EmptyState message="No submissions yet" />}
          {submissions.filter((s) => s.assignment_id === gradeFor?.id).length > 0 && (
            <div className="flex justify-end"><Btn onClick={saveGrades}>Save Grades</Btn></div>
          )}
        </div>
      </Modal>
    </div>
  );
}

function SubmitterName({ id }: { id: string }) {
  const students = useCollection<any>('students');
  return <>{students.find((s) => s.id === id)?.name || 'Student'}</>;
}
