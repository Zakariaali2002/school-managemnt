import { useState } from 'react';
import { Plus, Pencil, Trash2, FolderOpen, CreditCard } from 'lucide-react';
import { useCollection } from '../../hooks/useDB';
import { insert, update, remove, logActivity, getSettings } from '../../lib/db';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../components/ui/Toast';
import { useConfirm } from '../../components/ui/Confirm';
import { Modal } from '../../components/ui/Modal';
import { Field, Input, Select } from '../../components/ui/Field';
import { PageHeader, Card, Btn, EmptyState } from '../../components/ui/Shared';
import { fmtDate, money, printDocument, barcodeSvgString } from '../../lib/utils';

export function StaffPage({ readOnly = false }: { readOnly?: boolean }) {
  const staff = useCollection<any>('staff');
  const documents = useCollection<any>('staffDocuments');
  const { user } = useAuth();
  const { notify } = useToast();
  const confirm = useConfirm();
  const [open, setOpen] = useState(false);
  const [docOpen, setDocOpen] = useState<any>(null);
  const [editing, setEditing] = useState<any>(null);
  const [form, setForm] = useState<any>({});
  const [docForm, setDocForm] = useState({ doc_type: 'Contract', file_name: '', expiry_date: '' });

  const blank = () => ({
    name: '', employee_code: 'EMP-' + String(staff.length + 1).padStart(3, '0'), designation: '', department: '',
    join_date: new Date().toISOString().slice(0, 10), cnic: '', base_salary: 50000, contract_type: 'permanent',
    bank_name: '', bank_account_title: '', bank_account: '', iban: '', easypaisa: '', jazzcash: '',
  });

  const openNew = () => { setEditing(null); setForm(blank()); setOpen(true); };
  const openEdit = (s: any) => { setEditing(s); setForm({ ...s }); setOpen(true); };

  const save = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.designation) return notify('Name and designation required', 'error');
    if (editing) {
      update('staff', editing.id, { ...form, base_salary: Number(form.base_salary) });
      logActivity(user!, `Updated staff ${form.name}`, 'staff', editing.id);
      notify('Staff updated');
    } else {
      const created = insert('staff', { ...form, base_salary: Number(form.base_salary) });
      logActivity(user!, `Added staff ${form.name}`, 'staff', created.id);
      notify('Staff added');
    }
    setOpen(false);
  };

  const del = async (s: any) => {
    const ok = await confirm({ message: `Delete staff ${s.name}?`, danger: true, confirmText: 'Delete' });
    if (!ok) return;
    remove('staff', s.id);
    logActivity(user!, `Deleted staff ${s.name}`, 'staff', s.id);
    notify('Staff deleted');
  };

  const addDoc = (e: React.FormEvent) => {
    e.preventDefault();
    if (!docForm.file_name) return notify('File name required', 'error');
    insert('staffDocuments', { staff_id: docOpen.id, ...docForm, uploaded_at: new Date().toISOString() });
    logActivity(user!, `Uploaded ${docForm.doc_type} for ${docOpen.name}`, 'document', docOpen.id);
    notify('Document uploaded');
    setDocForm({ doc_type: 'Contract', file_name: '', expiry_date: '' });
  };

  const idCard = (s: any) => {
    const barcode = barcodeSvgString(s.employee_code, 300, 64);
    printDocument(`ID Card - ${s.name}`, `
      <div class="title">Employee ID Card</div>
      <div style="max-width:360px; border:1px solid #cbd5e1; border-radius:14px; overflow:hidden;">
        <div style="background:linear-gradient(to right,#2563eb,#4f46e5); color:#fff; text-align:center; padding:10px;">
          <div style="font-size:15px; font-weight:bold;">${getSettings().school_name}</div>
          <div style="font-size:10px; color:#dbeafe;">EMPLOYEE ID CARD</div>
        </div>
        <div style="display:flex; gap:12px; padding:16px; align-items:center;">
          <div style="width:64px; height:80px; background:#f3e8ff; border-radius:8px; display:flex; align-items:center; justify-content:center; font-size:34px;">👤</div>
          <div style="font-size:12px; color:#475569;">
            <div style="font-size:15px; font-weight:bold; color:#0f172a;">${s.name}</div>
            <div>${s.designation}</div>
            <div>${s.department || ''}</div>
            <div style="color:#94a3b8;">${s.employee_code}</div>
          </div>
        </div>
        <div style="border-top:1px solid #e2e8f0; padding:8px; text-align:center;">${barcode}</div>
      </div>
    `);
    logActivity(user!, `Generated ID card for ${s.name}`, 'staff', s.id);
  };

  return (
    <div>
      <PageHeader
        title="Staff Management"
        subtitle="Staff records, documents and details"
        action={!readOnly && <Btn onClick={openNew}><span className="flex items-center gap-2"><Plus className="h-4 w-4" /> Add Staff</span></Btn>}
      />

      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-left text-slate-600">
                <th className="pb-3 font-medium">Code</th>
                <th className="pb-3 font-medium">Name</th>
                <th className="pb-3 font-medium">Designation</th>
                <th className="pb-3 font-medium">Department</th>
                <th className="pb-3 font-medium">Salary</th>
                <th className="pb-3 font-medium">Joined</th>
                <th className="pb-3 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {staff.map((s) => (
                <tr key={s.id} className="border-b border-slate-100">
                  <td className="py-3 text-slate-600">{s.employee_code}</td>
                  <td className="py-3 font-medium text-slate-900">{s.name}</td>
                  <td className="py-3 text-slate-600">{s.designation}</td>
                  <td className="py-3 text-slate-600">{s.department || '-'}</td>
                  <td className="py-3 text-slate-600">{money(s.base_salary)}</td>
                  <td className="py-3 text-slate-500">{fmtDate(s.join_date)}</td>
                  <td className="py-3">
                    <div className="flex gap-1">
                      <button onClick={() => idCard(s)} className="rounded p-1.5 text-green-600 hover:bg-green-50" title="ID Card"><CreditCard className="h-4 w-4" /></button>
                      <button onClick={() => { setDocOpen(s); }} className="rounded p-1.5 text-indigo-600 hover:bg-indigo-50" title="Documents"><FolderOpen className="h-4 w-4" /></button>
                      {!readOnly && <button onClick={() => openEdit(s)} className="rounded p-1.5 text-blue-600 hover:bg-blue-50" title="Edit"><Pencil className="h-4 w-4" /></button>}
                      {!readOnly && <button onClick={() => del(s)} className="rounded p-1.5 text-red-600 hover:bg-red-50" title="Delete"><Trash2 className="h-4 w-4" /></button>}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {staff.length === 0 && <EmptyState message="No staff records" />}
        </div>
      </Card>

      <Modal open={open} onClose={() => setOpen(false)} title={editing ? 'Edit Staff' : 'Add Staff'} maxWidth="max-w-2xl">
        <form onSubmit={save} className="grid grid-cols-2 gap-4">
          <Field label="Full Name" required><Input value={form.name || ''} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
          <Field label="Employee Code"><Input value={form.employee_code || ''} onChange={(e) => setForm({ ...form, employee_code: e.target.value })} /></Field>
          <Field label="Designation" required><Input value={form.designation || ''} onChange={(e) => setForm({ ...form, designation: e.target.value })} /></Field>
          <Field label="Department"><Input value={form.department || ''} onChange={(e) => setForm({ ...form, department: e.target.value })} /></Field>
          <Field label="CNIC"><Input value={form.cnic || ''} onChange={(e) => setForm({ ...form, cnic: e.target.value })} /></Field>
          <Field label="Base Salary (PKR)"><Input type="number" value={form.base_salary || 0} onChange={(e) => setForm({ ...form, base_salary: e.target.value })} /></Field>
          <Field label="Contract Type">
            <Select value={form.contract_type || 'permanent'} onChange={(e) => setForm({ ...form, contract_type: e.target.value })}>
              <option value="permanent">Permanent</option>
              <option value="contract">Contract</option>
              <option value="part_time">Part Time</option>
            </Select>
          </Field>
          <Field label="Join Date"><Input type="date" value={form.join_date || ''} onChange={(e) => setForm({ ...form, join_date: e.target.value })} /></Field>
          <div className="col-span-2 mt-2 border-t border-slate-100 pt-3"><p className="text-xs font-semibold uppercase tracking-wide text-slate-400">Salary Transfer Details</p></div>
          <Field label="Bank Name"><Input value={form.bank_name || ''} onChange={(e) => setForm({ ...form, bank_name: e.target.value })} placeholder="e.g. HBL" /></Field>
          <Field label="Account Title"><Input value={form.bank_account_title || ''} onChange={(e) => setForm({ ...form, bank_account_title: e.target.value })} /></Field>
          <Field label="Account Number"><Input value={form.bank_account || ''} onChange={(e) => setForm({ ...form, bank_account: e.target.value })} /></Field>
          <Field label="IBAN"><Input value={form.iban || ''} onChange={(e) => setForm({ ...form, iban: e.target.value })} placeholder="PK..." /></Field>
          <Field label="EasyPaisa (optional)"><Input value={form.easypaisa || ''} onChange={(e) => setForm({ ...form, easypaisa: e.target.value })} /></Field>
          <Field label="JazzCash (optional)"><Input value={form.jazzcash || ''} onChange={(e) => setForm({ ...form, jazzcash: e.target.value })} /></Field>
          <div className="col-span-2 flex justify-end gap-2 pt-2">
            <Btn variant="secondary" onClick={() => setOpen(false)}>Cancel</Btn>
            <Btn type="submit">{editing ? 'Update' : 'Add'}</Btn>
          </div>
        </form>
      </Modal>

      <Modal open={!!docOpen} onClose={() => setDocOpen(null)} title={`Documents - ${docOpen?.name || ''}`}>
        <div className="space-y-4">
          <div className="space-y-2">
            {documents.filter((d) => d.staff_id === docOpen?.id).map((d) => (
              <div key={d.id} className="flex items-center justify-between rounded-lg bg-slate-50 p-3">
                <div>
                  <p className="text-sm font-medium text-slate-900">{d.doc_type}</p>
                  <p className="text-xs text-slate-500">{d.file_name} {d.expiry_date && `· expires ${fmtDate(d.expiry_date)}`}</p>
                </div>
                <button onClick={() => { remove('staffDocuments', d.id); notify('Document removed'); }} className="rounded p-1.5 text-red-600 hover:bg-red-50"><Trash2 className="h-4 w-4" /></button>
              </div>
            ))}
            {documents.filter((d) => d.staff_id === docOpen?.id).length === 0 && <EmptyState message="No documents" />}
          </div>
          {!readOnly && (
            <form onSubmit={addDoc} className="space-y-3 border-t border-slate-200 pt-4">
              <Field label="Document Type">
                <Select value={docForm.doc_type} onChange={(e) => setDocForm({ ...docForm, doc_type: e.target.value })}>
                  <option>Contract</option><option>Certificate</option><option>CNIC Copy</option><option>Degree</option><option>Other</option>
                </Select>
              </Field>
              <Field label="File Name" required><Input value={docForm.file_name} onChange={(e) => setDocForm({ ...docForm, file_name: e.target.value })} placeholder="e.g. contract_2024.pdf" /></Field>
              <Field label="Expiry Date"><Input type="date" value={docForm.expiry_date} onChange={(e) => setDocForm({ ...docForm, expiry_date: e.target.value })} /></Field>
              <div className="flex justify-end"><Btn type="submit">Upload Document</Btn></div>
            </form>
          )}
        </div>
      </Modal>
    </div>
  );
}
