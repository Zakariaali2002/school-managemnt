import { useState } from 'react';
import { Plus, Pencil, Trash2, Check, X, Eye, FileText, Search } from 'lucide-react';
import { useCollection } from '../../hooks/useDB';
import { insert, update, remove, logActivity } from '../../lib/db';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../components/ui/Toast';
import { useConfirm } from '../../components/ui/Confirm';
import { Modal } from '../../components/ui/Modal';
import { Field, Input, Select } from '../../components/ui/Field';
import { PageHeader, Card, Btn, EmptyState } from '../../components/ui/Shared';
import { fmtDate } from '../../lib/utils';
import { DOC_STATUS } from '../../lib/documents';

const ROLES = ['principal', 'hr', 'accounts', 'teacher', 'student', 'parent'];

export function DocumentAdminPage({ canManageCategories = false }: { canManageCategories?: boolean }) {
  const { user } = useAuth();
  const { notify } = useToast();
  const confirm = useConfirm();
  const categories = useCollection<any>('documentCategories');
  const documents = useCollection<any>('documents');
  const users = useCollection<any>('users');

  const [tab, setTab] = useState<'verify' | 'all' | 'categories'>('verify');
  const [catOpen, setCatOpen] = useState(false);
  const [editingCat, setEditingCat] = useState<any>(null);
  const [catForm, setCatForm] = useState({ role: 'teacher', name: '', has_expiry: false, required: true, allowed_types: 'all' });
  const [reviewDoc, setReviewDoc] = useState<any>(null);
  const [remarks, setRemarks] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');
  const [search, setSearch] = useState('');

  const userName = (id: string) => users.find((u) => u.id === id)?.name || '-';
  const userRole = (id: string) => users.find((u) => u.id === id)?.role || '-';
  const catName = (id: string) => categories.find((c) => c.id === id)?.name || '-';

  // ---- Categories CRUD ----
  const openNewCat = () => { setEditingCat(null); setCatForm({ role: 'teacher', name: '', has_expiry: false, required: true, allowed_types: 'all' }); setCatOpen(true); };
  const openEditCat = (c: any) => { setEditingCat(c); setCatForm({ role: c.role, name: c.name, has_expiry: c.has_expiry, required: c.required, allowed_types: c.allowed_types || 'all' }); setCatOpen(true); };
  const saveCat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!catForm.name) return notify('Name required', 'error');
    if (editingCat) { update('documentCategories', editingCat.id, catForm); notify('Category updated'); logActivity(user!, `Updated document category ${catForm.name}`, 'doc_category', editingCat.id); }
    else { const c = insert('documentCategories', catForm); notify('Category created'); logActivity(user!, `Created document category ${catForm.name}`, 'doc_category', c.id); }
    setCatOpen(false);
  };
  const delCat = async (c: any) => {
    const ok = await confirm({ message: `Delete category "${c.name}"?`, danger: true, confirmText: 'Delete' });
    if (!ok) return;
    remove('documentCategories', c.id);
    notify('Category deleted');
  };
  const toggleRequired = (c: any) => {
    update('documentCategories', c.id, { required: !c.required });
    logActivity(user!, `Set "${c.name}" as ${!c.required ? 'mandatory' : 'optional'}`, 'doc_category', c.id);
    notify(`"${c.name}" is now ${!c.required ? 'Mandatory' : 'Optional'}`);
  };

  // ---- Verification ----
  const approve = (d: any) => {
    update('documents', d.id, { status: 'verified', verified_by: user!.id, remarks: '' });
    logActivity(user!, `Verified document ${catName(d.category_id)} for ${userName(d.user_id)}`, 'document', d.id);
    notify('Document verified');
    setReviewDoc(null);
  };
  const reject = (d: any) => {
    if (!remarks.trim()) return notify('Please add remarks for rejection', 'error');
    update('documents', d.id, { status: 'rejected', verified_by: user!.id, remarks });
    logActivity(user!, `Rejected document ${catName(d.category_id)} for ${userName(d.user_id)}`, 'document', d.id);
    notify('Document rejected');
    setReviewDoc(null);
    setRemarks('');
  };

  const viewDoc = (d: any) => {
    if (d.file_data) {
      const w = window.open();
      if (w) {
        if (d.file_type === 'application/pdf') w.document.write(`<iframe src="${d.file_data}" style="width:100%;height:100%;border:none;"></iframe>`);
        else w.document.write(`<img src="${d.file_data}" style="max-width:100%;"/>`);
      }
    } else notify('Sample document (no file data)', 'info');
  };

  const pending = documents.filter((d) => d.status === 'pending');
  const allDocs = documents.filter((d) => {
    const mr = roleFilter === 'all' || userRole(d.user_id) === roleFilter;
    const ms = !search || userName(d.user_id).toLowerCase().includes(search.toLowerCase()) || catName(d.category_id).toLowerCase().includes(search.toLowerCase());
    return mr && ms;
  });

  const tabs: { key: typeof tab; label: string; count?: number }[] = [
    { key: 'verify', label: 'Verification Queue', count: pending.length },
    { key: 'all', label: 'All Documents' },
    ...(canManageCategories ? [{ key: 'categories' as const, label: 'Categories' }] : []),
  ];

  return (
    <div>
      <PageHeader title="Document Management" subtitle="Verify documents and manage categories"
        action={tab === 'categories' && canManageCategories ? <Btn onClick={openNewCat}><span className="flex items-center gap-2"><Plus className="h-4 w-4" /> Add Category</span></Btn> : undefined} />

      <Card>
        <div className="mb-4 flex flex-wrap gap-2">
          {tabs.map((t) => (
            <button key={t.key} onClick={() => setTab(t.key)}
              className={`rounded-lg px-4 py-2 text-sm font-medium ${tab === t.key ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}>
              {t.label}{t.count ? ` (${t.count})` : ''}
            </button>
          ))}
        </div>

        {/* Verification queue */}
        {tab === 'verify' && (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200 text-left text-slate-600">
                  <th className="pb-3 font-medium">User</th><th className="pb-3 font-medium">Role</th>
                  <th className="pb-3 font-medium">Document</th><th className="pb-3 font-medium">File</th>
                  <th className="pb-3 font-medium">Uploaded</th><th className="pb-3 font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {pending.map((d) => (
                  <tr key={d.id} className="border-b border-slate-100">
                    <td className="py-3 font-medium text-slate-900">{userName(d.user_id)}</td>
                    <td className="py-3 capitalize text-slate-600">{userRole(d.user_id)}</td>
                    <td className="py-3 text-slate-600">{catName(d.category_id)}</td>
                    <td className="py-3 text-slate-600">{d.file_name}</td>
                    <td className="py-3 text-slate-500">{fmtDate(d.uploaded_at)}</td>
                    <td className="py-3">
                      <div className="flex gap-1">
                        <button onClick={() => viewDoc(d)} className="rounded p-1.5 text-blue-600 hover:bg-blue-50" title="View"><Eye className="h-4 w-4" /></button>
                        <button onClick={() => approve(d)} className="rounded bg-green-100 p-1.5 text-green-700 hover:bg-green-200" title="Approve"><Check className="h-4 w-4" /></button>
                        <button onClick={() => { setReviewDoc(d); setRemarks(''); }} className="rounded bg-red-100 p-1.5 text-red-700 hover:bg-red-200" title="Reject"><X className="h-4 w-4" /></button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {pending.length === 0 && <EmptyState message="No documents pending verification 🎉" />}
          </div>
        )}

        {/* All documents */}
        {tab === 'all' && (
          <>
            <div className="mb-4 flex flex-wrap gap-3">
              <div className="relative min-w-[200px] flex-1">
                <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search by user or document..."
                  className="w-full rounded-md border border-slate-300 py-2 pl-9 pr-3 text-sm focus:border-blue-500 focus:outline-none" />
              </div>
              <Select value={roleFilter} onChange={(e) => setRoleFilter(e.target.value)} className="max-w-[180px]">
                <option value="all">All Roles</option>
                {ROLES.map((r) => <option key={r} value={r}>{r}</option>)}
              </Select>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-slate-200 text-left text-slate-600">
                    <th className="pb-3 font-medium">User</th><th className="pb-3 font-medium">Document</th>
                    <th className="pb-3 font-medium">Uploaded</th><th className="pb-3 font-medium">Expiry</th>
                    <th className="pb-3 font-medium">Status</th><th className="pb-3 font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {allDocs.map((d) => (
                    <tr key={d.id} className="border-b border-slate-100">
                      <td className="py-3 font-medium text-slate-900">{userName(d.user_id)}</td>
                      <td className="py-3 text-slate-600"><span className="flex items-center gap-1"><FileText className="h-4 w-4 text-slate-400" />{catName(d.category_id)}</span></td>
                      <td className="py-3 text-slate-500">{fmtDate(d.uploaded_at)}</td>
                      <td className="py-3 text-slate-500">{d.expiry_date ? fmtDate(d.expiry_date) : '-'}</td>
                      <td className="py-3"><span className={`rounded-full px-2 py-1 text-xs font-medium ${DOC_STATUS[d.status as keyof typeof DOC_STATUS]?.color}`}>{DOC_STATUS[d.status as keyof typeof DOC_STATUS]?.label}</span></td>
                      <td className="py-3">
                        <div className="flex gap-1">
                          <button onClick={() => viewDoc(d)} className="rounded p-1.5 text-blue-600 hover:bg-blue-50"><Eye className="h-4 w-4" /></button>
                          {d.status !== 'verified' && <button onClick={() => approve(d)} className="rounded bg-green-100 p-1.5 text-green-700 hover:bg-green-200"><Check className="h-4 w-4" /></button>}
                          {d.status !== 'rejected' && <button onClick={() => { setReviewDoc(d); setRemarks(''); }} className="rounded bg-red-100 p-1.5 text-red-700 hover:bg-red-200"><X className="h-4 w-4" /></button>}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {allDocs.length === 0 && <EmptyState message="No documents found" />}
            </div>
          </>
        )}

        {/* Categories */}
        {tab === 'categories' && canManageCategories && (
          <div className="space-y-6">
            {ROLES.map((role) => {
              const roleCats = categories.filter((c) => c.role === role);
              return (
                <div key={role}>
                  <h3 className="mb-2 text-sm font-semibold capitalize text-slate-700">{role} Documents</h3>
                  <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
                    {roleCats.map((c) => (
                      <div key={c.id} className="flex items-center justify-between rounded-lg border border-slate-200 px-3 py-2 text-sm">
                        <div>
                          <span className="font-medium text-slate-900">{c.name}</span>
                          <div className="mt-0.5 flex flex-wrap gap-1">
                            <button
                              onClick={() => toggleRequired(c)}
                              title="Click to toggle mandatory / optional"
                              className={`rounded px-1.5 text-[10px] font-medium ${c.required ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'}`}>
                              {c.required ? '⚠️ Mandatory' : '✓ Optional'}
                            </button>
                            {c.has_expiry && <span className="rounded bg-orange-100 px-1.5 text-[10px] text-orange-700">Expires</span>}
                          </div>
                        </div>
                        <div className="flex gap-1">
                          <button onClick={() => openEditCat(c)} className="rounded p-1 text-blue-600 hover:bg-blue-50"><Pencil className="h-3.5 w-3.5" /></button>
                          <button onClick={() => delCat(c)} className="rounded p-1 text-red-600 hover:bg-red-50"><Trash2 className="h-3.5 w-3.5" /></button>
                        </div>
                      </div>
                    ))}
                    {roleCats.length === 0 && <p className="text-xs text-slate-400">No categories</p>}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </Card>

      {/* Category modal */}
      <Modal open={catOpen} onClose={() => setCatOpen(false)} title={editingCat ? 'Edit Category' : 'Add Category'}>
        <form onSubmit={saveCat} className="space-y-4">
          <Field label="Applies To Role" required>
            <Select value={catForm.role} onChange={(e) => setCatForm({ ...catForm, role: e.target.value })}>
              {ROLES.map((r) => <option key={r} value={r}>{r}</option>)}
            </Select>
          </Field>
          <Field label="Document Name" required><Input value={catForm.name} onChange={(e) => setCatForm({ ...catForm, name: e.target.value })} placeholder="e.g. CNIC, Degree" /></Field>

          {/* Mandatory vs Optional selector */}
          <Field label="Is this document mandatory?" required>
            <div className="grid grid-cols-2 gap-3">
              <button type="button" onClick={() => setCatForm({ ...catForm, required: true })}
                className={`rounded-lg border-2 px-4 py-3 text-left text-sm transition ${catForm.required ? 'border-red-500 bg-red-50' : 'border-slate-200 hover:border-slate-300'}`}>
                <span className="block font-semibold text-slate-900">⚠️ Mandatory</span>
                <span className="text-xs text-slate-500">User must upload this. Shown in missing alerts.</span>
              </button>
              <button type="button" onClick={() => setCatForm({ ...catForm, required: false })}
                className={`rounded-lg border-2 px-4 py-3 text-left text-sm transition ${!catForm.required ? 'border-green-500 bg-green-50' : 'border-slate-200 hover:border-slate-300'}`}>
                <span className="block font-semibold text-slate-900">✓ Optional</span>
                <span className="text-xs text-slate-500">User may upload if available. Not enforced.</span>
              </button>
            </div>
          </Field>

          <label className="flex items-center gap-2 text-sm text-slate-700">
            <input type="checkbox" checked={catForm.has_expiry} onChange={(e) => setCatForm({ ...catForm, has_expiry: e.target.checked })} /> Has Expiry Date (e.g. CNIC, Passport, Contract)
          </label>

          <Field label="Allowed File Types">
            <Select value={catForm.allowed_types} onChange={(e) => setCatForm({ ...catForm, allowed_types: e.target.value })}>
              <option value="all">PDF, JPG, PNG (all)</option>
              <option value="pdf">PDF only</option>
              <option value="image">Images only (JPG, PNG)</option>
            </Select>
          </Field>

          <div className="flex justify-end gap-2 pt-2"><Btn variant="secondary" onClick={() => setCatOpen(false)}>Cancel</Btn><Btn type="submit">{editingCat ? 'Update' : 'Create'}</Btn></div>
        </form>
      </Modal>

      {/* Reject modal */}
      <Modal open={!!reviewDoc} onClose={() => setReviewDoc(null)} title="Reject Document">
        <div className="space-y-4">
          <p className="text-sm text-slate-600">Rejecting <span className="font-medium">{reviewDoc && catName(reviewDoc.category_id)}</span> for <span className="font-medium">{reviewDoc && userName(reviewDoc.user_id)}</span></p>
          <Field label="Remarks" required>
            <textarea value={remarks} onChange={(e) => setRemarks(e.target.value)} rows={3}
              className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none"
              placeholder="e.g. Degree image blurred. Please upload again." />
          </Field>
          <div className="flex justify-end gap-2"><Btn variant="secondary" onClick={() => setReviewDoc(null)}>Cancel</Btn><Btn variant="danger" onClick={() => reject(reviewDoc)}>Reject</Btn></div>
        </div>
      </Modal>
    </div>
  );
}
