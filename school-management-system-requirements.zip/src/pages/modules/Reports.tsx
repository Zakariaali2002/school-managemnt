import { getAll } from '../../lib/db';
import { useCollection } from '../../hooks/useDB';
import { PageHeader, Card, Btn } from '../../components/ui/Shared';
import { money, printDocument } from '../../lib/utils';
import { FileText, TrendingUp, Users, Wallet } from 'lucide-react';

export function ReportsPage() {
  const vouchers = useCollection<any>('feeVouchers');
  const payments = useCollection<any>('feePayments');
  const expenses = useCollection<any>('expenses');
  const students = useCollection<any>('students');
  const staff = useCollection<any>('staff');

  const collected = payments.reduce((a, p) => a + p.amount_paid, 0);
  const totalExpense = expenses.reduce((a, e) => a + e.amount, 0);
  const due = vouchers.filter((v) => v.status !== 'paid').reduce((a, v) => a + v.amount, 0);
  const net = collected - totalExpense;

  const financialReport = () => {
    const rows = expenses.map((e) => `<tr><td>${e.category}</td><td>${e.description}</td><td>${money(e.amount)}</td></tr>`).join('');
    printDocument('Monthly Financial Report', `
      <div class="title">Financial Summary Report</div>
      <div class="row"><span class="label">Total Fee Collected</span><span class="value">${money(collected)}</span></div>
      <div class="row"><span class="label">Total Fee Due</span><span class="value">${money(due)}</span></div>
      <div class="row"><span class="label">Total Expenses</span><span class="value">${money(totalExpense)}</span></div>
      <div class="row"><span class="label" style="font-size:16px;">Net Surplus/Deficit</span><span class="value" style="font-size:16px;">${money(net)}</span></div>
      <div class="title">Expense Breakdown</div>
      <table><thead><tr><th>Category</th><th>Description</th><th>Amount</th></tr></thead><tbody>${rows}</tbody></table>
    `);
  };

  const enrollmentReport = () => {
    const classes = getAll('classes');
    const rows = classes.map((c: any) => `<tr><td>${c.name}-${c.section}</td><td>${students.filter((s) => s.class_id === c.id).length}</td></tr>`).join('');
    printDocument('Enrollment Report', `
      <div class="title">Student Enrollment Report</div>
      <div class="row"><span class="label">Total Students</span><span class="value">${students.length}</span></div>
      <table><thead><tr><th>Class</th><th>Students</th></tr></thead><tbody>${rows}</tbody></table>
    `);
  };

  const defaultersReport = () => {
    const defaulters = vouchers.filter((v) => v.status === 'overdue');
    const rows = defaulters.map((v) => { const st = students.find((s) => s.id === v.student_id); return `<tr><td>${st?.name || '-'}</td><td>${v.voucher_no}</td><td>${money(v.amount)}</td></tr>`; }).join('');
    printDocument('Fee Defaulters Report', `
      <div class="title">Fee Defaulters Report</div>
      <table><thead><tr><th>Student</th><th>Voucher</th><th>Amount Due</th></tr></thead><tbody>${rows || '<tr><td colspan=3>No defaulters</td></tr>'}</tbody></table>
    `);
  };

  const staffReport = () => {
    const rows = staff.map((s) => `<tr><td>${s.employee_code}</td><td>${s.name}</td><td>${s.designation}</td><td>${money(s.base_salary)}</td></tr>`).join('');
    printDocument('Staff Report', `
      <div class="title">Staff Report</div>
      <table><thead><tr><th>Code</th><th>Name</th><th>Designation</th><th>Salary</th></tr></thead><tbody>${rows}</tbody></table>
    `);
  };

  const cards = [
    { title: 'Financial Report', desc: 'Income, expenses & net summary', icon: Wallet, color: 'from-blue-500 to-blue-600', action: financialReport },
    { title: 'Enrollment Report', desc: 'Class-wise student count', icon: Users, color: 'from-green-500 to-green-600', action: enrollmentReport },
    { title: 'Defaulters Report', desc: 'Students with overdue fees', icon: TrendingUp, color: 'from-red-500 to-red-600', action: defaultersReport },
    { title: 'Staff Report', desc: 'Complete staff directory', icon: FileText, color: 'from-purple-500 to-purple-600', action: staffReport },
  ];

  return (
    <div>
      <PageHeader title="Reports" subtitle="Generate and download printable reports" />

      <div className="mb-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card><p className="text-sm text-slate-600">Fee Collected</p><p className="mt-1 text-xl font-bold text-green-600">{money(collected)}</p></Card>
        <Card><p className="text-sm text-slate-600">Fee Due</p><p className="mt-1 text-xl font-bold text-yellow-600">{money(due)}</p></Card>
        <Card><p className="text-sm text-slate-600">Expenses</p><p className="mt-1 text-xl font-bold text-red-600">{money(totalExpense)}</p></Card>
        <Card><p className="text-sm text-slate-600">Net Balance</p><p className={`mt-1 text-xl font-bold ${net >= 0 ? 'text-blue-600' : 'text-red-600'}`}>{money(net)}</p></Card>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {cards.map((c) => (
          <Card key={c.title}>
            <div className={`mb-3 inline-flex h-12 w-12 items-center justify-center rounded-lg bg-gradient-to-br ${c.color}`}><c.icon className="h-6 w-6 text-white" /></div>
            <p className="font-semibold text-slate-900">{c.title}</p>
            <p className="mb-3 text-xs text-slate-500">{c.desc}</p>
            <Btn size="sm" onClick={c.action}>Generate PDF</Btn>
          </Card>
        ))}
      </div>
    </div>
  );
}
