import { useState } from 'react';
import { Check, X, Clock4, CalendarOff, Users2, FileDown, Search } from 'lucide-react';
import { useCollection } from '../../hooks/useDB';
import { insert, update, getAll, logActivity } from '../../lib/db';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../components/ui/Toast';
import { Select } from '../../components/ui/Field';
import { PageHeader, Btn, EmptyState } from '../../components/ui/Shared';
import { printDocument } from '../../lib/utils';
import { SelfAttendance } from '../../components/SelfAttendance';

const STATUS_CONFIG = [
  { key: 'present', label: 'Present', icon: Check, on: 'bg-emerald-500 text-white shadow-emerald-200', off: 'text-emerald-600 hover:bg-emerald-50' },
  { key: 'absent', label: 'Absent', icon: X, on: 'bg-rose-500 text-white shadow-rose-200', off: 'text-rose-600 hover:bg-rose-50' },
  { key: 'late', label: 'Late', icon: Clock4, on: 'bg-amber-500 text-white shadow-amber-200', off: 'text-amber-600 hover:bg-amber-50' },
  { key: 'leave', label: 'Leave', icon: CalendarOff, on: 'bg-sky-500 text-white shadow-sky-200', off: 'text-sky-600 hover:bg-sky-50' },
];

// ---------- TEACHER: Class attendance marking (modern grid) ----------
export function AttendancePage() {
  const classes = useCollection<any>('classes');
  const students = useCollection<any>('students');
  const records = useCollection<any>('studentAttendance');
  const { user } = useAuth();
  const { notify } = useToast();
  const [classId, setClassId] = useState(classes[0]?.id || '');
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [marks, setMarks] = useState<Record<string, string>>({});
  const [search, setSearch] = useState('');

  const classStudents = students
    .filter((s) => s.class_id === classId)
    .filter((s) => !search || s.name.toLowerCase().includes(search.toLowerCase()) || String(s.roll_no).includes(search));

  const existing = (sid: string) => records.find((r) => r.student_id === sid && r.date === date);
  const getStatus = (sid: string) => marks[sid] || existing(sid)?.status || 'present';

  const counts = classStudents.reduce(
    (acc, s) => { acc[getStatus(s.id)] = (acc[getStatus(s.id)] || 0) + 1; return acc; },
    {} as Record<string, number>,
  );

  const submit = () => {
    if (!classId) return notify('Select a class', 'error');
    classStudents.forEach((s) => {
      const status = getStatus(s.id);
      const rec = existing(s.id);
      if (rec) update('studentAttendance', rec.id, { status });
      else insert('studentAttendance', { student_id: s.id, class_id: classId, date, status, marked_by: user!.id });
    });
    logActivity(user!, `Marked attendance for ${classStudents.length} students`, 'attendance', classId);
    notify('Attendance saved', 'success');
    setMarks({});
  };

  const setAll = (st: string) => setMarks(Object.fromEntries(getAll('students').filter((s: any) => s.class_id === classId).map((s: any) => [s.id, st])));

  const monthlyReport = () => {
    const cls = classes.find((c) => c.id === classId);
    const recs = getAll('studentAttendance').filter((r: any) => r.class_id === classId);
    if (recs.length === 0) return notify('No attendance data for this class', 'error');
    const rows = students.filter((s) => s.class_id === classId).map((s) => {
      const sr = recs.filter((r: any) => r.student_id === s.id);
      const present = sr.filter((r: any) => r.status === 'present').length;
      const absent = sr.filter((r: any) => r.status === 'absent').length;
      const late = sr.filter((r: any) => r.status === 'late').length;
      const pct = sr.length ? ((present / sr.length) * 100).toFixed(0) : '0';
      return `<tr><td>${s.roll_no}</td><td>${s.name}</td><td>${present}</td><td>${absent}</td><td>${late}</td><td>${pct}%</td></tr>`;
    }).join('');
    printDocument(`Attendance Report - ${cls?.name}`, `
      <div class="title">Attendance Report - ${cls?.name}</div>
      <table><thead><tr><th>Roll</th><th>Student</th><th>Present</th><th>Absent</th><th>Late</th><th>%</th></tr></thead><tbody>${rows}</tbody></table>
    `);
    logActivity(user!, `Generated attendance report for ${cls?.name}`, 'attendance', classId);
  };

  const summaryTiles = [
    { label: 'Present', val: counts.present || 0, color: 'from-emerald-500 to-emerald-600' },
    { label: 'Absent', val: counts.absent || 0, color: 'from-rose-500 to-rose-600' },
    { label: 'Late', val: counts.late || 0, color: 'from-amber-500 to-amber-600' },
    { label: 'Leave', val: counts.leave || 0, color: 'from-sky-500 to-sky-600' },
  ];

  return (
    <div>
      <PageHeader title="Student Attendance" subtitle="Mark and review daily attendance"
        action={<Btn variant="secondary" onClick={monthlyReport}><span className="flex items-center gap-2"><FileDown className="h-4 w-4" /> Monthly Report</span></Btn>} />

      {/* Controls */}
      <div className="mb-5 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
        <div className="flex flex-wrap items-center gap-3">
          <Select value={classId} onChange={(e) => { setClassId(e.target.value); setMarks({}); }} className="max-w-[220px]">
            {classes.map((c) => <option key={c.id} value={c.id}>{c.name} - {c.section}</option>)}
          </Select>
          <input type="date" value={date} onChange={(e) => { setDate(e.target.value); setMarks({}); }}
            className="rounded-xl border border-slate-300 px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-100" />
          <div className="relative">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
            <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search student..."
              className="rounded-xl border border-slate-300 py-2 pl-9 pr-3 text-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-100" />
          </div>
          <div className="ml-auto flex flex-wrap gap-1.5">
            {STATUS_CONFIG.map((st) => (
              <button key={st.key} onClick={() => setAll(st.key)}
                className="rounded-lg border border-slate-200 px-2.5 py-1.5 text-xs font-medium text-slate-600 hover:bg-slate-50">
                Mark all {st.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Live summary tiles */}
      <div className="mb-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
        {summaryTiles.map((t) => (
          <div key={t.label} className={`rounded-2xl bg-gradient-to-br ${t.color} p-4 text-white shadow-sm`}>
            <p className="text-3xl font-bold">{t.val}</p>
            <p className="text-sm text-white/80">{t.label}</p>
          </div>
        ))}
      </div>

      {/* Student grid */}
      <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
        {classStudents.length === 0 ? (
          <EmptyState message="No students in this class" />
        ) : (
          <div className="grid gap-3 md:grid-cols-2">
            {classStudents.map((s) => {
              const cur = getStatus(s.id);
              return (
                <div key={s.id} className="flex items-center justify-between rounded-xl border border-slate-100 bg-slate-50/50 p-3">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-indigo-500 to-violet-500 text-sm font-semibold text-white">
                      {s.name.charAt(0)}
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-slate-800">{s.name}</p>
                      <p className="text-xs text-slate-400">Roll {s.roll_no}</p>
                    </div>
                  </div>
                  <div className="flex gap-1">
                    {STATUS_CONFIG.map((st) => {
                      const active = cur === st.key;
                      const Icon = st.icon;
                      return (
                        <button key={st.key} onClick={() => setMarks({ ...marks, [s.id]: st.key })} title={st.label}
                          className={`flex h-9 w-9 items-center justify-center rounded-lg text-sm font-medium transition ${active ? st.on + ' shadow-md' : 'bg-white ' + st.off}`}>
                          <Icon className="h-4 w-4" />
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {classStudents.length > 0 && (
          <div className="mt-4 flex items-center justify-between">
            <p className="flex items-center gap-2 text-sm text-slate-500"><Users2 className="h-4 w-4" /> {classStudents.length} students</p>
            <Btn onClick={submit}>Submit Attendance</Btn>
          </div>
        )}
      </div>
    </div>
  );
}

// ---------- STUDENT: self attendance portal ----------
export function AttendanceView({ studentId }: { studentId: string }) {
  const student = getAll('students').find((s: any) => s.id === studentId);
  const cls = getAll('classes').find((c: any) => c.id === student?.class_id);
  if (!student) return <PageHeader title="My Attendance" subtitle="No student profile linked" />;
  return (
    <div>
      <PageHeader title="My Attendance" subtitle="Check in, check out and track your record" />
      <SelfAttendance kind="student" entityId={student.id} name={student.name}
        meta={`${cls?.name || ''}${student.section ? ' - ' + student.section : ''} · Roll ${student.roll_no}`}
        classId={student.class_id} />
    </div>
  );
}

// ---------- STAFF/TEACHER: self attendance portal ----------
export function StaffAttendanceView({ staffId }: { staffId: string }) {
  const staff = getAll('staff').find((s: any) => s.id === staffId);
  if (!staff) return <PageHeader title="My Attendance" subtitle="No staff profile linked" />;
  return (
    <div>
      <PageHeader title="My Attendance" subtitle="Check in, check out and track your record" />
      <SelfAttendance kind="staff" entityId={staff.id} name={staff.name} meta={staff.designation} />
    </div>
  );
}
