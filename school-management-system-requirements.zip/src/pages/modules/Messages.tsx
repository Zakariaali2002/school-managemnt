import { useState } from 'react';
import { Send } from 'lucide-react';
import { useCollection } from '../../hooks/useDB';
import { insert, update, logActivity } from '../../lib/db';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../components/ui/Toast';
import { Field, Input, Select, Textarea } from '../../components/ui/Field';
import { PageHeader, Card, Btn, EmptyState } from '../../components/ui/Shared';
import { fmtDate } from '../../lib/utils';

export function MessagesPage() {
  const messages = useCollection<any>('messages');
  const users = useCollection<any>('users');
  const { user } = useAuth();
  const { notify } = useToast();
  const [tab, setTab] = useState<'inbox' | 'sent' | 'compose'>('inbox');
  const [form, setForm] = useState({ receiver_id: '', subject: '', body: '' });

  // Teachers/admins are valid recipients; parents/students message teachers.
  const recipients = users.filter((u) => u.id !== user?.id && ['teacher', 'principal', 'hr', 'parent'].includes(u.role));

  const inbox = messages.filter((m) => m.receiver_id === user?.id);
  const sent = messages.filter((m) => m.sender_id === user?.id);

  const send = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.receiver_id || !form.body) return notify('Recipient and message required', 'error');
    const rec = users.find((u) => u.id === form.receiver_id);
    insert('messages', { sender_id: user!.id, sender_name: user!.name, receiver_id: form.receiver_id, receiver_name: rec?.name, subject: form.subject, body: form.body, sent_at: new Date().toISOString(), is_read: false, thread_id: 'th-' + Date.now() });
    logActivity(user!, `Sent message to ${rec?.name}`, 'message');
    notify('Message sent');
    setForm({ receiver_id: '', subject: '', body: '' });
    setTab('sent');
  };

  const markRead = (m: any) => { if (!m.is_read) update('messages', m.id, { is_read: true }); };

  const list = tab === 'inbox' ? inbox : sent;

  return (
    <div>
      <PageHeader title="Messages" subtitle="Internal communication" />
      <Card>
        <div className="mb-4 flex gap-2">
          {(['inbox', 'sent', 'compose'] as const).map((t) => (
            <button key={t} onClick={() => setTab(t)} className={`rounded-lg px-4 py-2 text-sm font-medium capitalize ${tab === t ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}>
              {t} {t === 'inbox' && inbox.filter((m) => !m.is_read).length > 0 && `(${inbox.filter((m) => !m.is_read).length})`}
            </button>
          ))}
        </div>

        {tab === 'compose' ? (
          <form onSubmit={send} className="max-w-lg space-y-4">
            <Field label="To" required>
              <Select value={form.receiver_id} onChange={(e) => setForm({ ...form, receiver_id: e.target.value })}>
                <option value="">Select recipient...</option>
                {recipients.map((r) => <option key={r.id} value={r.id}>{r.name} ({r.role})</option>)}
              </Select>
            </Field>
            <Field label="Subject"><Input value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} /></Field>
            <Field label="Message" required><Textarea rows={4} value={form.body} onChange={(e) => setForm({ ...form, body: e.target.value })} /></Field>
            <Btn type="submit"><span className="flex items-center gap-2"><Send className="h-4 w-4" /> Send Message</span></Btn>
          </form>
        ) : (
          <div className="space-y-2">
            {list.slice().reverse().map((m) => (
              <div key={m.id} onClick={() => markRead(m)} className={`cursor-pointer rounded-lg border p-3 ${!m.is_read && tab === 'inbox' ? 'border-blue-200 bg-blue-50' : 'border-slate-100 bg-slate-50'}`}>
                <div className="flex items-center justify-between">
                  <p className="text-sm font-medium text-slate-900">{tab === 'inbox' ? m.sender_name : m.receiver_name}</p>
                  <span className="text-xs text-slate-400">{fmtDate(m.sent_at)}</span>
                </div>
                {m.subject && <p className="text-sm font-medium text-slate-700">{m.subject}</p>}
                <p className="mt-1 text-sm text-slate-600">{m.body}</p>
              </div>
            ))}
            {list.length === 0 && <EmptyState message={`No ${tab} messages`} />}
          </div>
        )}
      </Card>
    </div>
  );
}
