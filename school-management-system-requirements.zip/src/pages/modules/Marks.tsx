import { useState, useEffect } from 'react';
import { useCollection } from '../../hooks/useDB';
import { insert, update, logActivity } from '../../lib/db';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../components/ui/Toast';
import { Select } from '../../components/ui/Field';
import { PageHeader, Card, Btn, EmptyState } from '../../components/ui/Shared';
import { calcGrade } from '../../lib/utils';

export function MarksPage() {
  const exams = useCollection<any>('exams');
  const subjects = useCollection<any>('subjects');
  const students = useCollection<any>('students');
  const marks = useCollection<any>('marks');
  const { user } = useAuth();
  const { notify } = useToast();
  const [examId, setExamId] = useState(exams[0]?.id || '');
  const [subjectId, setSubjectId] = useState('');
  const [entries, setEntries] = useState<Record<string, string>>({});

  const exam = exams.find((e) => e.id === examId);
  const examSubjects = subjects.filter((s) => s.class_id === exam?.class_id);
  const classStudents = students.filter((s) => s.class_id === exam?.class_id);

  useEffect(() => {
    if (examSubjects.length && !examSubjects.find((s) => s.id === subjectId)) {
      setSubjectId(examSubjects[0]?.id || '');
    }
  }, [examId]);

  const existing = (sid: string) => marks.find((m) => m.student_id === sid && m.exam_id === examId && m.subject_id === subjectId);

  const get = (sid: string) => entries[sid] ?? (existing(sid)?.marks_obtained?.toString() || '');

  const save = () => {
    if (!examId || !subjectId) return notify('Select exam and subject', 'error');
    classStudents.forEach((s) => {
      const val = get(s.id);
      if (val === '') return;
      const num = Number(val);
      const grade = calcGrade(num);
      const rec = existing(s.id);
      if (rec) update('marks', rec.id, { marks_obtained: num, grade });
      else insert('marks', { student_id: s.id, exam_id: examId, subject_id: subjectId, marks_obtained: num, total_marks: 100, grade, entered_by: user!.id });
    });
    logActivity(user!, `Entered marks for ${exam?.name}`, 'marks', examId);
    notify('Marks saved');
    setEntries({});
  };

  return (
    <div>
      <PageHeader title="Marks Entry" subtitle="Record exam results per subject" />
      <Card title="Enter Marks">
        <div className="mb-4 flex flex-wrap gap-3">
          <Select value={examId} onChange={(e) => setExamId(e.target.value)} className="max-w-[220px]">
            {exams.map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}
          </Select>
          <Select value={subjectId} onChange={(e) => setSubjectId(e.target.value)} className="max-w-[220px]">
            {examSubjects.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </Select>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-left text-slate-600">
                <th className="pb-3 font-medium">Roll</th><th className="pb-3 font-medium">Student</th>
                <th className="pb-3 font-medium">Marks (/100)</th><th className="pb-3 font-medium">Grade</th>
              </tr>
            </thead>
            <tbody>
              {classStudents.map((s) => {
                const val = get(s.id);
                return (
                  <tr key={s.id} className="border-b border-slate-100">
                    <td className="py-2 text-slate-600">{s.roll_no}</td>
                    <td className="py-2 font-medium text-slate-900">{s.name}</td>
                    <td className="py-2">
                      <input type="number" min={0} max={100} value={val}
                        onChange={(e) => setEntries({ ...entries, [s.id]: e.target.value })}
                        className="w-24 rounded border border-slate-300 px-2 py-1 text-sm" />
                    </td>
                    <td className="py-2 font-medium text-slate-700">{val !== '' ? calcGrade(Number(val)) : '-'}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {classStudents.length === 0 && <EmptyState message="No students for this exam's class" />}
        </div>
        {classStudents.length > 0 && <div className="mt-4 flex justify-end"><Btn onClick={save}>Save Marks</Btn></div>}
      </Card>
    </div>
  );
}
