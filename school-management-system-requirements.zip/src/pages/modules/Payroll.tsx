import { useState } from 'react';
import { FileText, Play, TrendingUp, Banknote, Download } from 'lucide-react';
import { useCollection } from '../../hooks/useDB';
import { insert, update, logActivity, getById } from '../../lib/db';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../components/ui/Toast';
import { useConfirm } from '../../components/ui/Confirm';
import { Modal } from '../../components/ui/Modal';
import { Field, Input, Select } from '../../components/ui/Field';
import { PageHeader, Card, Btn, EmptyState, StatCard } from '../../components/ui/Shared';
import { StatusBadge, money, fmtDate, printDocument } from '../../lib/utils';
import { sendMessage } from '../../lib/messaging';

export function PayrollPage() {
  const staff = useCollection<any>('staff');
  const payroll = useCollection<any>('payroll');
  const increments = useCollection<any>('salaryIncrements');
  const { user } = useAuth();
  const { notify } = useToast();
  const confirm = useConfirm();
  const [genOpen, setGenOpen] = useState(false);
  const [incOpen, setIncOpen] = useState(false);
  const [gen, setGen] = useState({ month: new Date().getMonth() + 1, year: new Date().getFullYear(), allowances: 5000, deductions: 1500, bonus: 0, overtime: 0 });
  const [inc, setInc] = useState({ staff_id: staff[0]?.id || '', increment_amount: 5000, reason: '', effective_date: new Date().toISOString().slice(0, 10) });

  const staffName = (id: string) => staff.find((s) => s.id === id)?.name || '-';

  const generate = (e: React.FormEvent) => {
    e.preventDefault();
    let count = 0;
    staff.forEach((s) => {
      const dupe = payroll.find((p) => p.staff_id === s.id && p.month === Number(gen.month) && p.year === Number(gen.year));
      if (dupe) return;
      const allowances = Number(gen.allowances) + Number(gen.bonus) + Number(gen.overtime);
      const net = s.base_salary + allowances - Number(gen.deductions);
      insert('payroll', { staff_id: s.id, month: Number(gen.month), year: Number(gen.year), basic_salary: s.base_salary, allowances: Number(gen.allowances), bonus: Number(gen.bonus), overtime: Number(gen.overtime), deductions: Number(gen.deductions), net_salary: net, status: 'generated' });
      count++;
    });
    logActivity(user!, `Generated payroll for ${count} staff (${gen.month}/${gen.year})`, 'payroll');
    notify(`${count} payroll record(s) generated`);
    setGenOpen(false);
  };

  const markPaid = (p: any) => {
    update('payroll', p.id, { status: 'paid', paid_at: new Date().toISOString().slice(0, 10) });
    const s = getById<any>('staff', p.staff_id);
    sendMessage({ to: s?.name || 'Staff', channels: ['SMS', 'WhatsApp'], category: 'payroll', relatedId: p.id,
      title: 'Salary Transferred', body: `Dear ${s?.name}, your salary of ${money(p.net_salary)} for ${p.month}/${p.year} has been transferred to your account.` });
    logActivity(user!, `Marked salary paid for ${staffName(p.staff_id)}`, 'payroll', p.id);
    notify('Marked as paid · SMS sent');
  };

  // One-click: pay all generated (unpaid) salaries via bank transfer simulation.
  const payAll = async () => {
    const unpaid = payroll.filter((p) => p.status !== 'paid');
    if (unpaid.length === 0) return notify('No pending salaries to pay', 'info');
    const total = unpaid.reduce((a, p) => a + p.net_salary, 0);
    const ok = await confirm({
      message: `Transfer salaries to ${unpaid.length} staff (Total ${money(total)}) via bank? Each will receive an SMS/WhatsApp confirmation.`,
      confirmText: 'Pay All Staff',
    });
    if (!ok) return;
    unpaid.forEach((p) => {
      update('payroll', p.id, { status: 'paid', paid_at: new Date().toISOString().slice(0, 10) });
      const s = getById<any>('staff', p.staff_id);
      sendMessage({ to: s?.name || 'Staff', channels: ['SMS', 'WhatsApp'], category: 'payroll', relatedId: p.id,
        title: 'Salary Transferred', body: `Dear ${s?.name}, your salary of ${money(p.net_salary)} for ${p.month}/${p.year} has been transferred to ${s?.bank_name || 'your bank'} (${s?.bank_account || s?.iban || 'account on file'}).` });
    });
    logActivity(user!, `Paid all staff salaries (${unpaid.length} transfers, ${money(total)})`, 'payroll');
    notify(`${unpaid.length} salaries transferred · notifications sent`);
  };

  // Generate a bank transfer file (CSV) of pending salaries.
  const bankFile = () => {
    const unpaid = payroll.filter((p) => p.status !== 'paid');
    if (unpaid.length === 0) return notify('No pending salaries', 'info');
    const rows = unpaid.map((p) => {
      const s = getById<any>('staff', p.staff_id) || {};
      return `${s.name || ''},${s.bank_name || ''},${s.bank_account_title || s.name || ''},${s.bank_account || ''},${s.iban || ''},${p.net_salary}`;
    });
    const csv = 'Employee,Bank,Account Title,Account No,IBAN,Amount\n' + rows.join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `bank_transfer_${gen.month}_${gen.year}.csv`;
    a.click();
    logActivity(user!, `Downloaded bank transfer file (${unpaid.length} records)`, 'payroll');
    notify('Bank transfer file downloaded');
  };

  const slip = (p: any) => {
    printDocument(`Salary Slip - ${staffName(p.staff_id)}`, `
      <div class="title">Salary Slip - ${p.month}/${p.year}</div>
      <div class="row"><span class="label">Employee</span><span class="value">${staffName(p.staff_id)}</span></div>
      <div class="row"><span class="label">Basic Salary</span><span class="value">${money(p.basic_salary)}</span></div>
      <div class="row"><span class="label">Allowances</span><span class="value">+ ${money(p.allowances)}</span></div>
      <div class="row"><span class="label">Deductions</span><span class="value">- ${money(p.deductions)}</span></div>
      <div class="row"><span class="label" style="font-size:16px;">Net Salary</span><span class="value" style="font-size:16px;">${money(p.net_salary)}</span></div>
      <div class="row"><span class="label">Status</span><span class="value">${p.status.toUpperCase()}</span></div>
      <div class="signature"><div class="sign-box">Accountant</div><div class="sign-box">Employee Signature</div></div>
    `);
  };

  const addIncrement = (e: React.FormEvent) => {
    e.preventDefault();
    const s = staff.find((x) => x.id === inc.staff_id);
    if (!s) return;
    update('staff', s.id, { base_salary: s.base_salary + Number(inc.increment_amount) });
    insert('salaryIncrements', { ...inc, increment_amount: Number(inc.increment_amount), approved_by: user!.id });
    logActivity(user!, `Salary increment for ${s.name}: +${money(Number(inc.increment_amount))}`, 'increment', s.id);
    notify('Increment applied');
    setIncOpen(false);
  };

  const totalPayroll = payroll.reduce((a, p) => a + p.net_salary, 0);

  return (
    <div>
      <PageHeader title="Payroll Automation" subtitle="Generate salaries, bank transfers & increments"
        action={<div className="flex flex-wrap gap-2">
          <Btn variant="secondary" onClick={bankFile}><span className="flex items-center gap-2"><Download className="h-4 w-4" /> Bank File</span></Btn>
          <Btn variant="secondary" onClick={() => setIncOpen(true)}><span className="flex items-center gap-2"><TrendingUp className="h-4 w-4" /> Increment</span></Btn>
          <Btn variant="secondary" onClick={() => setGenOpen(true)}><span className="flex items-center gap-2"><Play className="h-4 w-4" /> Generate</span></Btn>
          <Btn variant="success" onClick={payAll}><span className="flex items-center gap-2"><Banknote className="h-4 w-4" /> Pay All Staff</span></Btn>
        </div>} />

      <div className="mb-6 grid gap-4 sm:grid-cols-3">
        <StatCard title="Total Staff" value={staff.length} icon={FileText} color="from-blue-500 to-blue-600" />
        <StatCard title="Payroll Records" value={payroll.length} icon={Play} color="from-green-500 to-green-600" />
        <StatCard title="Total Disbursed" value={money(totalPayroll)} icon={TrendingUp} color="from-purple-500 to-purple-600" />
      </div>

      <Card title="Payroll Records">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-left text-slate-600">
                <th className="pb-3 font-medium">Staff</th><th className="pb-3 font-medium">Period</th>
                <th className="pb-3 font-medium">Basic</th><th className="pb-3 font-medium">Net Salary</th>
                <th className="pb-3 font-medium">Status</th><th className="pb-3 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {payroll.slice().reverse().map((p) => (
                <tr key={p.id} className="border-b border-slate-100">
                  <td className="py-3 font-medium text-slate-900">{staffName(p.staff_id)}</td>
                  <td className="py-3 text-slate-600">{p.month}/{p.year}</td>
                  <td className="py-3 text-slate-600">{money(p.basic_salary)}</td>
                  <td className="py-3 font-medium text-slate-900">{money(p.net_salary)}</td>
                  <td className="py-3"><StatusBadge status={p.status} /></td>
                  <td className="py-3">
                    <div className="flex gap-1">
                      <button onClick={() => slip(p)} className="rounded p-1.5 text-green-600 hover:bg-green-50" title="Salary Slip"><FileText className="h-4 w-4" /></button>
                      {p.status !== 'paid' && <Btn size="sm" onClick={() => markPaid(p)}>Mark Paid</Btn>}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {payroll.length === 0 && <EmptyState message="No payroll generated yet" />}
        </div>
      </Card>

      {increments.length > 0 && (
        <div className="mt-6">
          <Card title="Increment History">
            <div className="space-y-2">
              {increments.slice().reverse().map((i: any) => (
                <div key={i.id} className="flex items-center justify-between rounded-lg bg-slate-50 p-3 text-sm">
                  <span className="font-medium text-slate-900">{staffName(i.staff_id)}</span>
                  <span className="text-green-600">+ {money(i.increment_amount)}</span>
                  <span className="text-slate-500">{i.reason}</span>
                  <span className="text-slate-400">{fmtDate(i.effective_date)}</span>
                </div>
              ))}
            </div>
          </Card>
        </div>
      )}

      <Modal open={genOpen} onClose={() => setGenOpen(false)} title="Generate Monthly Payroll">
        <form onSubmit={generate} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <Field label="Month"><Input type="number" min={1} max={12} value={gen.month} onChange={(e) => setGen({ ...gen, month: Number(e.target.value) })} /></Field>
            <Field label="Year"><Input type="number" value={gen.year} onChange={(e) => setGen({ ...gen, year: Number(e.target.value) })} /></Field>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Allowances (PKR)"><Input type="number" value={gen.allowances} onChange={(e) => setGen({ ...gen, allowances: Number(e.target.value) })} /></Field>
            <Field label="Deductions (PKR)"><Input type="number" value={gen.deductions} onChange={(e) => setGen({ ...gen, deductions: Number(e.target.value) })} /></Field>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Bonus (PKR)"><Input type="number" value={gen.bonus} onChange={(e) => setGen({ ...gen, bonus: Number(e.target.value) })} /></Field>
            <Field label="Overtime (PKR)"><Input type="number" value={gen.overtime} onChange={(e) => setGen({ ...gen, overtime: Number(e.target.value) })} /></Field>
          </div>
          <p className="text-xs text-slate-500">Applies to all {staff.length} staff. Bonus & overtime are added to net salary. Existing records for the period are skipped.</p>
          <div className="flex justify-end gap-2 pt-2"><Btn variant="secondary" onClick={() => setGenOpen(false)}>Cancel</Btn><Btn type="submit">Generate</Btn></div>
        </form>
      </Modal>

      <Modal open={incOpen} onClose={() => setIncOpen(false)} title="Salary Increment">
        <form onSubmit={addIncrement} className="space-y-4">
          <Field label="Staff" required>
            <Select value={inc.staff_id} onChange={(e) => setInc({ ...inc, staff_id: e.target.value })}>
              {staff.map((s) => <option key={s.id} value={s.id}>{s.name} ({money(s.base_salary)})</option>)}
            </Select>
          </Field>
          <Field label="Increment Amount (PKR)" required><Input type="number" value={inc.increment_amount} onChange={(e) => setInc({ ...inc, increment_amount: Number(e.target.value) })} /></Field>
          <Field label="Effective Date"><Input type="date" value={inc.effective_date} onChange={(e) => setInc({ ...inc, effective_date: e.target.value })} /></Field>
          <Field label="Reason"><Input value={inc.reason} onChange={(e) => setInc({ ...inc, reason: e.target.value })} /></Field>
          <div className="flex justify-end gap-2 pt-2"><Btn variant="secondary" onClick={() => setIncOpen(false)}>Cancel</Btn><Btn type="submit">Apply Increment</Btn></div>
        </form>
      </Modal>
    </div>
  );
}
