import { useState } from 'react';
import { Plus, Trash2, FileText, Check } from 'lucide-react';
import { useCollection } from '../../hooks/useDB';
import { insert, remove, update, logActivity, getAll } from '../../lib/db';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../components/ui/Toast';
import { useConfirm } from '../../components/ui/Confirm';
import { Modal } from '../../components/ui/Modal';
import { Field, Input, Select } from '../../components/ui/Field';
import { PageHeader, Card, Btn, EmptyState, StatCard } from '../../components/ui/Shared';
import { money, fmtDate, printDocument, StatusBadge } from '../../lib/utils';
import { TrendingUp, TrendingDown, Wallet } from 'lucide-react';

// ---------------- CASH BOOK ----------------
export function CashBookPage() {
  const entries = useCollection<any>('cashbook');
  const payments = useCollection<any>('feePayments');
  const expenses = useCollection<any>('expenses');
  const { user } = useAuth();
  const { notify } = useToast();
  const confirm = useConfirm();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ date: new Date().toISOString().slice(0, 10), type: 'in', description: '', amount: 0, ref: '' });

  // Build combined ledger: manual entries + fee payments (in) + expenses (out)
  const ledger = [
    ...entries.map((e) => ({ ...e, source: 'manual' })),
    ...payments.map((p) => ({ id: 'pay-' + p.id, date: (p.paid_at || p.created_at).slice(0, 10), type: 'in', description: 'Fee payment ' + (p.receipt_no || ''), amount: p.amount_paid, ref: p.receipt_no, source: 'fee' })),
    ...expenses.map((x) => ({ id: 'exp-' + x.id, date: (x.date || x.created_at).slice(0, 10), type: 'out', description: x.description, amount: x.amount, ref: x.category, source: 'expense' })),
  ].sort((a, b) => (a.date < b.date ? -1 : 1));

  let running = 0;
  const rows = ledger.map((e) => {
    running += e.type === 'in' ? e.amount : -e.amount;
    return { ...e, balance: running };
  });

  const totalIn = rows.filter((r) => r.type === 'in').reduce((a, r) => a + r.amount, 0);
  const totalOut = rows.filter((r) => r.type === 'out').reduce((a, r) => a + r.amount, 0);

  const save = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.description || !form.amount) return notify('Description and amount required', 'error');
    insert('cashbook', { ...form, amount: Number(form.amount) });
    logActivity(user!, `Cash book entry: ${form.description}`, 'cashbook');
    notify('Entry added');
    setOpen(false);
    setForm({ date: new Date().toISOString().slice(0, 10), type: 'in', description: '', amount: 0, ref: '' });
  };

  const del = async (e: any) => {
    if (e.source !== 'manual') return notify('Only manual entries can be deleted here', 'info');
    const ok = await confirm({ message: 'Delete this entry?', danger: true, confirmText: 'Delete' });
    if (!ok) return;
    remove('cashbook', e.id);
    notify('Entry deleted');
  };

  const dailyClosing = () => {
    const today = new Date().toISOString().slice(0, 10);
    const todays = rows.filter((r) => r.date === today);
    const tin = todays.filter((r) => r.type === 'in').reduce((a, r) => a + r.amount, 0);
    const tout = todays.filter((r) => r.type === 'out').reduce((a, r) => a + r.amount, 0);
    const rowsHtml = todays.map((r) => `<tr><td>${r.description}</td><td>${r.type === 'in' ? money(r.amount) : '-'}</td><td>${r.type === 'out' ? money(r.amount) : '-'}</td></tr>`).join('');
    printDocument('Daily Cash Closing', `
      <div class="title">Daily Cash Closing — ${fmtDate(today)}</div>
      <table><thead><tr><th>Description</th><th>Cash In</th><th>Cash Out</th></tr></thead><tbody>${rowsHtml || '<tr><td colspan=3>No transactions today</td></tr>'}</tbody></table>
      <div class="row"><span class="label">Total Cash In</span><span class="value">${money(tin)}</span></div>
      <div class="row"><span class="label">Total Cash Out</span><span class="value">${money(tout)}</span></div>
      <div class="row"><span class="label" style="font-size:16px;">Closing Balance</span><span class="value" style="font-size:16px;">${money(running)}</span></div>
      <div class="signature"><div class="sign-box">Cashier</div><div class="sign-box">Accounts Manager</div></div>
    `);
  };

  return (
    <div>
      <PageHeader title="Cash Book" subtitle="Complete cash ledger with running balance"
        action={<div className="flex gap-2">
          <Btn variant="secondary" onClick={dailyClosing}>Daily Closing</Btn>
          <Btn onClick={() => setOpen(true)}><span className="flex items-center gap-2"><Plus className="h-4 w-4" /> Add Entry</span></Btn>
        </div>} />

      <div className="mb-6 grid gap-4 sm:grid-cols-3">
        <StatCard title="Total Cash In" value={money(totalIn)} icon={TrendingUp} color="from-green-500 to-green-600" />
        <StatCard title="Total Cash Out" value={money(totalOut)} icon={TrendingDown} color="from-red-500 to-red-600" />
        <StatCard title="Current Balance" value={money(running)} icon={Wallet} color="from-blue-500 to-blue-600" />
      </div>

      <Card title="Cash Ledger">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-left text-slate-600">
                <th className="pb-3 font-medium">Date</th><th className="pb-3 font-medium">Description</th>
                <th className="pb-3 font-medium">Ref</th><th className="pb-3 font-medium text-right">Cash In</th>
                <th className="pb-3 font-medium text-right">Cash Out</th><th className="pb-3 font-medium text-right">Balance</th><th className="pb-3"></th>
              </tr>
            </thead>
            <tbody>
              {rows.slice().reverse().map((e) => (
                <tr key={e.id} className="border-b border-slate-100">
                  <td className="py-2 text-slate-500">{fmtDate(e.date)}</td>
                  <td className="py-2 font-medium text-slate-900">{e.description}</td>
                  <td className="py-2 text-slate-500">{e.ref || '-'}</td>
                  <td className="py-2 text-right text-green-600">{e.type === 'in' ? money(e.amount) : '-'}</td>
                  <td className="py-2 text-right text-red-600">{e.type === 'out' ? money(e.amount) : '-'}</td>
                  <td className="py-2 text-right font-medium text-slate-900">{money(e.balance)}</td>
                  <td className="py-2 text-right">{e.source === 'manual' && <button onClick={() => del(e)} className="rounded p-1 text-red-600 hover:bg-red-50"><Trash2 className="h-3.5 w-3.5" /></button>}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {rows.length === 0 && <EmptyState message="No cash entries" />}
        </div>
      </Card>

      <Modal open={open} onClose={() => setOpen(false)} title="Add Cash Entry">
        <form onSubmit={save} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <Field label="Date"><Input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} /></Field>
            <Field label="Type"><Select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}><option value="in">Cash In</option><option value="out">Cash Out</option></Select></Field>
          </div>
          <Field label="Description" required><Input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></Field>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Amount (PKR)" required><Input type="number" value={form.amount} onChange={(e) => setForm({ ...form, amount: Number(e.target.value) })} /></Field>
            <Field label="Reference"><Input value={form.ref} onChange={(e) => setForm({ ...form, ref: e.target.value })} /></Field>
          </div>
          <div className="flex justify-end gap-2 pt-2"><Btn variant="secondary" onClick={() => setOpen(false)}>Cancel</Btn><Btn type="submit">Add</Btn></div>
        </form>
      </Modal>
    </div>
  );
}

// ---------------- VOUCHERS (payment/receipt vouchers) ----------------
export function VouchersPage() {
  const vouchers = useCollection<any>('vouchers');
  const { user } = useAuth();
  const { notify } = useToast();
  const confirm = useConfirm();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ type: 'payment', payee: '', purpose: '', amount: 0, date: new Date().toISOString().slice(0, 10), method: 'Cash' });

  const save = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.payee || !form.amount) return notify('Payee and amount required', 'error');
    const no = (form.type === 'payment' ? 'PV-' : 'RV-') + new Date().getFullYear() + '-' + String(vouchers.length + 1).padStart(4, '0');
    insert('vouchers', { ...form, amount: Number(form.amount), voucher_no: no, created_by: user!.id });
    logActivity(user!, `Created ${form.type} voucher ${no}`, 'voucher');
    notify('Voucher created');
    setOpen(false);
    setForm({ type: 'payment', payee: '', purpose: '', amount: 0, date: new Date().toISOString().slice(0, 10), method: 'Cash' });
  };

  const del = async (v: any) => {
    const ok = await confirm({ message: `Delete voucher ${v.voucher_no}?`, danger: true, confirmText: 'Delete' });
    if (!ok) return;
    remove('vouchers', v.id);
    notify('Voucher deleted');
  };

  const print = (v: any) => {
    printDocument(`Voucher ${v.voucher_no}`, `
      <div class="title">${v.type === 'payment' ? 'Payment' : 'Receipt'} Voucher</div>
      <div class="row"><span class="label">Voucher No</span><span class="value">${v.voucher_no}</span></div>
      <div class="row"><span class="label">Date</span><span class="value">${fmtDate(v.date)}</span></div>
      <div class="row"><span class="label">${v.type === 'payment' ? 'Paid To' : 'Received From'}</span><span class="value">${v.payee}</span></div>
      <div class="row"><span class="label">Purpose</span><span class="value">${v.purpose || '-'}</span></div>
      <div class="row"><span class="label">Method</span><span class="value">${v.method}</span></div>
      <div class="row"><span class="label" style="font-size:16px;">Amount</span><span class="value" style="font-size:16px;">${money(v.amount)}</span></div>
      <div class="signature"><div class="sign-box">Prepared By</div><div class="sign-box">Approved By</div></div>
    `);
  };

  return (
    <div>
      <PageHeader title="Voucher Management" subtitle="Payment & receipt vouchers"
        action={<Btn onClick={() => setOpen(true)}><span className="flex items-center gap-2"><Plus className="h-4 w-4" /> New Voucher</span></Btn>} />
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-left text-slate-600">
                <th className="pb-3 font-medium">Voucher No</th><th className="pb-3 font-medium">Type</th>
                <th className="pb-3 font-medium">Payee</th><th className="pb-3 font-medium">Amount</th>
                <th className="pb-3 font-medium">Date</th><th className="pb-3 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {vouchers.slice().reverse().map((v) => (
                <tr key={v.id} className="border-b border-slate-100">
                  <td className="py-3 text-slate-600">{v.voucher_no}</td>
                  <td className="py-3"><span className={`rounded-full px-2 py-1 text-xs font-medium ${v.type === 'payment' ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'}`}>{v.type === 'payment' ? 'Payment' : 'Receipt'}</span></td>
                  <td className="py-3 font-medium text-slate-900">{v.payee}</td>
                  <td className="py-3 text-slate-600">{money(v.amount)}</td>
                  <td className="py-3 text-slate-500">{fmtDate(v.date)}</td>
                  <td className="py-3">
                    <div className="flex gap-1">
                      <button onClick={() => print(v)} className="rounded p-1.5 text-green-600 hover:bg-green-50" title="Print"><FileText className="h-4 w-4" /></button>
                      <button onClick={() => del(v)} className="rounded p-1.5 text-red-600 hover:bg-red-50"><Trash2 className="h-4 w-4" /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {vouchers.length === 0 && <EmptyState message="No vouchers created" />}
        </div>
      </Card>

      <Modal open={open} onClose={() => setOpen(false)} title="New Voucher">
        <form onSubmit={save} className="space-y-4">
          <Field label="Voucher Type"><Select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}><option value="payment">Payment Voucher</option><option value="receipt">Receipt Voucher</option></Select></Field>
          <Field label={form.type === 'payment' ? 'Paid To' : 'Received From'} required><Input value={form.payee} onChange={(e) => setForm({ ...form, payee: e.target.value })} /></Field>
          <Field label="Purpose"><Input value={form.purpose} onChange={(e) => setForm({ ...form, purpose: e.target.value })} /></Field>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Amount (PKR)" required><Input type="number" value={form.amount} onChange={(e) => setForm({ ...form, amount: Number(e.target.value) })} /></Field>
            <Field label="Method"><Select value={form.method} onChange={(e) => setForm({ ...form, method: e.target.value })}><option>Cash</option><option>Bank Transfer</option><option>Cheque</option></Select></Field>
          </div>
          <Field label="Date"><Input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} /></Field>
          <div className="flex justify-end gap-2 pt-2"><Btn variant="secondary" onClick={() => setOpen(false)}>Cancel</Btn><Btn type="submit">Create</Btn></div>
        </form>
      </Modal>
    </div>
  );
}

// ---------------- BANK RECONCILIATION ----------------
export function BankReconciliationPage() {
  const items = useCollection<any>('bankReconciliation');
  const { user } = useAuth();
  const { notify } = useToast();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ date: new Date().toISOString().slice(0, 10), description: '', book_balance: 0, bank_balance: 0, status: 'unreconciled' });

  const save = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.description) return notify('Description required', 'error');
    insert('bankReconciliation', { ...form, book_balance: Number(form.book_balance), bank_balance: Number(form.bank_balance) });
    logActivity(user!, `Bank reconciliation: ${form.description}`, 'reconciliation');
    notify('Entry added');
    setOpen(false);
    setForm({ date: new Date().toISOString().slice(0, 10), description: '', book_balance: 0, bank_balance: 0, status: 'unreconciled' });
  };

  const reconcile = (item: any) => {
    update('bankReconciliation', item.id, { status: 'reconciled' });
    logActivity(user!, `Reconciled ${item.description}`, 'reconciliation', item.id);
    notify('Marked as reconciled');
  };

  return (
    <div>
      <PageHeader title="Bank Reconciliation" subtitle="Match book balance with bank statement"
        action={<Btn onClick={() => setOpen(true)}><span className="flex items-center gap-2"><Plus className="h-4 w-4" /> Add Entry</span></Btn>} />
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-left text-slate-600">
                <th className="pb-3 font-medium">Date</th><th className="pb-3 font-medium">Description</th>
                <th className="pb-3 font-medium text-right">Book Balance</th><th className="pb-3 font-medium text-right">Bank Balance</th>
                <th className="pb-3 font-medium text-right">Difference</th><th className="pb-3 font-medium">Status</th><th className="pb-3 font-medium">Action</th>
              </tr>
            </thead>
            <tbody>
              {items.slice().reverse().map((it) => {
                const diff = it.book_balance - it.bank_balance;
                return (
                  <tr key={it.id} className="border-b border-slate-100">
                    <td className="py-3 text-slate-500">{fmtDate(it.date)}</td>
                    <td className="py-3 font-medium text-slate-900">{it.description}</td>
                    <td className="py-3 text-right text-slate-600">{money(it.book_balance)}</td>
                    <td className="py-3 text-right text-slate-600">{money(it.bank_balance)}</td>
                    <td className={`py-3 text-right font-medium ${diff === 0 ? 'text-green-600' : 'text-red-600'}`}>{money(diff)}</td>
                    <td className="py-3"><StatusBadge status={it.status === 'reconciled' ? 'verified' : 'pending'} /></td>
                    <td className="py-3">{it.status !== 'reconciled' && <button onClick={() => reconcile(it)} className="rounded bg-green-100 p-1.5 text-green-700 hover:bg-green-200" title="Reconcile"><Check className="h-4 w-4" /></button>}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {items.length === 0 && <EmptyState message="No reconciliation entries" />}
        </div>
      </Card>

      <Modal open={open} onClose={() => setOpen(false)} title="Add Reconciliation Entry">
        <form onSubmit={save} className="space-y-4">
          <Field label="Date"><Input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} /></Field>
          <Field label="Description" required><Input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></Field>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Book Balance (PKR)"><Input type="number" value={form.book_balance} onChange={(e) => setForm({ ...form, book_balance: Number(e.target.value) })} /></Field>
            <Field label="Bank Balance (PKR)"><Input type="number" value={form.bank_balance} onChange={(e) => setForm({ ...form, bank_balance: Number(e.target.value) })} /></Field>
          </div>
          <div className="flex justify-end gap-2 pt-2"><Btn variant="secondary" onClick={() => setOpen(false)}>Cancel</Btn><Btn type="submit">Add</Btn></div>
        </form>
      </Modal>
    </div>
  );
}

// ---------------- SALARY MANAGEMENT (read-focused summary linking payroll) ----------------
export function SalaryManagementPage() {
  const staff = useCollection<any>('staff');
  const payroll = useCollection<any>('payroll');
  const staffName = (id: string) => staff.find((s) => s.id === id)?.name || '-';
  const totalMonthly = staff.reduce((a, s) => a + (s.base_salary || 0), 0);
  const paid = payroll.filter((p) => p.status === 'paid').reduce((a, p) => a + p.net_salary, 0);

  void getAll;
  return (
    <div>
      <PageHeader title="Salary Management" subtitle="Staff salary overview" />
      <div className="mb-6 grid gap-4 sm:grid-cols-3">
        <StatCard title="Total Staff" value={staff.length} icon={Wallet} color="from-blue-500 to-blue-600" />
        <StatCard title="Monthly Salary Bill" value={money(totalMonthly)} icon={TrendingDown} color="from-purple-500 to-purple-600" />
        <StatCard title="Total Paid" value={money(paid)} icon={TrendingUp} color="from-green-500 to-green-600" />
      </div>
      <Card title="Salary Structure">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-left text-slate-600">
                <th className="pb-3 font-medium">Employee</th><th className="pb-3 font-medium">Designation</th>
                <th className="pb-3 font-medium">Base Salary</th><th className="pb-3 font-medium">Contract</th><th className="pb-3 font-medium">Bank</th>
              </tr>
            </thead>
            <tbody>
              {staff.map((s) => (
                <tr key={s.id} className="border-b border-slate-100">
                  <td className="py-3 font-medium text-slate-900">{s.name}</td>
                  <td className="py-3 text-slate-600">{s.designation}</td>
                  <td className="py-3 text-slate-600">{money(s.base_salary)}</td>
                  <td className="py-3 capitalize text-slate-600">{(s.contract_type || '').replace('_', ' ')}</td>
                  <td className="py-3 text-slate-500">{s.bank_account || '-'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
      <div className="mt-6">
        <Card title="Recent Payroll">
          <div className="space-y-2">
            {payroll.slice().reverse().slice(0, 6).map((p) => (
              <div key={p.id} className="flex items-center justify-between rounded-lg bg-slate-50 px-3 py-2 text-sm">
                <span className="font-medium text-slate-900">{staffName(p.staff_id)}</span>
                <span className="text-slate-600">{p.month}/{p.year}</span>
                <span className="font-medium text-slate-900">{money(p.net_salary)}</span>
                <StatusBadge status={p.status} />
              </div>
            ))}
            {payroll.length === 0 && <EmptyState message="No payroll records — generate from Payroll page" />}
          </div>
        </Card>
      </div>
    </div>
  );
}
