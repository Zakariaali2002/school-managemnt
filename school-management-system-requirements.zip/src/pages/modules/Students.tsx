import { useState } from 'react';
import { Plus, Pencil, Trash2, CreditCard, FileText, ArrowUpCircle, Search } from 'lucide-react';
import { useCollection } from '../../hooks/useDB';
import { insert, update, remove, logActivity, getAll, getSettings } from '../../lib/db';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../components/ui/Toast';
import { useConfirm } from '../../components/ui/Confirm';
import { Modal } from '../../components/ui/Modal';
import { Field, Input, Select } from '../../components/ui/Field';
import { PageHeader, Card, Btn, EmptyState } from '../../components/ui/Shared';
import { fmtDate, printDocument, barcodeSvgString, calcGrade } from '../../lib/utils';

export function StudentsPage({ readOnly = false }: { readOnly?: boolean }) {
  const students = useCollection<any>('students');
  const classes = useCollection<any>('classes');
  const { user } = useAuth();
  const { notify } = useToast();
  const confirm = useConfirm();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [search, setSearch] = useState('');
  const [classFilter, setClassFilter] = useState('all');
  const [form, setForm] = useState<any>({});

  const blank = () => ({
    name: '', student_code: 'STU-' + new Date().getFullYear() + '-' + String(students.length + 1).padStart(4, '0'),
    class_id: classes[0]?.id || '', section: 'A', roll_no: '', date_of_birth: '',
    guardian_name: '', admission_date: new Date().toISOString().slice(0, 10), address: '', phone: '',
  });

  const openNew = () => { setEditing(null); setForm(blank()); setOpen(true); };
  const openEdit = (s: any) => { setEditing(s); setForm({ ...s }); setOpen(true); };

  const save = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.class_id || !form.roll_no) return notify('Name, class and roll no required', 'error');
    if (editing) {
      update('students', editing.id, form);
      logActivity(user!, `Updated student ${form.name}`, 'student', editing.id);
      notify('Student updated');
    } else {
      const created = insert('students', { ...form, barcode: form.student_code });
      logActivity(user!, `Admitted student ${form.name}`, 'student', created.id);
      notify('Student admitted - generating ID card...');
      // Auto-generate ID card right after admission
      setTimeout(() => idCard(created), 500);
    }
    setOpen(false);
  };

  const del = async (s: any) => {
    const ok = await confirm({ message: `Delete student ${s.name}? This cannot be undone.`, danger: true, confirmText: 'Delete' });
    if (!ok) return;
    remove('students', s.id);
    logActivity(user!, `Deleted student ${s.name}`, 'student', s.id);
    notify('Student deleted');
  };

  const promote = async (s: any) => {
    const idx = classes.findIndex((c) => c.id === s.class_id);
    const next = classes[idx + 1];
    if (!next) return notify('No higher class available', 'error');
    const ok = await confirm({ message: `Promote ${s.name} from ${className(s.class_id)} to ${next.name}?`, confirmText: 'Promote' });
    if (!ok) return;
    update('students', s.id, { class_id: next.id });
    logActivity(user!, `Promoted ${s.name} to ${next.name}`, 'student', s.id);
    notify('Student promoted');
  };

  const className = (id: string) => classes.find((c) => c.id === id)?.name || '-';

  const resultCard = (s: any) => {
    const marks = getAll('marks').filter((m: any) => m.student_id === s.id);
    const subjects = getAll('subjects');
    const exams = getAll('exams');
    if (marks.length === 0) return notify('No results recorded for this student', 'error');
    const rows = marks.map((m: any) => {
      const sub = subjects.find((x: any) => x.id === m.subject_id);
      const exam = exams.find((x: any) => x.id === m.exam_id);
      const pct = (m.marks_obtained / m.total_marks) * 100;
      return `<tr><td>${exam?.name || '-'}</td><td>${sub?.name || '-'}</td><td>${m.marks_obtained}/${m.total_marks}</td><td>${pct.toFixed(0)}%</td><td>${m.grade || calcGrade(pct)}</td></tr>`;
    }).join('');
    const total = marks.reduce((a: number, m: any) => a + m.marks_obtained, 0);
    const max = marks.reduce((a: number, m: any) => a + m.total_marks, 0);
    const overall = ((total / max) * 100).toFixed(1);
    printDocument(`Result Card - ${s.name}`, `
      <div class="title">Student Result Card</div>
      <div class="row"><span class="label">Name</span><span class="value">${s.name}</span></div>
      <div class="row"><span class="label">Student Code</span><span class="value">${s.student_code}</span></div>
      <div class="row"><span class="label">Class</span><span class="value">${className(s.class_id)} - ${s.section}</span></div>
      <div class="row"><span class="label">Roll No</span><span class="value">${s.roll_no}</span></div>
      <table><thead><tr><th>Exam</th><th>Subject</th><th>Marks</th><th>%</th><th>Grade</th></tr></thead><tbody>${rows}</tbody></table>
      <div class="row"><span class="label">Overall Percentage</span><span class="value">${overall}% (Grade ${calcGrade(Number(overall))})</span></div>
      <div class="signature"><div class="sign-box">Class Teacher</div><div class="sign-box">Principal</div></div>
    `);
    logActivity(user!, `Generated result card for ${s.name}`, 'student', s.id);
  };

  const idCard = (s: any) => {
    const barcode = barcodeSvgString(s.student_code, 300, 64);
    printDocument(`ID Card - ${s.name}`, `
      <div class="title">Student ID Card</div>
      <div style="max-width:360px; border:1px solid #cbd5e1; border-radius:14px; overflow:hidden;">
        <div style="background:linear-gradient(to right,#2563eb,#4f46e5); color:#fff; text-align:center; padding:10px;">
          <div style="font-size:15px; font-weight:bold;">${getSettings().school_name}</div>
          <div style="font-size:10px; color:#dbeafe;">STUDENT ID CARD</div>
        </div>
        <div style="display:flex; gap:12px; padding:16px; align-items:center;">
          <div style="width:64px; height:80px; background:#dbeafe; border-radius:8px; display:flex; align-items:center; justify-content:center; font-size:34px;">🎓</div>
          <div style="font-size:12px; color:#475569;">
            <div style="font-size:15px; font-weight:bold; color:#0f172a;">${s.name}</div>
            <div>${className(s.class_id)} - ${s.section}</div>
            <div>Roll: ${s.roll_no}</div>
            <div style="color:#94a3b8;">${s.student_code}</div>
          </div>
        </div>
        <div style="border-top:1px solid #e2e8f0; padding:8px; text-align:center;">${barcode}</div>
      </div>
    `);
    logActivity(user!, `Generated ID card for ${s.name}`, 'student', s.id);
  };

  const filtered = students.filter((s) => {
    const matchSearch = !search || s.name.toLowerCase().includes(search.toLowerCase()) || s.student_code.toLowerCase().includes(search.toLowerCase());
    const matchClass = classFilter === 'all' || s.class_id === classFilter;
    return matchSearch && matchClass;
  });

  return (
    <div>
      <PageHeader
        title="Students"
        subtitle="Manage student admissions and records"
        action={!readOnly && (
          <Btn onClick={openNew}><span className="flex items-center gap-2"><Plus className="h-4 w-4" /> Admit Student</span></Btn>
        )}
      />

      <Card>
        <div className="mb-4 flex flex-wrap gap-3">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by name or code..."
              className="w-full rounded-md border border-slate-300 py-2 pl-9 pr-3 text-sm focus:border-blue-500 focus:outline-none"
            />
          </div>
          <Select value={classFilter} onChange={(e) => setClassFilter(e.target.value)} className="max-w-[200px]">
            <option value="all">All Classes</option>
            {classes.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </Select>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-left text-slate-600">
                <th className="pb-3 font-medium">Code</th>
                <th className="pb-3 font-medium">Name</th>
                <th className="pb-3 font-medium">Class</th>
                <th className="pb-3 font-medium">Roll</th>
                <th className="pb-3 font-medium">Guardian</th>
                <th className="pb-3 font-medium">Admission</th>
                <th className="pb-3 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((s) => (
                <tr key={s.id} className="border-b border-slate-100">
                  <td className="py-3 text-slate-600">{s.student_code}</td>
                  <td className="py-3 font-medium text-slate-900">{s.name}</td>
                  <td className="py-3 text-slate-600">{className(s.class_id)}-{s.section}</td>
                  <td className="py-3 text-slate-600">{s.roll_no}</td>
                  <td className="py-3 text-slate-600">{s.guardian_name || '-'}</td>
                  <td className="py-3 text-slate-500">{fmtDate(s.admission_date)}</td>
                  <td className="py-3">
                    <div className="flex gap-1">
                      <button onClick={() => idCard(s)} className="rounded p-1.5 text-indigo-600 hover:bg-indigo-50" title="ID Card"><CreditCard className="h-4 w-4" /></button>
                      <button onClick={() => resultCard(s)} className="rounded p-1.5 text-green-600 hover:bg-green-50" title="Result Card"><FileText className="h-4 w-4" /></button>
                      {!readOnly && <button onClick={() => promote(s)} className="rounded p-1.5 text-purple-600 hover:bg-purple-50" title="Promote"><ArrowUpCircle className="h-4 w-4" /></button>}
                      {!readOnly && <button onClick={() => openEdit(s)} className="rounded p-1.5 text-blue-600 hover:bg-blue-50" title="Edit"><Pencil className="h-4 w-4" /></button>}
                      {!readOnly && <button onClick={() => del(s)} className="rounded p-1.5 text-red-600 hover:bg-red-50" title="Delete"><Trash2 className="h-4 w-4" /></button>}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filtered.length === 0 && <EmptyState message="No students found" />}
        </div>
      </Card>

      <Modal open={open} onClose={() => setOpen(false)} title={editing ? 'Edit Student' : 'Admit Student'} maxWidth="max-w-2xl">
        <form onSubmit={save} className="grid grid-cols-2 gap-4">
          <Field label="Full Name" required><Input value={form.name || ''} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
          <Field label="Student Code"><Input value={form.student_code || ''} onChange={(e) => setForm({ ...form, student_code: e.target.value })} /></Field>
          <Field label="Class" required>
            <Select value={form.class_id || ''} onChange={(e) => setForm({ ...form, class_id: e.target.value })}>
              {classes.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </Select>
          </Field>
          <Field label="Section"><Input value={form.section || ''} onChange={(e) => setForm({ ...form, section: e.target.value })} /></Field>
          <Field label="Roll No" required><Input value={form.roll_no || ''} onChange={(e) => setForm({ ...form, roll_no: e.target.value })} /></Field>
          <Field label="Date of Birth"><Input type="date" value={form.date_of_birth || ''} onChange={(e) => setForm({ ...form, date_of_birth: e.target.value })} /></Field>
          <Field label="Guardian Name"><Input value={form.guardian_name || ''} onChange={(e) => setForm({ ...form, guardian_name: e.target.value })} /></Field>
          <Field label="Phone"><Input value={form.phone || ''} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></Field>
          <Field label="Admission Date"><Input type="date" value={form.admission_date || ''} onChange={(e) => setForm({ ...form, admission_date: e.target.value })} /></Field>
          <div className="col-span-2"><Field label="Address"><Input value={form.address || ''} onChange={(e) => setForm({ ...form, address: e.target.value })} /></Field></div>
          <div className="col-span-2 flex justify-end gap-2 pt-2">
            <Btn variant="secondary" onClick={() => setOpen(false)}>Cancel</Btn>
            <Btn type="submit">{editing ? 'Update' : 'Admit'}</Btn>
          </div>
        </form>
      </Modal>
    </div>
  );
}
