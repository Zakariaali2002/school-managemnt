import { useState } from 'react';
import { Plus, MessageSquareWarning, Star, AlertTriangle, ShieldAlert, Trash2 } from 'lucide-react';
import { useCollection } from '../../hooks/useDB';
import { insert, remove, logActivity, getById } from '../../lib/db';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../components/ui/Toast';
import { useConfirm } from '../../components/ui/Confirm';
import { Modal } from '../../components/ui/Modal';
import { Field, Input, Select, Textarea } from '../../components/ui/Field';
import { PageHeader, Card, Btn, EmptyState, StatCard } from '../../components/ui/Shared';
import { fmtDate } from '../../lib/utils';
import { notifyParent } from '../../lib/messaging';

const TYPES = [
  { key: 'complaint', label: 'Complaint', icon: MessageSquareWarning, color: 'bg-rose-100 text-rose-700' },
  { key: 'remark', label: 'Remark', icon: AlertTriangle, color: 'bg-amber-100 text-amber-700' },
  { key: 'appreciation', label: 'Appreciation', icon: Star, color: 'bg-emerald-100 text-emerald-700' },
  { key: 'warning', label: 'Warning', icon: ShieldAlert, color: 'bg-orange-100 text-orange-700' },
];

// Teacher / admin view to add complaints & remarks for students.
export function ComplaintsPage({ canManage = true }: { canManage?: boolean }) {
  const complaints = useCollection<any>('complaints');
  const students = useCollection<any>('students');
  const { user } = useAuth();
  const { notify } = useToast();
  const confirm = useConfirm();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<any>({ student_id: students[0]?.id || '', type: 'remark', subject: '', body: '' });

  const studentName = (id: string) => students.find((s) => s.id === id)?.name || '-';
  const typeMeta = (t: string) => TYPES.find((x) => x.key === t) || TYPES[0];

  const save = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.subject) return notify('Subject required', 'error');
    const created = insert('complaints', { ...form, by_user: user!.id, by_name: user!.name });
    const student = getById<any>('students', form.student_id);
    notifyParent(
      studentName(form.student_id), student?.phone || '',
      `New ${typeMeta(form.type).label}`,
      `Your child ${studentName(form.student_id)} received a ${form.type} from ${user!.name}: "${form.subject}".`,
      'complaint', created.id,
    );
    logActivity(user!, `Added ${form.type} for ${studentName(form.student_id)}`, 'complaint', created.id);
    notify(`${typeMeta(form.type).label} added · parent notified`);
    setOpen(false);
    setForm({ student_id: students[0]?.id || '', type: 'remark', subject: '', body: '' });
  };

  const del = async (c: any) => {
    if (!(await confirm({ message: 'Delete this entry?', danger: true, confirmText: 'Delete' }))) return;
    remove('complaints', c.id);
    notify('Deleted');
  };

  const counts = TYPES.map((t) => ({ ...t, count: complaints.filter((c) => c.type === t.key).length }));

  return (
    <div>
      <PageHeader title="Complaints & Remarks" subtitle="Add complaints, remarks, warnings & appreciation"
        action={canManage ? <Btn onClick={() => setOpen(true)}><span className="flex items-center gap-2"><Plus className="h-4 w-4" /> New Entry</span></Btn> : undefined} />

      <div className="mb-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {counts.map((t) => (
          <StatCard key={t.key} title={t.label + 's'} value={t.count} icon={t.icon}
            color={t.key === 'appreciation' ? 'from-emerald-500 to-emerald-600' : t.key === 'warning' ? 'from-orange-500 to-orange-600' : t.key === 'complaint' ? 'from-rose-500 to-rose-600' : 'from-amber-500 to-amber-600'} />
        ))}
      </div>

      <Card title="All Entries">
        <div className="space-y-3">
          {complaints.slice().reverse().map((c) => {
            const meta = typeMeta(c.type);
            return (
              <div key={c.id} className="flex items-start gap-3 rounded-xl border border-slate-100 bg-slate-50/50 p-4">
                <div className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-full ${meta.color}`}>
                  <meta.icon className="h-5 w-5" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <p className="font-semibold text-slate-900">{c.subject}</p>
                    <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${meta.color}`}>{meta.label}</span>
                  </div>
                  <p className="mt-0.5 text-sm text-slate-600">{c.body}</p>
                  <p className="mt-1 text-xs text-slate-400">For {studentName(c.student_id)} · by {c.by_name} · {fmtDate(c.created_at)}</p>
                </div>
                {canManage && <button onClick={() => del(c)} className="rounded p-1.5 text-rose-600 hover:bg-rose-50"><Trash2 className="h-4 w-4" /></button>}
              </div>
            );
          })}
          {complaints.length === 0 && <EmptyState message="No entries yet" />}
        </div>
      </Card>

      <Modal open={open} onClose={() => setOpen(false)} title="New Complaint / Remark">
        <form onSubmit={save} className="space-y-4">
          <Field label="Student" required>
            <Select value={form.student_id} onChange={(e) => setForm({ ...form, student_id: e.target.value })}>
              {students.map((s) => <option key={s.id} value={s.id}>{s.name} ({s.student_code})</option>)}
            </Select>
          </Field>
          <Field label="Type">
            <Select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>
              {TYPES.map((t) => <option key={t.key} value={t.key}>{t.label}</option>)}
            </Select>
          </Field>
          <Field label="Subject" required><Input value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} placeholder="e.g. Late submission" /></Field>
          <Field label="Details"><Textarea rows={3} value={form.body} onChange={(e) => setForm({ ...form, body: e.target.value })} /></Field>
          <p className="text-xs text-slate-400">Parent will be notified automatically via SMS + WhatsApp.</p>
          <div className="flex justify-end gap-2 pt-2"><Btn variant="secondary" onClick={() => setOpen(false)}>Cancel</Btn><Btn type="submit">Add & Notify</Btn></div>
        </form>
      </Modal>
    </div>
  );
}

// Read-only view for student / parent to see remarks about them / their child.
export function MyRemarksPage({ forParent = false }: { forParent?: boolean }) {
  const { user } = useAuth();
  const students = useCollection<any>('students');
  const complaints = useCollection<any>('complaints');

  // Determine which student records belong to this user.
  const myStudents = forParent
    ? students.filter((s) => s.guardian_id === user?.id)
    : students.filter((s) => s.user_id === user?.id);
  const myIds = myStudents.map((s) => s.id);
  const mine = complaints.filter((c) => myIds.includes(c.student_id));
  const studentName = (id: string) => students.find((s) => s.id === id)?.name || '-';
  const typeMeta = (t: string) => TYPES.find((x) => x.key === t) || TYPES[0];

  return (
    <div>
      <PageHeader title={forParent ? "Child Remarks" : "My Remarks"} subtitle="Remarks, complaints & appreciation from teachers" />
      <Card>
        <div className="space-y-3">
          {mine.slice().reverse().map((c) => {
            const meta = typeMeta(c.type);
            return (
              <div key={c.id} className="flex items-start gap-3 rounded-xl border border-slate-100 bg-slate-50/50 p-4">
                <div className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-full ${meta.color}`}><meta.icon className="h-5 w-5" /></div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <p className="font-semibold text-slate-900">{c.subject}</p>
                    <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${meta.color}`}>{meta.label}</span>
                  </div>
                  <p className="mt-0.5 text-sm text-slate-600">{c.body}</p>
                  <p className="mt-1 text-xs text-slate-400">{forParent ? studentName(c.student_id) + ' · ' : ''}by {c.by_name} · {fmtDate(c.created_at)}</p>
                </div>
              </div>
            );
          })}
          {mine.length === 0 && <EmptyState message="No remarks yet 🎉" />}
        </div>
      </Card>
    </div>
  );
}
