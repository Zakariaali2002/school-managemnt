import { useState } from 'react';
import { Plus, Trash2, Megaphone } from 'lucide-react';
import { useCollection } from '../../hooks/useDB';
import { insert, remove, update, logActivity } from '../../lib/db';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../components/ui/Toast';
import { useConfirm } from '../../components/ui/Confirm';
import { Modal } from '../../components/ui/Modal';
import { Field, Input, Textarea } from '../../components/ui/Field';
import { PageHeader, Card, Btn, EmptyState } from '../../components/ui/Shared';
import { fmtDate } from '../../lib/utils';
import { UserRole } from '../../types';

const ROLES: UserRole[] = ['principal', 'hr', 'accounts', 'teacher', 'student', 'parent'];

export function NoticesPage({ canPost = false }: { canPost?: boolean }) {
  const notices = useCollection<any>('notices');
  const { user } = useAuth();
  const { notify } = useToast();
  const confirm = useConfirm();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<{ title: string; content: string; target_roles: string[]; expiry_date: string }>({ title: '', content: '', target_roles: ['student', 'parent', 'teacher'], expiry_date: '' });

  const save = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.title || !form.content) return notify('Title and content required', 'error');
    const c = insert('notices', { ...form, posted_by: user!.id, posted_by_name: user!.name, posted_at: new Date().toISOString(), is_active: true });
    logActivity(user!, `Posted notice "${form.title}"`, 'notice', c.id);
    notify('Notice posted');
    setOpen(false);
    setForm({ title: '', content: '', target_roles: ['student', 'parent', 'teacher'], expiry_date: '' });
  };

  const del = async (n: any) => {
    const ok = await confirm({ message: `Delete notice "${n.title}"?`, danger: true, confirmText: 'Delete' });
    if (!ok) return;
    remove('notices', n.id);
    notify('Notice deleted');
  };

  const toggleRole = (role: string) => {
    setForm((f) => ({ ...f, target_roles: f.target_roles.includes(role) ? f.target_roles.filter((r) => r !== role) : [...f.target_roles, role] }));
  };

  const visible = canPost ? notices : notices.filter((n) => n.is_active && (n.target_roles?.includes(user?.role) || user?.role === 'super_admin'));

  return (
    <div>
      <PageHeader title="Notice Board" subtitle={canPost ? 'Post and manage announcements' : 'School announcements'}
        action={canPost && <Btn onClick={() => setOpen(true)}><span className="flex items-center gap-2"><Plus className="h-4 w-4" /> Post Notice</span></Btn>} />

      <div className="space-y-3">
        {visible.slice().reverse().map((n) => (
          <Card key={n.id}>
            <div className="flex items-start justify-between">
              <div className="flex gap-3">
                <div className="rounded-lg bg-blue-100 p-2"><Megaphone className="h-5 w-5 text-blue-600" /></div>
                <div>
                  <p className="font-semibold text-slate-900">{n.title}</p>
                  <p className="mt-1 text-sm text-slate-600">{n.content}</p>
                  <p className="mt-2 text-xs text-slate-400">By {n.posted_by_name} · {fmtDate(n.posted_at)} · For: {(n.target_roles || []).join(', ')}</p>
                </div>
              </div>
              {canPost && (
                <div className="flex gap-1">
                  <button onClick={() => update('notices', n.id, { is_active: !n.is_active })} className={`rounded px-2 py-1 text-xs font-medium ${n.is_active ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-500'}`}>{n.is_active ? 'Active' : 'Inactive'}</button>
                  <button onClick={() => del(n)} className="rounded p-1.5 text-red-600 hover:bg-red-50"><Trash2 className="h-4 w-4" /></button>
                </div>
              )}
            </div>
          </Card>
        ))}
        {visible.length === 0 && <Card><EmptyState message="No notices" /></Card>}
      </div>

      <Modal open={open} onClose={() => setOpen(false)} title="Post Notice">
        <form onSubmit={save} className="space-y-4">
          <Field label="Title" required><Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} /></Field>
          <Field label="Content" required><Textarea rows={4} value={form.content} onChange={(e) => setForm({ ...form, content: e.target.value })} /></Field>
          <Field label="Target Roles">
            <div className="flex flex-wrap gap-2">
              {ROLES.map((r) => (
                <button type="button" key={r} onClick={() => toggleRole(r)}
                  className={`rounded-full px-3 py-1 text-xs font-medium capitalize ${form.target_roles.includes(r) ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600'}`}>{r}</button>
              ))}
            </div>
          </Field>
          <Field label="Expiry Date"><Input type="date" value={form.expiry_date} onChange={(e) => setForm({ ...form, expiry_date: e.target.value })} /></Field>
          <div className="flex justify-end gap-2 pt-2"><Btn variant="secondary" onClick={() => setOpen(false)}>Cancel</Btn><Btn type="submit">Post</Btn></div>
        </form>
      </Modal>
    </div>
  );
}
