import { useState } from 'react';
import { Printer, Search, GraduationCap, UserCheck } from 'lucide-react';
import { useCollection } from '../../hooks/useDB';
import { getSettings, logActivity } from '../../lib/db';
import { useAuth } from '../../contexts/AuthContext';
import { Select } from '../../components/ui/Field';
import { PageHeader, Card, Btn, EmptyState } from '../../components/ui/Shared';
import { Barcode, barcodeSvgString } from '../../lib/utils';

// Live, on-screen ID card preview
function IDCardPreview({ person, type, className }: { person: any; type: 'student' | 'staff'; className?: string }) {
  const s = getSettings();
  const code = type === 'student' ? person.student_code : person.employee_code;
  const sub = type === 'student' ? `${className || ''} - ${person.section || ''}` : person.designation;
  return (
    <div className="w-[320px] overflow-hidden rounded-xl border border-slate-300 bg-white shadow-md">
      <div className="bg-gradient-to-r from-blue-600 to-indigo-600 px-4 py-2.5 text-center">
        <p className="text-sm font-bold text-white">{s.school_name}</p>
        <p className="text-[10px] text-blue-100">{type === 'student' ? 'STUDENT ID CARD' : 'EMPLOYEE ID CARD'}</p>
      </div>
      <div className="flex gap-3 p-4">
        <div className={`flex h-20 w-16 items-center justify-center rounded-lg text-3xl ${type === 'student' ? 'bg-blue-100' : 'bg-purple-100'}`}>
          {type === 'student' ? '🎓' : '👤'}
        </div>
        <div className="flex-1 text-xs">
          <p className="text-sm font-bold text-slate-900">{person.name}</p>
          <p className="text-slate-500">{sub}</p>
          {type === 'student' && <p className="mt-1 text-slate-500">Roll: {person.roll_no}</p>}
          {type === 'staff' && <p className="mt-1 text-slate-500">{person.department}</p>}
          <p className="text-slate-400">{code}</p>
        </div>
      </div>
      <div className="flex flex-col items-center border-t border-slate-200 px-3 py-2">
        <Barcode value={code} width={280} height={56} />
      </div>
    </div>
  );
}

export function IDCardsPage() {
  const students = useCollection<any>('students');
  const staff = useCollection<any>('staff');
  const classes = useCollection<any>('classes');
  const { user } = useAuth();
  const [tab, setTab] = useState<'student' | 'staff'>('student');
  const [search, setSearch] = useState('');
  const [classFilter, setClassFilter] = useState('all');
  const [selected, setSelected] = useState<any>(null);

  const className = (id: string) => classes.find((c) => c.id === id)?.name || '';

  const printCard = (person: any, type: 'student' | 'staff') => {
    const s = getSettings();
    const code = type === 'student' ? person.student_code : person.employee_code;
    const sub = type === 'student' ? `${className(person.class_id)} - ${person.section || ''}` : person.designation;
    const barcode = barcodeSvgString(code, 300, 64);
    const win = window.open('', '_blank', 'width=500,height=400');
    if (!win) { alert('Please allow popups to print the ID card.'); return; }
    win.document.write(`
      <html><head><title>ID Card - ${person.name}</title>
      <style>
        * { font-family: Arial, sans-serif; box-sizing: border-box; margin:0; }
        body { padding: 30px; display:flex; justify-content:center; }
        .card { width: 340px; border:1px solid #cbd5e1; border-radius:14px; overflow:hidden; box-shadow:0 4px 12px rgba(0,0,0,.1); }
        .top { background: linear-gradient(to right,#2563eb,#4f46e5); color:#fff; text-align:center; padding:10px; }
        .top h1 { font-size:15px; } .top p { font-size:10px; color:#dbeafe; }
        .body { display:flex; gap:12px; padding:16px; }
        .photo { width:64px; height:80px; border-radius:8px; display:flex; align-items:center; justify-content:center; font-size:34px; background:${type === 'student' ? '#dbeafe' : '#f3e8ff'}; }
        .info { font-size:12px; color:#475569; } .info .name { font-size:15px; font-weight:bold; color:#0f172a; }
        .barcode { border-top:1px solid #e2e8f0; padding:8px; text-align:center; }
      </style></head>
      <body>
        <div class="card">
          <div class="top"><h1>${s.school_name}</h1><p>${type === 'student' ? 'STUDENT ID CARD' : 'EMPLOYEE ID CARD'}</p></div>
          <div class="body">
            <div class="photo">${type === 'student' ? '🎓' : '👤'}</div>
            <div class="info">
              <div class="name">${person.name}</div>
              <div>${sub}</div>
              ${type === 'student' ? `<div>Roll: ${person.roll_no}</div>` : `<div>${person.department || ''}</div>`}
              <div style="color:#94a3b8;">${code}</div>
            </div>
          </div>
          <div class="barcode">${barcode}</div>
        </div>
      </body></html>
    `);
    win.document.close();
    setTimeout(() => win.print(), 400);
    logActivity(user!, `Generated ID card for ${person.name}`, type, person.id);
  };

  const printAll = () => {
    const s = getSettings();
    const list = tab === 'student'
      ? students.filter((p) => classFilter === 'all' || p.class_id === classFilter)
      : staff;
    if (list.length === 0) return;
    const cards = list.map((person: any) => {
      const code = tab === 'student' ? person.student_code : person.employee_code;
      const sub = tab === 'student' ? `${className(person.class_id)} - ${person.section || ''}` : person.designation;
      return `
        <div class="card">
          <div class="top"><h1>${s.school_name}</h1><p>${tab === 'student' ? 'STUDENT ID' : 'EMPLOYEE ID'}</p></div>
          <div class="body">
            <div class="photo">${tab === 'student' ? '🎓' : '👤'}</div>
            <div class="info"><div class="name">${person.name}</div><div>${sub}</div><div style="color:#94a3b8;">${code}</div></div>
          </div>
          <div class="barcode">${barcodeSvgString(code, 280, 60)}</div>
        </div>`;
    }).join('');
    const win = window.open('', '_blank');
    if (!win) { alert('Please allow popups.'); return; }
    win.document.write(`
      <html><head><title>ID Cards Batch</title><style>
        * { font-family: Arial, sans-serif; box-sizing: border-box; margin:0; }
        body { padding:20px; display:flex; flex-wrap:wrap; gap:16px; }
        .card { width:320px; border:1px solid #cbd5e1; border-radius:12px; overflow:hidden; page-break-inside:avoid; }
        .top { background:linear-gradient(to right,#2563eb,#4f46e5); color:#fff; text-align:center; padding:8px; }
        .top h1 { font-size:13px; } .top p { font-size:9px; color:#dbeafe; }
        .body { display:flex; gap:10px; padding:12px; }
        .photo { width:56px; height:70px; border-radius:8px; display:flex; align-items:center; justify-content:center; font-size:28px; background:#eef2ff; }
        .info { font-size:11px; color:#475569; } .info .name { font-size:13px; font-weight:bold; color:#0f172a; }
        .barcode { border-top:1px solid #e2e8f0; padding:6px; text-align:center; }
      </style></head><body>${cards}</body></html>
    `);
    win.document.close();
    setTimeout(() => win.print(), 500);
    logActivity(user!, `Generated ${list.length} ID cards (batch)`, tab);
  };

  const studentList = students.filter((p) => {
    const ms = !search || p.name.toLowerCase().includes(search.toLowerCase()) || p.student_code.toLowerCase().includes(search.toLowerCase());
    const mc = classFilter === 'all' || p.class_id === classFilter;
    return ms && mc;
  });
  const staffList = staff.filter((p) => !search || p.name.toLowerCase().includes(search.toLowerCase()) || p.employee_code.toLowerCase().includes(search.toLowerCase()));
  const list = tab === 'student' ? studentList : staffList;

  return (
    <div>
      <PageHeader title="ID Card Generator" subtitle="Generate scannable barcode ID cards for students and employees"
        action={<Btn onClick={printAll}><span className="flex items-center gap-2"><Printer className="h-4 w-4" /> Print All Cards</span></Btn>} />

      <Card>
        <div className="mb-4 flex flex-wrap items-center gap-3">
          <div className="flex gap-2">
            <button onClick={() => { setTab('student'); setSelected(null); }} className={`flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-medium ${tab === 'student' ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}>
              <GraduationCap className="h-4 w-4" /> Students
            </button>
            <button onClick={() => { setTab('staff'); setSelected(null); }} className={`flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-medium ${tab === 'staff' ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}>
              <UserCheck className="h-4 w-4" /> Employees
            </button>
          </div>
          <div className="relative ml-auto min-w-[200px] flex-1">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
            <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search by name or code..."
              className="w-full rounded-md border border-slate-300 py-2 pl-9 pr-3 text-sm focus:border-blue-500 focus:outline-none" />
          </div>
          {tab === 'student' && (
            <Select value={classFilter} onChange={(e) => setClassFilter(e.target.value)} className="max-w-[180px]">
              <option value="all">All Classes</option>
              {classes.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </Select>
          )}
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200 text-left text-slate-600">
                  <th className="pb-3 font-medium">Code</th>
                  <th className="pb-3 font-medium">Name</th>
                  <th className="pb-3 font-medium">{tab === 'student' ? 'Class' : 'Designation'}</th>
                  <th className="pb-3 font-medium">Generate</th>
                </tr>
              </thead>
              <tbody>
                {list.map((p) => (
                  <tr key={p.id} className={`cursor-pointer border-b border-slate-100 ${selected?.id === p.id ? 'bg-blue-50' : ''}`} onClick={() => setSelected(p)}>
                    <td className="py-3 text-slate-600">{tab === 'student' ? p.student_code : p.employee_code}</td>
                    <td className="py-3 font-medium text-slate-900">{p.name}</td>
                    <td className="py-3 text-slate-600">{tab === 'student' ? `${className(p.class_id)}-${p.section}` : p.designation}</td>
                    <td className="py-3">
                      <Btn size="sm" onClick={() => printCard(p, tab)}>
                        <span className="flex items-center gap-1"><Printer className="h-3 w-3" /> ID Card</span>
                      </Btn>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {list.length === 0 && <EmptyState message="No records found" />}
          </div>

          <div className="flex flex-col items-center justify-center rounded-lg bg-slate-50 p-6">
            {selected ? (
              <>
                <p className="mb-4 text-sm font-medium text-slate-600">ID Card Preview</p>
                <IDCardPreview person={selected} type={tab} className={tab === 'student' ? className(selected.class_id) : undefined} />
                <Btn className="mt-4" onClick={() => printCard(selected, tab)}>
                  <span className="flex items-center gap-2"><Printer className="h-4 w-4" /> Print This Card</span>
                </Btn>
                <p className="mt-3 max-w-xs text-center text-xs text-slate-400">
                  The barcode encodes <span className="font-mono">{tab === 'student' ? selected.student_code : selected.employee_code}</span>. Scan it on the Attendance Scanner to auto-mark attendance.
                </p>
              </>
            ) : (
              <div className="text-center text-slate-400">
                <Printer className="mx-auto mb-2 h-10 w-10" />
                <p className="text-sm">Select a person to preview their ID card</p>
              </div>
            )}
          </div>
        </div>
      </Card>
    </div>
  );
}
