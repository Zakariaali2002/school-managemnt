// Native (Capacitor) integration helpers.
// Yeh sab kuch safe hai — web browser par bhi chalega kyunki hum pehle
// check karte hain ke app native platform (Android) par hai ya nahi.

import { Capacitor } from '@capacitor/core';

export function isNative(): boolean {
  return Capacitor.isNativePlatform();
}

// App start hone par native UI setup karein (status bar, splash screen, back button).
export async function initNative() {
  if (!isNative()) return; // web browser par kuch na karein

  try {
    const { StatusBar, Style } = await import('@capacitor/status-bar');
    await StatusBar.setBackgroundColor({ color: '#4f46e5' });
    await StatusBar.setStyle({ style: Style.Light });
  } catch {
    // status bar plugin available nahi — ignore
  }

  try {
    const { SplashScreen } = await import('@capacitor/splash-screen');
    // App ready hone par splash hata dein.
    await SplashScreen.hide();
  } catch {
    // ignore
  }

  try {
    const { App } = await import('@capacitor/app');
    // Android hardware back button: agar history mein peeche jaa sakte hain to jaayein,
    // warna app ko background mein bhej dein (exit confirm jaisa behaviour).
    App.addListener('backButton', ({ canGoBack }) => {
      if (canGoBack) {
        window.history.back();
      } else {
        App.exitApp();
      }
    });
  } catch {
    // ignore
  }
}
