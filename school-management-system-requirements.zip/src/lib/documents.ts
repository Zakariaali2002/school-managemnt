import { getAll } from './db';

export const DOC_STATUS = {
  verified: { label: 'Verified', color: 'bg-green-100 text-green-700', dot: '🟢' },
  pending: { label: 'Pending Review', color: 'bg-yellow-100 text-yellow-700', dot: '🟡' },
  rejected: { label: 'Rejected', color: 'bg-red-100 text-red-700', dot: '🔴' },
};

// Map a user role to the document-category role bucket.
export function categoryRoleForUser(role: string): string {
  return role; // categories are keyed by role directly
}

export function categoriesForRole(role: string) {
  return getAll('documentCategories').filter((c: any) => c.role === role);
}

export function userDocuments(userId: string) {
  return getAll('documents').filter((d: any) => d.user_id === userId);
}

// Returns required categories the user has not uploaded yet.
export function missingDocuments(userId: string, role: string) {
  const cats = categoriesForRole(role).filter((c: any) => c.required);
  const docs = userDocuments(userId);
  return cats.filter((c: any) => !docs.find((d: any) => d.category_id === c.id));
}

export function daysUntil(date: string): number {
  if (!date) return Infinity;
  return Math.ceil((new Date(date).getTime() - Date.now()) / 86400000);
}

// Documents expiring within `withinDays` (default 30) - across all or a single user.
export function expiringDocuments(withinDays = 30, userId?: string) {
  return getAll('documents').filter((d: any) => {
    if (userId && d.user_id !== userId) return false;
    if (!d.expiry_date) return false;
    const days = daysUntil(d.expiry_date);
    return days <= withinDays && days >= 0;
  });
}

export function expiredDocuments(userId?: string) {
  return getAll('documents').filter((d: any) => {
    if (userId && d.user_id !== userId) return false;
    if (!d.expiry_date) return false;
    return daysUntil(d.expiry_date) < 0;
  });
}

export function pendingVerification() {
  return getAll('documents').filter((d: any) => d.status === 'pending');
}
