// Client-side persistent database using localStorage.
// Provides full CRUD with reactive subscriptions so the UI updates live.

type Listener = () => void;

const STORAGE_KEY = 'sms_db_v1';

export interface DBShape {
  users: any[];
  students: any[];
  staff: any[];
  classes: any[];
  subjects: any[];
  timetable: any[];
  exams: any[];
  marks: any[];
  assignments: any[];
  submissions: any[];
  studentAttendance: any[];
  staffAttendance: any[];
  feeTypes: any[];
  feeVouchers: any[];
  feePayments: any[];
  concessions: any[];
  expenses: any[];
  payroll: any[];
  salaryIncrements: any[];
  leaveRequests: any[];
  staffDocuments: any[];
  notices: any[];
  messages: any[];
  events: any[];
  activityLogs: any[];
  documentCategories: any[];
  documents: any[];
  cashbook: any[];
  vouchers: any[];
  bankReconciliation: any[];
  library: any[];
  transport: any[];
  hostel: any[];
  inventory: any[];
  communication: any[];
  notifications: any[];
  branches: any[];
  discounts: any[];
  fines: any[];
  complaints: any[];
  messageLog: any[];
  settings: Record<string, any>;
}

const listeners = new Set<Listener>();

function uid(prefix = ''): string {
  return prefix + Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
}

export function now(): string {
  return new Date().toISOString();
}

function load(): DBShape {
  const seeded = seed();
  const raw = localStorage.getItem(STORAGE_KEY);
  if (raw) {
    try {
      const parsed = JSON.parse(raw);
      // Migration: merge any NEW collections from the seed into the stored data so
      // older saved databases (missing newly-added collections) don't break the app.
      let changed = false;
      for (const key of Object.keys(seeded) as (keyof DBShape)[]) {
        if (parsed[key] === undefined || parsed[key] === null) {
          (parsed as any)[key] = (seeded as any)[key];
          changed = true;
        }
      }
      // Ensure settings always has the latest default keys merged in.
      if (parsed.settings) {
        const mergedSettings = { ...seeded.settings, ...parsed.settings };
        if (JSON.stringify(mergedSettings) !== JSON.stringify(parsed.settings)) {
          parsed.settings = mergedSettings;
          changed = true;
        }
      } else {
        parsed.settings = seeded.settings;
        changed = true;
      }
      if (changed) localStorage.setItem(STORAGE_KEY, JSON.stringify(parsed));
      return parsed;
    } catch {
      /* fall through to seed */
    }
  }
  localStorage.setItem(STORAGE_KEY, JSON.stringify(seeded));
  return seeded;
}

let db: DBShape = typeof localStorage !== 'undefined' ? load() : seed();

function persist() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(db));
  listeners.forEach((l) => l());
}

export function subscribe(listener: Listener): () => void {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

export function resetDB() {
  db = seed();
  persist();
}

// Generic collection accessors -------------------------------------------------

// Stable empty array so that components using useSyncExternalStore don't get a
// brand-new reference on every read (which would cause an infinite render loop).
const EMPTY: any[] = [];

export function getAll<T = any>(collection: keyof DBShape): T[] {
  return (db[collection] as T[]) || (EMPTY as T[]);
}

export function getById<T = any>(collection: keyof DBShape, id: string): T | undefined {
  return (db[collection] as any[]).find((r) => r.id === id);
}

export function insert<T extends Record<string, any>>(collection: keyof DBShape, record: T): T & { id: string } {
  const withId = { id: record.id || uid(), created_at: record.created_at || now(), ...record };
  if (!withId.id) withId.id = uid();
  (db[collection] as any[]).push(withId);
  persist();
  return withId as T & { id: string };
}

export function update(collection: keyof DBShape, id: string, patch: Record<string, any>) {
  const list = db[collection] as any[];
  const idx = list.findIndex((r) => r.id === id);
  if (idx >= 0) {
    list[idx] = { ...list[idx], ...patch };
    persist();
    return list[idx];
  }
  return undefined;
}

export function remove(collection: keyof DBShape, id: string) {
  const list = db[collection] as any[];
  const idx = list.findIndex((r) => r.id === id);
  if (idx >= 0) {
    list.splice(idx, 1);
    persist();
    return true;
  }
  return false;
}

export function getSettings(): Record<string, any> {
  return db.settings;
}

export function updateSettings(patch: Record<string, any>) {
  db.settings = { ...db.settings, ...patch };
  persist();
}

export function logActivity(user: { id: string; name: string }, action: string, entity_type = '', entity_id = '') {
  (db.activityLogs as any[]).unshift({
    id: uid(),
    user_id: user.id,
    user_name: user.name,
    action,
    entity_type,
    entity_id,
    ip_address: '192.168.1.' + Math.floor(Math.random() * 200 + 2),
    timestamp: now(),
  });
  if (db.activityLogs.length > 300) db.activityLogs.length = 300;
  persist();
}

export { uid };

// Seed data --------------------------------------------------------------------

function seed(): DBShape {
  const classes = [
    { id: 'c1', name: 'Class 8', level: '8', section: 'A', max_students: 40, class_teacher_id: 'st5' },
    { id: 'c2', name: 'Class 9', level: '9', section: 'A', max_students: 40, class_teacher_id: 'st5' },
    { id: 'c3', name: 'Class 10', level: '10', section: 'B', max_students: 40, class_teacher_id: 'st6' },
    { id: 'c4', name: 'Class 11', level: '11', section: 'C', max_students: 35, class_teacher_id: 'st6' },
  ];

  const users = [
    { id: 'u1', name: 'Super Admin', email: 'admin@school.edu', password: 'admin123', role: 'super_admin', phone: '0300-1112233', is_active: true, created_at: now() },
    { id: 'u2', name: 'Dr. Ahmed Khan', email: 'principal@school.edu', password: 'admin123', role: 'principal', phone: '0300-2223344', is_active: true, created_at: now() },
    { id: 'u3', name: 'Sarah Ali', email: 'hr@school.edu', password: 'admin123', role: 'hr', phone: '0300-3334455', is_active: true, created_at: now() },
    { id: 'u4', name: 'Muhammad Aslam', email: 'accounts@school.edu', password: 'admin123', role: 'accounts', phone: '0300-4445566', is_active: true, created_at: now() },
    { id: 'u5', name: 'Ms. Fatima Sheikh', email: 'teacher@school.edu', password: 'admin123', role: 'teacher', phone: '0300-5556677', is_active: true, created_at: now() },
    { id: 'u6', name: 'Mr. Ali (Science)', email: 'teacher2@school.edu', password: 'admin123', role: 'teacher', phone: '0300-5556688', is_active: true, created_at: now() },
    { id: 'u7', name: 'Ali Raza', email: 'student@school.edu', password: 'admin123', role: 'student', phone: '0300-6667788', is_active: true, created_at: now() },
    { id: 'u8', name: 'Sana Khan', email: 'student2@school.edu', password: 'admin123', role: 'student', phone: '0300-6667799', is_active: true, created_at: now() },
    { id: 'u9', name: 'Mr. Raza (Parent)', email: 'parent@school.edu', password: 'admin123', role: 'parent', phone: '0300-7778899', is_active: true, created_at: now() },
  ];

  const staff = [
    { id: 'st2', user_id: 'u2', name: 'Dr. Ahmed Khan', employee_code: 'EMP-001', designation: 'Principal', department: 'Administration', join_date: '2020-01-15', cnic: '35201-1234567-1', base_salary: 180000, contract_type: 'permanent', bank_account: 'PK11HABB0001', created_at: now() },
    { id: 'st3', user_id: 'u3', name: 'Sarah Ali', employee_code: 'EMP-002', designation: 'HR Manager', department: 'Administration', join_date: '2021-03-22', cnic: '35201-2234567-2', base_salary: 95000, contract_type: 'permanent', bank_account: 'PK11HABB0002', created_at: now() },
    { id: 'st4', user_id: 'u4', name: 'Muhammad Aslam', employee_code: 'EMP-003', designation: 'Accounts Officer', department: 'Finance', join_date: '2022-07-10', cnic: '35201-3234567-3', base_salary: 78000, contract_type: 'permanent', bank_account: 'PK11HABB0003', created_at: now() },
    { id: 'st5', user_id: 'u5', name: 'Ms. Fatima Sheikh', employee_code: 'EMP-004', designation: 'Senior Teacher', department: 'Mathematics', join_date: '2023-01-05', cnic: '35201-4234567-4', base_salary: 72000, contract_type: 'permanent', bank_account: 'PK11HABB0004', created_at: now() },
    { id: 'st6', user_id: 'u6', name: 'Mr. Ali', employee_code: 'EMP-005', designation: 'Teacher', department: 'Science', join_date: '2023-08-12', cnic: '35201-5234567-5', base_salary: 65000, contract_type: 'contract', bank_account: 'PK11HABB0005', created_at: now() },
  ];

  const students = [
    { id: 's1', user_id: 'u7', name: 'Ali Raza', student_code: 'STU-2024-0001', class_id: 'c2', section: 'A', roll_no: '05', date_of_birth: '2009-04-12', guardian_id: 'u9', guardian_name: 'Mr. Raza', admission_date: '2023-09-01', address: 'House 12, Block B, Lahore', phone: '0300-6667788', created_at: now() },
    { id: 's2', user_id: 'u8', name: 'Sana Khan', student_code: 'STU-2024-0002', class_id: 'c3', section: 'B', roll_no: '12', date_of_birth: '2008-07-22', guardian_id: 'u9', guardian_name: 'Mr. Raza', admission_date: '2022-09-01', address: 'House 12, Block B, Lahore', phone: '0300-6667799', created_at: now() },
    { id: 's3', user_id: '', name: 'Ahmed Sheikh', student_code: 'STU-2024-0003', class_id: 'c4', section: 'C', roll_no: '03', date_of_birth: '2007-11-30', guardian_id: '', guardian_name: 'Mr. Sheikh', admission_date: '2021-09-01', address: 'House 8, Model Town, Lahore', phone: '0301-1112233', created_at: now() },
    { id: 's4', user_id: '', name: 'Fatima Ali', student_code: 'STU-2024-0004', class_id: 'c1', section: 'A', roll_no: '08', date_of_birth: '2010-02-18', guardian_id: '', guardian_name: 'Mr. Ali', admission_date: '2023-09-01', address: 'House 45, Johar Town, Lahore', phone: '0302-2223344', created_at: now() },
    { id: 's5', user_id: '', name: 'Hassan Tariq', student_code: 'STU-2024-0005', class_id: 'c2', section: 'A', roll_no: '06', date_of_birth: '2009-09-09', guardian_id: '', guardian_name: 'Mr. Tariq', admission_date: '2023-09-01', address: 'House 9, Gulberg, Lahore', phone: '0303-3334455', created_at: now() },
  ];

  const subjects = [
    { id: 'sub1', name: 'Mathematics', code: 'MATH', class_id: 'c2', teacher_id: 'st5', credit_hours: 4, created_at: now() },
    { id: 'sub2', name: 'Physics', code: 'PHY', class_id: 'c2', teacher_id: 'st6', credit_hours: 3, created_at: now() },
    { id: 'sub3', name: 'English', code: 'ENG', class_id: 'c2', teacher_id: 'st5', credit_hours: 3, created_at: now() },
    { id: 'sub4', name: 'Mathematics', code: 'MATH', class_id: 'c3', teacher_id: 'st5', credit_hours: 4, created_at: now() },
    { id: 'sub5', name: 'Chemistry', code: 'CHEM', class_id: 'c3', teacher_id: 'st6', credit_hours: 3, created_at: now() },
  ];

  const timetable = [
    { id: 't1', class_id: 'c2', subject_id: 'sub1', teacher_id: 'st5', day_of_week: 'Monday', start_time: '08:00', end_time: '08:45', room: 'Room 101', created_at: now() },
    { id: 't2', class_id: 'c2', subject_id: 'sub2', teacher_id: 'st6', day_of_week: 'Monday', start_time: '09:00', end_time: '09:45', room: 'Lab 1', created_at: now() },
    { id: 't3', class_id: 'c2', subject_id: 'sub3', teacher_id: 'st5', day_of_week: 'Monday', start_time: '10:00', end_time: '10:45', room: 'Room 101', created_at: now() },
    { id: 't4', class_id: 'c2', subject_id: 'sub1', teacher_id: 'st5', day_of_week: 'Tuesday', start_time: '08:00', end_time: '08:45', room: 'Room 101', created_at: now() },
  ];

  const exams = [
    { id: 'e1', name: 'Midterm 2024', class_id: 'c2', academic_year: '2024', start_date: '2024-05-01', end_date: '2024-05-10', created_by: 'u2', created_at: now() },
    { id: 'e2', name: 'Final 2024', class_id: 'c2', academic_year: '2024', start_date: '2024-12-01', end_date: '2024-12-12', created_by: 'u2', created_at: now() },
  ];

  const marks = [
    { id: 'm1', student_id: 's1', exam_id: 'e1', subject_id: 'sub1', marks_obtained: 92, total_marks: 100, grade: 'A+', entered_by: 'u5', created_at: now() },
    { id: 'm2', student_id: 's1', exam_id: 'e1', subject_id: 'sub2', marks_obtained: 85, total_marks: 100, grade: 'A', entered_by: 'u6', created_at: now() },
    { id: 'm3', student_id: 's1', exam_id: 'e1', subject_id: 'sub3', marks_obtained: 88, total_marks: 100, grade: 'A', entered_by: 'u5', created_at: now() },
  ];

  const assignments = [
    { id: 'a1', title: 'Algebra Exercise', subject_id: 'sub1', class_id: 'c2', teacher_id: 'st5', due_date: '2024-06-15', max_marks: 50, description: 'Complete exercises 5.1 to 5.4', created_at: now() },
    { id: 'a2', title: 'Physics Lab Report', subject_id: 'sub2', class_id: 'c2', teacher_id: 'st6', due_date: '2024-06-18', max_marks: 30, description: 'Write a report on the pendulum experiment', created_at: now() },
  ];

  const feeTypes = [
    { id: 'ft1', name: 'Tuition Fee', amount: 10000, frequency: 'monthly', class_id: 'c2', created_at: now() },
    { id: 'ft2', name: 'Transport Fee', amount: 2500, frequency: 'monthly', class_id: 'c2', created_at: now() },
    { id: 'ft3', name: 'Lab Fee', amount: 1500, frequency: 'monthly', class_id: 'c3', created_at: now() },
  ];

  const feeVouchers = [
    { id: 'fv1', student_id: 's1', fee_type_id: 'ft1', voucher_no: 'V-2024-0001', month: 6, year: 2024, amount: 12500, due_date: '2024-06-10', status: 'paid', created_at: now() },
    { id: 'fv2', student_id: 's2', fee_type_id: 'ft1', voucher_no: 'V-2024-0002', month: 6, year: 2024, amount: 15000, due_date: '2024-06-10', status: 'unpaid', created_at: now() },
    { id: 'fv3', student_id: 's3', fee_type_id: 'ft1', voucher_no: 'V-2024-0003', month: 5, year: 2024, amount: 18000, due_date: '2024-05-10', status: 'overdue', created_at: now() },
    { id: 'fv4', student_id: 's4', fee_type_id: 'ft1', voucher_no: 'V-2024-0004', month: 6, year: 2024, amount: 10000, due_date: '2024-06-10', status: 'paid', created_at: now() },
  ];

  const feePayments = [
    { id: 'fp1', voucher_id: 'fv1', amount_paid: 12500, late_fee: 0, discount: 0, receipt_no: 'R-2024-0001', paid_at: '2024-06-08', created_at: now() },
    { id: 'fp2', voucher_id: 'fv4', amount_paid: 10000, late_fee: 0, discount: 0, receipt_no: 'R-2024-0002', paid_at: '2024-06-09', created_at: now() },
  ];

  const expenses = [
    { id: 'ex1', category: 'Utilities', description: 'Electricity bill - May', amount: 85000, date: '2024-05-15', paid_to: 'LESCO', approved_by: 'u2', created_at: now() },
    { id: 'ex2', category: 'Supplies', description: 'Lab equipment purchase', amount: 120000, date: '2024-05-20', paid_to: 'Science Supplies Co', approved_by: 'u2', created_at: now() },
    { id: 'ex3', category: 'Maintenance', description: 'Building repairs', amount: 45000, date: '2024-06-01', paid_to: 'ABC Contractors', approved_by: '', created_at: now() },
  ];

  const payroll = [
    { id: 'pr1', staff_id: 'st5', month: 5, year: 2024, basic_salary: 72000, allowances: 8000, deductions: 2000, net_salary: 78000, status: 'paid', paid_at: '2024-05-31', created_at: now() },
    { id: 'pr2', staff_id: 'st6', month: 5, year: 2024, basic_salary: 65000, allowances: 5000, deductions: 1500, net_salary: 68500, status: 'paid', paid_at: '2024-05-31', created_at: now() },
  ];

  const leaveRequests = [
    { id: 'lr1', staff_id: 'st5', staff_name: 'Ms. Fatima Sheikh', leave_type: 'Sick Leave', from_date: '2024-06-12', to_date: '2024-06-13', reason: 'Fever and rest advised by doctor', status: 'pending', reviewed_by: '', created_at: now() },
    { id: 'lr2', staff_id: 'st6', staff_name: 'Mr. Ali', leave_type: 'Casual Leave', from_date: '2024-06-15', to_date: '2024-06-15', reason: 'Personal work', status: 'pending', reviewed_by: '', created_at: now() },
  ];

  const staffDocuments = [
    { id: 'd1', staff_id: 'st5', doc_type: 'Contract', file_name: 'fatima_contract.pdf', expiry_date: '2025-01-05', uploaded_at: now(), created_at: now() },
    { id: 'd2', staff_id: 'st6', doc_type: 'Certificate', file_name: 'ali_degree.pdf', expiry_date: '', uploaded_at: now(), created_at: now() },
  ];

  const notices = [
    { id: 'n1', title: 'Parent-Teacher Meeting', content: 'PTM scheduled for June 20, 2024 at 10:00 AM in the main hall.', target_roles: ['parent', 'teacher', 'student'], posted_by: 'u2', posted_by_name: 'Dr. Ahmed Khan', posted_at: now(), expiry_date: '2024-06-21', is_active: true, created_at: now() },
    { id: 'n2', title: 'Summer Vacation Notice', content: 'School will close for summer break from June 25 to August 10, 2024.', target_roles: ['parent', 'teacher', 'student', 'accounts', 'hr'], posted_by: 'u2', posted_by_name: 'Dr. Ahmed Khan', posted_at: now(), expiry_date: '2024-08-10', is_active: true, created_at: now() },
  ];

  const events = [
    { id: 'ev1', title: 'Annual Sports Day', description: 'Inter-house sports competition', event_date: '2024-07-05', location: 'School Ground', created_by: 'u2', target_roles: ['student', 'parent', 'teacher'], created_at: now() },
  ];

  const messages = [
    { id: 'msg1', sender_id: 'u9', sender_name: 'Mr. Raza (Parent)', receiver_id: 'u5', receiver_name: 'Ms. Fatima Sheikh', subject: 'Ali\'s progress', body: 'Could you please share an update on Ali\'s math performance?', sent_at: now(), is_read: false, thread_id: 'th1', created_at: now() },
  ];

  // Document categories: which document types are required per role, and whether they expire.
  const documentCategories = [
    // HR / Staff (used for hr, principal, accounts roles too)
    { id: 'dc_hr_cnic', role: 'hr', name: 'CNIC', has_expiry: true, required: true, created_at: now() },
    { id: 'dc_hr_cv', role: 'hr', name: 'CV', has_expiry: false, required: true, created_at: now() },
    { id: 'dc_hr_degree', role: 'hr', name: 'Degree', has_expiry: false, required: true, created_at: now() },
    { id: 'dc_hr_exp', role: 'hr', name: 'Experience Certificate', has_expiry: false, required: false, created_at: now() },
    { id: 'dc_hr_police', role: 'hr', name: 'Police Verification', has_expiry: true, required: false, created_at: now() },
    { id: 'dc_hr_medical', role: 'hr', name: 'Medical Certificate', has_expiry: true, required: false, created_at: now() },
    // Teacher
    { id: 'dc_t_cnic', role: 'teacher', name: 'CNIC', has_expiry: true, required: true, created_at: now() },
    { id: 'dc_t_degree', role: 'teacher', name: 'Degree', has_expiry: false, required: true, created_at: now() },
    { id: 'dc_t_bform', role: 'teacher', name: 'B-Form', has_expiry: false, required: false, created_at: now() },
    { id: 'dc_t_exp', role: 'teacher', name: 'Experience Letter', has_expiry: false, required: false, created_at: now() },
    // Student
    { id: 'dc_s_bform', role: 'student', name: 'B-Form', has_expiry: false, required: true, created_at: now() },
    { id: 'dc_s_birth', role: 'student', name: 'Birth Certificate', has_expiry: false, required: true, created_at: now() },
    { id: 'dc_s_leaving', role: 'student', name: 'Previous School Leaving Certificate', has_expiry: false, required: false, created_at: now() },
    { id: 'dc_s_photo', role: 'student', name: 'Photograph', has_expiry: false, required: true, created_at: now() },
    { id: 'dc_s_gcnic', role: 'student', name: 'Guardian CNIC', has_expiry: true, required: true, created_at: now() },
    // Parent
    { id: 'dc_p_cnicf', role: 'parent', name: 'CNIC Front', has_expiry: true, required: true, created_at: now() },
    { id: 'dc_p_cnicb', role: 'parent', name: 'CNIC Back', has_expiry: true, required: true, created_at: now() },
    { id: 'dc_p_utility', role: 'parent', name: 'Utility Bill', has_expiry: false, required: false, created_at: now() },
    { id: 'dc_p_address', role: 'parent', name: 'Address Proof', has_expiry: false, required: false, created_at: now() },
    // Accounts
    { id: 'dc_a_cnic', role: 'accounts', name: 'CNIC', has_expiry: true, required: true, created_at: now() },
    { id: 'dc_a_bank', role: 'accounts', name: 'Bank Details', has_expiry: false, required: true, created_at: now() },
    { id: 'dc_a_appoint', role: 'accounts', name: 'Appointment Letter', has_expiry: false, required: true, created_at: now() },
    { id: 'dc_a_salary', role: 'accounts', name: 'Salary Agreement', has_expiry: true, required: false, created_at: now() },
    // Principal
    { id: 'dc_pr_cnic', role: 'principal', name: 'CNIC', has_expiry: true, required: true, created_at: now() },
    { id: 'dc_pr_degree', role: 'principal', name: 'Degree', has_expiry: false, required: true, created_at: now() },
    { id: 'dc_pr_appoint', role: 'principal', name: 'Appointment Letter', has_expiry: false, required: true, created_at: now() },
  ];

  const soon = new Date(Date.now() + 20 * 86400000).toISOString().slice(0, 10);
  const documents = [
    { id: 'doc1', user_id: 'u5', category_id: 'dc_t_cnic', file_name: 'fatima_cnic.pdf', file_type: 'application/pdf', uploaded_at: now(), expiry_date: soon, status: 'verified', remarks: '', verified_by: 'u1', created_at: now() },
    { id: 'doc2', user_id: 'u5', category_id: 'dc_t_degree', file_name: 'fatima_degree.jpg', file_type: 'image/jpeg', uploaded_at: now(), expiry_date: '', status: 'pending', remarks: '', verified_by: '', created_at: now() },
    { id: 'doc3', user_id: 'u7', category_id: 'dc_s_bform', file_name: 'ali_bform.pdf', file_type: 'application/pdf', uploaded_at: now(), expiry_date: '', status: 'rejected', remarks: 'Image is blurred, please re-upload.', verified_by: 'u1', created_at: now() },
  ];

  // ---- New operational modules seed data ----
  const library = [
    { id: 'lib1', title: 'Mathematics Grade 9', author: 'Oxford', isbn: '978-0-19-1', category: 'Textbook', total_copies: 20, available: 18, issued_to: '', created_at: now() },
    { id: 'lib2', title: 'Pakistan Studies', author: 'M. Ikram', isbn: '978-9-69-2', category: 'Textbook', total_copies: 15, available: 12, issued_to: '', created_at: now() },
    { id: 'lib3', title: 'English Grammar', author: 'Wren & Martin', isbn: '978-8-12-3', category: 'Reference', total_copies: 10, available: 8, issued_to: '', created_at: now() },
    { id: 'lib4', title: 'Science Encyclopedia', author: 'DK', isbn: '978-1-46-4', category: 'Reference', total_copies: 5, available: 5, issued_to: '', created_at: now() },
  ];
  const transport = [
    { id: 'tr1', route_name: 'Route A - Gulberg', vehicle_no: 'LEA-1234', driver_name: 'Akram Khan', driver_phone: '0300-1112233', capacity: 30, students_assigned: 24, fee: 3000, created_at: now() },
    { id: 'tr2', route_name: 'Route B - Johar Town', vehicle_no: 'LEB-5678', driver_name: 'Saleem Ahmed', driver_phone: '0301-2223344', capacity: 25, students_assigned: 20, fee: 3500, created_at: now() },
    { id: 'tr3', route_name: 'Route C - Model Town', vehicle_no: 'LEC-9012', driver_name: 'Rashid Ali', driver_phone: '0302-3334455', capacity: 30, students_assigned: 18, fee: 2800, created_at: now() },
  ];
  const hostel = [
    { id: 'hs1', room_no: 'A-101', block: 'Block A', capacity: 4, occupied: 3, type: 'Boys', warden: 'Mr. Tariq', created_at: now() },
    { id: 'hs2', room_no: 'A-102', block: 'Block A', capacity: 4, occupied: 4, type: 'Boys', warden: 'Mr. Tariq', created_at: now() },
    { id: 'hs3', room_no: 'B-201', block: 'Block B', capacity: 3, occupied: 2, type: 'Girls', warden: 'Mrs. Saima', created_at: now() },
  ];
  const inventory = [
    { id: 'inv1', item_name: 'Whiteboard Markers', category: 'Stationery', quantity: 150, unit: 'pcs', reorder_level: 50, location: 'Store Room 1', created_at: now() },
    { id: 'inv2', item_name: 'Computer Systems', category: 'Electronics', quantity: 40, unit: 'units', reorder_level: 5, location: 'IT Lab', created_at: now() },
    { id: 'inv3', item_name: 'Student Desks', category: 'Furniture', quantity: 320, unit: 'pcs', reorder_level: 20, location: 'Classrooms', created_at: now() },
    { id: 'inv4', item_name: 'First Aid Kits', category: 'Medical', quantity: 8, unit: 'kits', reorder_level: 10, location: 'Medical Room', created_at: now() },
  ];
  const communication = [
    { id: 'cm1', title: 'Fee Reminder', message: 'Dear parent, please clear outstanding fees by 10th.', audience: 'parent', channel: 'SMS', sent_by: 'u4', sent_at: now(), recipients: 320, created_at: now() },
    { id: 'cm2', title: 'Exam Schedule', message: 'Mid-term exams begin next Monday. Best of luck!', audience: 'student', channel: 'Email', sent_by: 'u2', sent_at: now(), recipients: 845, created_at: now() },
  ];
  const notifications = [
    { id: 'nt1', title: 'New Admission', message: 'A new student was admitted to Class 9-A.', type: 'info', is_read: false, created_at: now() },
    { id: 'nt2', title: 'Fee Collected', message: 'PKR 1.5M collected this month.', type: 'success', is_read: false, created_at: now() },
    { id: 'nt3', title: 'Document Pending', message: '3 documents awaiting verification.', type: 'warning', is_read: true, created_at: now() },
  ];
  const branches = [
    { id: 'br1', name: 'Main Campus', address: 'Main Boulevard, Lahore', phone: '042-111-222-333', principal: 'Dr. Ahmed Khan', students: 845, status: 'active', created_at: now() },
    { id: 'br2', name: 'City Branch', address: 'Mall Road, Lahore', phone: '042-111-444-555', principal: 'Ms. Ayesha', students: 420, status: 'active', created_at: now() },
  ];
  const discounts = [
    { id: 'ds1', name: 'Sibling Discount', type: 'percent', value: 10, applies_to: 'Tuition', reason: '2+ children enrolled', active: true, created_at: now() },
    { id: 'ds2', name: 'Merit Scholarship', type: 'percent', value: 50, applies_to: 'Tuition', reason: 'Top position holders', active: true, created_at: now() },
    { id: 'ds3', name: 'Staff Child', type: 'percent', value: 100, applies_to: 'All', reason: 'Children of staff', active: true, created_at: now() },
  ];
  const fines = [
    { id: 'fn1', name: 'Late Fee Fine', amount: 500, reason: 'Fee paid after due date', applies_after_days: 7, active: true, created_at: now() },
    { id: 'fn2', name: 'Library Late Return', amount: 50, reason: 'Per day book overdue', applies_after_days: 1, active: true, created_at: now() },
    { id: 'fn3', name: 'Damaged Property', amount: 1000, reason: 'Damage to school property', applies_after_days: 0, active: true, created_at: now() },
  ];

  return {
    users,
    students,
    staff,
    classes,
    subjects,
    timetable,
    exams,
    marks,
    assignments,
    submissions: [],
    studentAttendance: [],
    staffAttendance: [],
    feeTypes,
    feeVouchers,
    feePayments,
    concessions: [],
    expenses,
    payroll,
    salaryIncrements: [],
    leaveRequests,
    staffDocuments,
    notices,
    messages,
    events,
    activityLogs: [
      { id: 'al1', user_id: 'u2', user_name: 'Dr. Ahmed Khan', action: 'Logged in', entity_type: 'auth', entity_id: '', ip_address: '192.168.1.45', timestamp: now() },
    ],
    documentCategories,
    documents,
    cashbook: [
      { id: 'cb1', date: now().slice(0, 10), type: 'in', description: 'Opening balance', amount: 100000, ref: 'OPENING', created_at: now() },
    ],
    vouchers: [],
    bankReconciliation: [],
    library,
    transport,
    hostel,
    inventory,
    communication,
    notifications,
    branches,
    discounts,
    fines,
    complaints: [
      { id: 'cmp1', student_id: 's1', type: 'remark', subject: 'Homework not completed', body: 'Ali did not submit his math homework on time.', by_user: 'u5', by_name: 'Ms. Fatima Sheikh', created_at: now() },
      { id: 'cmp2', student_id: 's2', type: 'appreciation', subject: 'Excellent performance', body: 'Sana scored highest in the science quiz. Well done!', by_user: 'u6', by_name: 'Mr. Ali', created_at: now() },
    ],
    messageLog: [],
    settings: {
      school_name: 'City Grammar School',
      academic_year: '2024-2025',
      address: 'Main Boulevard, Lahore, Pakistan',
      phone: '042-111-222-333',
      email: 'info@school.edu',
      late_fee: 500,
      currency: 'PKR',
      monthly_target: 2000000,
      max_doc_size_mb: 5,
      easypaisa_number: '0345-1234567',
      jazzcash_number: '0301-7654321',
      bank_name: 'HBL Bank',
      bank_account_title: 'City Grammar School',
      bank_account_number: '0001-1234567890',
      bank_iban: 'PK36HABB0000001234567890',
    },
  };
}
