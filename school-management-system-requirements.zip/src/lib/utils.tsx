import { getSettings } from './db';

export function money(n: number): string {
  const s = getSettings();
  return `${s.currency || 'PKR'} ${Number(n || 0).toLocaleString()}`;
}

export function fmtDate(d?: string): string {
  if (!d) return '-';
  const date = new Date(d);
  if (isNaN(date.getTime())) return d;
  return date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
}

export function calcGrade(pct: number): string {
  if (pct >= 90) return 'A+';
  if (pct >= 80) return 'A';
  if (pct >= 70) return 'B+';
  if (pct >= 60) return 'B';
  if (pct >= 50) return 'C';
  if (pct >= 40) return 'D';
  return 'F';
}

export function StatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    paid: 'bg-emerald-100 text-emerald-700 ring-emerald-200',
    unpaid: 'bg-amber-100 text-amber-700 ring-amber-200',
    overdue: 'bg-rose-100 text-rose-700 ring-rose-200',
    pending: 'bg-amber-100 text-amber-700 ring-amber-200',
    approved: 'bg-emerald-100 text-emerald-700 ring-emerald-200',
    rejected: 'bg-rose-100 text-rose-700 ring-rose-200',
    active: 'bg-emerald-100 text-emerald-700 ring-emerald-200',
    inactive: 'bg-slate-100 text-slate-600 ring-slate-200',
    present: 'bg-emerald-100 text-emerald-700 ring-emerald-200',
    absent: 'bg-rose-100 text-rose-700 ring-rose-200',
    late: 'bg-amber-100 text-amber-700 ring-amber-200',
    leave: 'bg-sky-100 text-sky-700 ring-sky-200',
    submitted: 'bg-emerald-100 text-emerald-700 ring-emerald-200',
    generated: 'bg-indigo-100 text-indigo-700 ring-indigo-200',
    reconciled: 'bg-emerald-100 text-emerald-700 ring-emerald-200',
  };
  return (
    <span className={`inline-block rounded-full px-2.5 py-0.5 text-xs font-medium capitalize ring-1 ${map[status] || 'bg-slate-100 text-slate-600 ring-slate-200'}`}>
      {status}
    </span>
  );
}

// Generates a printable document (used for "PDF"/report downloads via print dialog).
export function printDocument(title: string, bodyHtml: string) {
  const s = getSettings();
  const win = window.open('', '_blank', 'width=800,height=900');
  if (!win) {
    alert('Please allow popups to generate the document.');
    return;
  }
  win.document.write(`
    <html>
      <head>
        <title>${title}</title>
        <style>
          * { font-family: Arial, sans-serif; box-sizing: border-box; }
          body { padding: 40px; color: #1e293b; }
          .header { text-align:center; border-bottom: 3px solid #2563eb; padding-bottom: 16px; margin-bottom: 24px; }
          .header h1 { margin: 0; color: #1e3a8a; font-size: 24px; }
          .header p { margin: 4px 0; color: #64748b; font-size: 13px; }
          .title { font-size: 18px; font-weight: bold; margin: 16px 0; color:#0f172a; }
          table { width: 100%; border-collapse: collapse; margin: 12px 0; }
          th, td { border: 1px solid #cbd5e1; padding: 8px 12px; text-align: left; font-size: 13px; }
          th { background: #f1f5f9; }
          .row { display:flex; justify-content: space-between; padding: 6px 0; border-bottom: 1px dashed #e2e8f0; font-size:14px; }
          .label { color:#64748b; }
          .value { font-weight: 600; }
          .footer { margin-top: 40px; text-align:center; color:#94a3b8; font-size: 11px; border-top:1px solid #e2e8f0; padding-top:12px;}
          .signature { margin-top: 60px; display:flex; justify-content: space-between; }
          .sign-box { border-top: 1px solid #475569; padding-top: 4px; width: 200px; text-align:center; font-size: 12px; }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>${s.school_name}</h1>
          <p>${s.address} | ${s.phone}</p>
          <p>Academic Year: ${s.academic_year}</p>
        </div>
        ${bodyHtml}
        <div class="footer">This is a system-generated document. ${new Date().toLocaleString()}</div>
      </body>
    </html>
  `);
  win.document.close();
  setTimeout(() => win.print(), 400);
}

// Simple SVG-based QR-like code (deterministic blocks from a string).
export function QRCode({ value, size = 120 }: { value: string; size?: number }) {
  const grid = 21;
  const cell = size / grid;
  let hash = 0;
  for (let i = 0; i < value.length; i++) hash = (hash * 31 + value.charCodeAt(i)) >>> 0;
  const rng = (n: number) => {
    hash = (hash * 1103515245 + 12345 + n) >>> 0;
    return (hash >> 16) & 1;
  };
  const cells: boolean[][] = [];
  for (let r = 0; r < grid; r++) {
    cells[r] = [];
    for (let c = 0; c < grid; c++) cells[r][c] = rng(r * grid + c) === 1;
  }
  // finder patterns
  const finder = (sr: number, sc: number) => {
    for (let r = 0; r < 7; r++)
      for (let c = 0; c < 7; c++) {
        const border = r === 0 || r === 6 || c === 0 || c === 6;
        const inner = r >= 2 && r <= 4 && c >= 2 && c <= 4;
        cells[sr + r][sc + c] = border || inner;
      }
  };
  finder(0, 0);
  finder(0, grid - 7);
  finder(grid - 7, 0);

  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="rounded bg-white">
      <rect width={size} height={size} fill="#fff" />
      {cells.map((row, r) =>
        row.map((on, c) =>
          on ? <rect key={`${r}-${c}`} x={c * cell} y={r * cell} width={cell} height={cell} fill="#0f172a" /> : null,
        ),
      )}
    </svg>
  );
}

// QR-like code as an SVG string (for use inside printDocument HTML).
export function qrSvgString(value: string, size = 110): string {
  const grid = 21;
  const cell = size / grid;
  let hash = 0;
  for (let i = 0; i < value.length; i++) hash = (hash * 31 + value.charCodeAt(i)) >>> 0;
  const rng = (n: number) => { hash = (hash * 1103515245 + 12345 + n) >>> 0; return (hash >> 16) & 1; };
  const cells: boolean[][] = [];
  for (let r = 0; r < grid; r++) { cells[r] = []; for (let c = 0; c < grid; c++) cells[r][c] = rng(r * grid + c) === 1; }
  const finder = (sr: number, sc: number) => {
    for (let r = 0; r < 7; r++) for (let c = 0; c < 7; c++) {
      const border = r === 0 || r === 6 || c === 0 || c === 6;
      const inner = r >= 2 && r <= 4 && c >= 2 && c <= 4;
      cells[sr + r][sc + c] = border || inner;
    }
  };
  finder(0, 0); finder(0, grid - 7); finder(grid - 7, 0);
  let rects = '';
  for (let r = 0; r < grid; r++) for (let c = 0; c < grid; c++) if (cells[r][c]) rects += `<rect x="${c * cell}" y="${r * cell}" width="${cell}" height="${cell}" fill="#0f172a"/>`;
  return `<svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" xmlns="http://www.w3.org/2000/svg"><rect width="${size}" height="${size}" fill="#fff"/>${rects}</svg>`;
}

// ---------------------------------------------------------------------------
// Code128-B barcode generator (real, scannable). Returns array of bar widths.
// ---------------------------------------------------------------------------
const CODE128_PATTERNS = [
  '11011001100','11001101100','11001100110','10010011000','10010001100','10001001100','10011001000','10011000100','10001100100','11001001000',
  '11001000100','11000100100','10110011100','10011011100','10011001110','10111001100','10011101100','10011100110','11001110010','11001011100',
  '11001001110','11011100100','11001110100','11101101110','11101001100','11100101100','11100100110','11101100100','11100110100','11100110010',
  '11011011000','11011000110','11000110110','10100011000','10001011000','10001000110','10110001000','10001101000','10001100010','11010001000',
  '11000101000','11000100010','10110111000','10110001110','10001101110','10111011000','10111000110','10001110110','11101110110','11010001110',
  '11000101110','11011101000','11011100010','11011101110','11101011000','11101000110','11100010110','11101101000','11101100010','11100011010',
  '11101111010','11001000010','11110001010','10100110000','10100001100','10010110000','10010000110','10000101100','10000100110','10110010000',
  '10110000100','10011010000','10011000010','10000110100','10000110010','11000010010','11001010000','11110111010','11000010100','10001111010',
  '10100111100','10010111100','10010011110','10111100100','10011110100','10011110010','11110100100','11110010100','11110010010','11011011110',
  '11011110110','11110110110','10101111000','10100011110','10001011110','10111101000','10111100010','11110101000','11110100010','10111011110',
  '10111101110','11101011110','11110101110','11010000100','11010010000','11010011100','11000111010',
];
const CODE128_STOP = '1100011101011';

// value must be ASCII 32-126 (Code Set B). Returns bar pattern string of 0/1.
export function code128Pattern(value: string): string {
  const startB = 104;
  let checksum = startB;
  let pattern = CODE128_PATTERNS[startB];
  for (let i = 0; i < value.length; i++) {
    const code = value.charCodeAt(i) - 32; // Code Set B mapping
    if (code < 0 || code > 94) continue;
    pattern += CODE128_PATTERNS[code];
    checksum += code * (i + 1);
  }
  pattern += CODE128_PATTERNS[checksum % 103];
  pattern += CODE128_STOP;
  return pattern;
}

// SVG barcode component (scannable)
export function Barcode({ value, width = 260, height = 70, showText = true }: { value: string; width?: number; height?: number; showText?: boolean }) {
  const pattern = code128Pattern(value);
  const barWidth = width / pattern.length;
  let x = 0;
  const bars: { x: number; w: number }[] = [];
  let i = 0;
  while (i < pattern.length) {
    let run = 1;
    while (i + run < pattern.length && pattern[i + run] === pattern[i]) run++;
    if (pattern[i] === '1') bars.push({ x, w: barWidth * run });
    x += barWidth * run;
    i += run;
  }
  const barH = showText ? height - 16 : height;
  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} className="bg-white">
      <rect width={width} height={height} fill="#fff" />
      {bars.map((b, idx) => (
        <rect key={idx} x={b.x} y={0} width={b.w} height={barH} fill="#000" />
      ))}
      {showText && (
        <text x={width / 2} y={height - 3} textAnchor="middle" fontSize="11" fontFamily="monospace" fill="#000" letterSpacing="1">
          {value}
        </text>
      )}
    </svg>
  );
}

// Barcode markup for print documents (returns SVG string)
export function barcodeSvgString(value: string, width = 260, height = 70): string {
  const pattern = code128Pattern(value);
  const barWidth = width / pattern.length;
  let x = 0;
  let rects = '';
  let i = 0;
  while (i < pattern.length) {
    let run = 1;
    while (i + run < pattern.length && pattern[i + run] === pattern[i]) run++;
    if (pattern[i] === '1') rects += `<rect x="${x}" y="0" width="${barWidth * run}" height="${height - 16}" fill="#000"/>`;
    x += barWidth * run;
    i += run;
  }
  return `<svg width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" xmlns="http://www.w3.org/2000/svg"><rect width="${width}" height="${height}" fill="#fff"/>${rects}<text x="${width / 2}" y="${height - 3}" text-anchor="middle" font-size="11" font-family="monospace" fill="#000">${value}</text></svg>`;
}
