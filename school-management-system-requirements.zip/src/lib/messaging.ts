import { insert, getAll } from './db';

export type Channel = 'SMS' | 'WhatsApp' | 'Email';

// Simulated message sender. In a real deployment this would call a gateway API
// (Twilio, WhatsApp Business, EasyPaisa/JazzCash, etc). Here we log every message
// so the UI can show a realistic delivery history.
export function sendMessage(opts: {
  to: string; // recipient name or phone
  channels: Channel[];
  title: string;
  body: string;
  category?: string; // e.g. 'fee', 'attendance', 'complaint', 'payroll'
  relatedId?: string;
}) {
  opts.channels.forEach((ch) => {
    insert('messageLog', {
      to: opts.to,
      channel: ch,
      title: opts.title,
      body: opts.body,
      category: opts.category || 'general',
      related_id: opts.relatedId || '',
      status: 'sent',
      sent_at: new Date().toISOString(),
    });
  });
}

// Create an in-app notification.
export function pushNotification(opts: { title: string; message: string; type?: string }) {
  insert('notifications', {
    title: opts.title,
    message: opts.message,
    type: opts.type || 'info',
    is_read: false,
  });
}

// Convenience: notify a parent about their child via SMS + WhatsApp + in-app.
export function notifyParent(studentName: string, parentContact: string, title: string, body: string, category = 'general', relatedId = '') {
  sendMessage({ to: `${parentContact || studentName} (Parent)`, channels: ['SMS', 'WhatsApp'], title, body, category, relatedId });
  pushNotification({ title, message: body });
}

export function messageHistory(category?: string) {
  const all = getAll('messageLog');
  return category ? all.filter((m: any) => m.category === category) : all;
}
