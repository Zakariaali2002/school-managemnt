import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App";
import { initNative } from "./lib/native";

// Native (mobile app) features initialize karein — web par yeh safely skip ho jaata hai.
initNative();

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App />
  </StrictMode>
);
