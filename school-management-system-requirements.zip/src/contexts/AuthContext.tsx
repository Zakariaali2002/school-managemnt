import { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { User } from '../types';
import { getAll, update, logActivity } from '../lib/db';

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<{ ok: boolean; error?: string }>;
  logout: () => void;
  // Forgot-password flow: returns generated OTP (simulated send to email/phone)
  requestOtp: (identifier: string) => { ok: boolean; otp?: string; via?: string; error?: string };
  resetPassword: (identifier: string, newPassword: string) => { ok: boolean; error?: string };
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);
const SESSION_KEY = 'sms_session';

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const raw = localStorage.getItem(SESSION_KEY);
    if (raw) {
      try {
        const id = JSON.parse(raw).id;
        const found = getAll<User>('users').find((u) => u.id === id);
        if (found) setUser(found);
      } catch {
        /* ignore */
      }
    }
    setIsLoading(false);
  }, []);

  const login = async (email: string, password: string): Promise<{ ok: boolean; error?: string }> => {
    const users = getAll<any>('users');
    const found = users.find((u) => u.email.toLowerCase() === email.toLowerCase().trim());
    if (!found) return { ok: false, error: 'No account found with this email' };
    if (found.password !== password) return { ok: false, error: 'Incorrect password' };
    if (!found.is_active) return { ok: false, error: 'Account is deactivated' };
    setUser(found);
    localStorage.setItem(SESSION_KEY, JSON.stringify({ id: found.id }));
    logActivity(found, 'Logged in', 'auth');
    return { ok: true };
  };

  const logout = () => {
    if (user) logActivity(user, 'Logged out', 'auth');
    setUser(null);
    localStorage.removeItem(SESSION_KEY);
  };

  // Generate a 6-digit OTP for the account matching email OR phone.
  const requestOtp = (identifier: string) => {
    const id = identifier.toLowerCase().trim();
    const found = getAll<any>('users').find(
      (u) => u.email?.toLowerCase() === id || u.phone === identifier.trim(),
    );
    if (!found) return { ok: false, error: 'No account found with this email or mobile number' };
    const otp = String(Math.floor(100000 + Math.random() * 900000));
    const via = identifier.includes('@') ? `email (${found.email})` : `SMS (${found.phone || found.email})`;
    // In production this would send via SMS/email gateway. Here we return it to display.
    return { ok: true, otp, via };
  };

  const resetPassword = (identifier: string, newPassword: string) => {
    const id = identifier.toLowerCase().trim();
    const found = getAll<any>('users').find(
      (u) => u.email?.toLowerCase() === id || u.phone === identifier.trim(),
    );
    if (!found) return { ok: false, error: 'Account not found' };
    if (!newPassword || newPassword.length < 4) return { ok: false, error: 'Password must be at least 4 characters' };
    update('users', found.id, { password: newPassword });
    logActivity(found, 'Reset password via OTP', 'auth');
    return { ok: true };
  };

  return (
    <AuthContext.Provider value={{ user, isLoading, login, logout, requestOtp, resetPassword }}>{children}</AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
}
