import { ReactNode } from 'react';

// Circular / Donut progress chart
export function DonutChart({
  value,
  max,
  label,
  sublabel,
  color = '#2563eb',
  size = 140,
  centerText,
}: {
  value: number;
  max: number;
  label?: string;
  sublabel?: string;
  color?: string;
  size?: number;
  centerText?: ReactNode;
}) {
  const radius = size / 2 - 12;
  const circ = 2 * Math.PI * radius;
  const pct = max > 0 ? Math.min(100, Math.round((value / max) * 100)) : 0;
  const offset = circ - (circ * pct) / 100;

  return (
    <div className="flex flex-col items-center">
      <div className="relative" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="-rotate-90">
          <circle cx={size / 2} cy={size / 2} r={radius} stroke="#e2e8f0" strokeWidth="12" fill="none" />
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke={color}
            strokeWidth="12"
            fill="none"
            strokeLinecap="round"
            strokeDasharray={circ}
            strokeDashoffset={offset}
            style={{ transition: 'stroke-dashoffset 0.6s ease' }}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
          {centerText ?? <span className="text-2xl font-bold text-slate-900">{pct}%</span>}
        </div>
      </div>
      {label && <p className="mt-2 text-sm font-medium text-slate-700">{label}</p>}
      {sublabel && <p className="text-xs text-slate-500">{sublabel}</p>}
    </div>
  );
}

// Simple bar chart for trends
export function BarChart({ data, color = '#2563eb', height = 160, valuePrefix = '' }: { data: { label: string; value: number }[]; color?: string; height?: number; valuePrefix?: string }) {
  const max = Math.max(...data.map((d) => d.value), 1);
  return (
    <div>
      <div className="flex items-end gap-2" style={{ height }}>
        {data.map((d, i) => (
          <div key={i} className="flex flex-1 flex-col items-center justify-end">
            <span className="mb-1 text-[10px] font-medium text-slate-500">{valuePrefix}{abbr(d.value)}</span>
            <div
              className="w-full rounded-t-md transition-all"
              style={{ height: `${(d.value / max) * (height - 30)}px`, backgroundColor: color, minHeight: 2 }}
              title={`${d.label}: ${d.value}`}
            />
            <span className="mt-1 text-[10px] text-slate-400">{d.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// Horizontal breakdown bars (e.g., expense categories)
export function BreakdownBars({ data, colors }: { data: { label: string; value: number }[]; colors?: string[] }) {
  const total = data.reduce((a, d) => a + d.value, 0) || 1;
  const palette = colors || ['#2563eb', '#16a34a', '#9333ea', '#ea580c', '#dc2626', '#0891b2', '#ca8a04'];
  return (
    <div className="space-y-3">
      {data.map((d, i) => (
        <div key={i}>
          <div className="mb-1 flex justify-between text-sm">
            <span className="text-slate-700">{d.label}</span>
            <span className="font-medium text-slate-900">{Math.round((d.value / total) * 100)}%</span>
          </div>
          <div className="h-2.5 w-full rounded-full bg-slate-100">
            <div className="h-2.5 rounded-full" style={{ width: `${(d.value / total) * 100}%`, backgroundColor: palette[i % palette.length] }} />
          </div>
        </div>
      ))}
      {data.length === 0 && <p className="text-sm text-slate-400">No data</p>}
    </div>
  );
}

// Dual-line style comparison using overlaid bars (income vs expense)
export function IncomeExpenseChart({ data, height = 180 }: { data: { label: string; income: number; expense: number }[]; height?: number }) {
  const max = Math.max(...data.flatMap((d) => [d.income, d.expense]), 1);
  return (
    <div>
      <div className="flex items-end gap-3" style={{ height }}>
        {data.map((d, i) => (
          <div key={i} className="flex flex-1 flex-col items-center justify-end">
            <div className="flex w-full items-end justify-center gap-1" style={{ height: height - 24 }}>
              <div className="w-1/2 rounded-t bg-green-500" style={{ height: `${(d.income / max) * (height - 24)}px`, minHeight: 2 }} title={`Income: ${d.income}`} />
              <div className="w-1/2 rounded-t bg-red-500" style={{ height: `${(d.expense / max) * (height - 24)}px`, minHeight: 2 }} title={`Expense: ${d.expense}`} />
            </div>
            <span className="mt-1 text-[10px] text-slate-400">{d.label}</span>
          </div>
        ))}
      </div>
      <div className="mt-3 flex justify-center gap-4 text-xs">
        <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-green-500" /> Income</span>
        <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-red-500" /> Expense</span>
      </div>
    </div>
  );
}

function abbr(n: number): string {
  if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M';
  if (n >= 1000) return (n / 1000).toFixed(0) + 'k';
  return String(n);
}
