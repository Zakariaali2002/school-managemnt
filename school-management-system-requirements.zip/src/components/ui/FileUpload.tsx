import { useRef, useState } from 'react';
import { Upload, FileText, X, Eye } from 'lucide-react';
import { getSettings } from '../../lib/db';

interface FileUploadProps {
  value?: { file_name: string; file_data: string; file_type: string } | null;
  onChange: (file: { file_name: string; file_data: string; file_type: string } | null) => void;
  accept?: string; // e.g. ".pdf,.jpg,.png"
  allowedMime?: string[]; // restrict mime types
  label?: string;
  maxMb?: number;
  onError?: (msg: string) => void;
}

const DEFAULT_MIME = ['application/pdf', 'image/jpeg', 'image/png', 'image/jpg'];

// Reusable file picker that stores files as base64 (works fully client-side).
export function FileUpload({ value, onChange, accept = '.pdf,.jpg,.jpeg,.png', allowedMime = DEFAULT_MIME, label, maxMb, onError }: FileUploadProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragOver, setDragOver] = useState(false);
  const limit = maxMb || getSettings().max_doc_size_mb || 5;

  const handleFiles = (files: FileList | null) => {
    const file = files?.[0];
    if (!file) return;
    if (allowedMime.length && !allowedMime.includes(file.type)) {
      onError?.('File type not allowed');
      return;
    }
    if (file.size > limit * 1024 * 1024) {
      onError?.(`File exceeds ${limit}MB limit`);
      return;
    }
    const reader = new FileReader();
    reader.onload = () => onChange({ file_name: file.name, file_data: reader.result as string, file_type: file.type });
    reader.readAsDataURL(file);
  };

  const view = () => {
    if (!value?.file_data) return;
    const w = window.open();
    if (!w) return;
    if (value.file_type === 'application/pdf') w.document.write(`<iframe src="${value.file_data}" style="width:100%;height:100%;border:none;"></iframe>`);
    else w.document.write(`<img src="${value.file_data}" style="max-width:100%;"/>`);
  };

  return (
    <div>
      {label && <label className="mb-1 block text-sm font-medium text-slate-700">{label}</label>}
      {value?.file_name ? (
        <div className="flex items-center justify-between rounded-lg border border-green-200 bg-green-50 px-3 py-2">
          <span className="flex items-center gap-2 text-sm text-slate-700"><FileText className="h-4 w-4 text-green-600" />{value.file_name}</span>
          <div className="flex gap-1">
            {value.file_data && <button type="button" onClick={view} className="rounded p-1 text-blue-600 hover:bg-blue-100" title="View"><Eye className="h-4 w-4" /></button>}
            <button type="button" onClick={() => onChange(null)} className="rounded p-1 text-red-600 hover:bg-red-100" title="Remove"><X className="h-4 w-4" /></button>
          </div>
        </div>
      ) : (
        <div
          onClick={() => inputRef.current?.click()}
          onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
          onDragLeave={() => setDragOver(false)}
          onDrop={(e) => { e.preventDefault(); setDragOver(false); handleFiles(e.dataTransfer.files); }}
          className={`flex cursor-pointer flex-col items-center justify-center rounded-lg border-2 border-dashed px-4 py-6 text-center transition ${dragOver ? 'border-blue-400 bg-blue-50' : 'border-slate-300 hover:border-blue-300 hover:bg-slate-50'}`}
        >
          <Upload className="mb-2 h-6 w-6 text-slate-400" />
          <p className="text-sm font-medium text-slate-600">Click to upload or drag &amp; drop</p>
          <p className="text-xs text-slate-400">Max {limit}MB</p>
        </div>
      )}
      <input ref={inputRef} type="file" accept={accept} className="hidden" onChange={(e) => handleFiles(e.target.files)} />
    </div>
  );
}
