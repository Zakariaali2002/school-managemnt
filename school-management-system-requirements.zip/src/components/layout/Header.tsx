import { useState } from 'react';
import { Bell, LogOut, User as UserIcon, Menu } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { User } from '../../types';
import { useCollection } from '../../hooks/useDB';
import { fmtDate } from '../../lib/utils';

export function Header({ user, onMenuClick }: { user: User; onMenuClick?: () => void }) {
  const { logout } = useAuth();
  const [open, setOpen] = useState(false);
  const notices = useCollection<any>('notices').filter(
    (n) => n.is_active && (n.target_roles?.includes(user.role) || user.role === 'super_admin'),
  );

  return (
    <header className="safe-area-top flex h-16 items-center justify-between border-b border-slate-200 bg-white px-4 sm:px-6">
      <div className="flex items-center gap-3">
        {/* Mobile hamburger menu */}
        <button
          onClick={onMenuClick}
          className="rounded-lg p-2 text-slate-600 hover:bg-slate-100 lg:hidden"
          aria-label="Open menu"
        >
          <Menu className="h-6 w-6" />
        </button>
        <div>
          <h2 className="text-sm font-semibold text-slate-900 sm:text-base">Welcome, {user.name}</h2>
          <p className="hidden text-xs text-slate-500 sm:block">
            {new Date().toLocaleDateString('en-PK', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
          </p>
        </div>
      </div>

      <div className="flex items-center gap-3">
        <div className="relative">
          <button
            onClick={() => setOpen((o) => !o)}
            className="relative rounded-full p-2 text-slate-600 hover:bg-slate-100"
          >
            <Bell className="h-5 w-5" />
            {notices.length > 0 && (
              <span className="absolute right-1 top-1 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[10px] font-bold text-white">
                {notices.length}
              </span>
            )}
          </button>
          {open && (
            <>
              <div className="fixed inset-0 z-10" onClick={() => setOpen(false)} />
              <div className="absolute right-0 z-20 mt-2 w-80 rounded-lg border border-slate-200 bg-white shadow-xl">
                <div className="border-b border-slate-100 px-4 py-3 text-sm font-semibold text-slate-900">
                  Notifications
                </div>
                <div className="max-h-80 overflow-y-auto">
                  {notices.length === 0 && <p className="p-4 text-sm text-slate-400">No new notices</p>}
                  {notices.map((n) => (
                    <div key={n.id} className="border-b border-slate-50 px-4 py-3 hover:bg-slate-50">
                      <p className="text-sm font-medium text-slate-900">{n.title}</p>
                      <p className="mt-0.5 line-clamp-2 text-xs text-slate-500">{n.content}</p>
                      <p className="mt-1 text-[11px] text-slate-400">{fmtDate(n.posted_at)}</p>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}
        </div>

        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-200">
            <UserIcon className="h-4 w-4 text-slate-600" />
          </div>
          <span className="hidden text-sm text-slate-700 sm:block">{user.email}</span>
        </div>

        <button onClick={logout} className="rounded-lg p-2 text-slate-600 hover:bg-slate-100" title="Logout">
          <LogOut className="h-4 w-4" />
        </button>
      </div>
    </header>
  );
}
