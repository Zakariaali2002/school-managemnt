import { NavLink } from 'react-router-dom';
import { cn } from '../../utils/cn';
import { UserRole } from '../../types';
import {
  LayoutDashboard, GraduationCap, UserCog, Wallet, CheckSquare, BookOpen,
  Trophy, MessageSquare, Receipt, Users, CalendarCheck, FileText,
} from 'lucide-react';

interface NavItem { name: string; icon: any; path: string }

// Har role ke liye 4-5 sab se important shortcuts (mobile bottom bar).
const bottomMenus: Record<UserRole, NavItem[]> = {
  super_admin: [
    { name: 'Home', icon: LayoutDashboard, path: '/dashboard' },
    { name: 'Students', icon: GraduationCap, path: '/dashboard/students' },
    { name: 'Staff', icon: UserCog, path: '/dashboard/staff' },
    { name: 'Users', icon: Users, path: '/dashboard/users' },
  ],
  principal: [
    { name: 'Home', icon: LayoutDashboard, path: '/dashboard' },
    { name: 'Students', icon: GraduationCap, path: '/dashboard/students' },
    { name: 'Attend', icon: CheckSquare, path: '/dashboard/attendance' },
    { name: 'Exams', icon: FileText, path: '/dashboard/exams' },
  ],
  hr: [
    { name: 'Home', icon: LayoutDashboard, path: '/dashboard' },
    { name: 'Staff', icon: UserCog, path: '/dashboard/staff' },
    { name: 'Leave', icon: CalendarCheck, path: '/dashboard/leave' },
    { name: 'Payroll', icon: Wallet, path: '/dashboard/payroll' },
  ],
  accounts: [
    { name: 'Home', icon: LayoutDashboard, path: '/dashboard' },
    { name: 'Fees', icon: Receipt, path: '/dashboard/fee-vouchers' },
    { name: 'Pay', icon: Wallet, path: '/dashboard/payments' },
    { name: 'Reports', icon: FileText, path: '/dashboard/reports' },
  ],
  teacher: [
    { name: 'Home', icon: LayoutDashboard, path: '/dashboard' },
    { name: 'Attend', icon: CheckSquare, path: '/dashboard/attendance' },
    { name: 'Marks', icon: FileText, path: '/dashboard/marks' },
    { name: 'Tasks', icon: BookOpen, path: '/dashboard/assignments' },
  ],
  student: [
    { name: 'Home', icon: LayoutDashboard, path: '/dashboard' },
    { name: 'Attend', icon: CheckSquare, path: '/dashboard/attendance' },
    { name: 'Results', icon: Trophy, path: '/dashboard/results' },
    { name: 'Fee', icon: Wallet, path: '/dashboard/fee' },
  ],
  parent: [
    { name: 'Home', icon: LayoutDashboard, path: '/dashboard' },
    { name: 'Progress', icon: Trophy, path: '/dashboard/progress' },
    { name: 'Fee', icon: Wallet, path: '/dashboard/fee' },
    { name: 'Chat', icon: MessageSquare, path: '/dashboard/messages' },
  ],
};

// Mobile-only bottom navigation bar (real app jaisa feel).
export function BottomNav({ role }: { role: UserRole }) {
  const items = bottomMenus[role] || [];
  return (
    <nav className="safe-area-bottom fixed bottom-0 left-0 right-0 z-30 flex items-center justify-around border-t border-slate-200 bg-white/95 backdrop-blur lg:hidden">
      {items.map((item) => (
        <NavLink
          key={item.path}
          to={item.path}
          end={item.path === '/dashboard'}
          className={({ isActive }) =>
            cn(
              'flex flex-1 flex-col items-center gap-0.5 py-2 text-[10px] font-medium transition-colors',
              isActive ? 'text-indigo-600' : 'text-slate-400 hover:text-slate-600',
            )
          }
        >
          <item.icon className="h-5 w-5" />
          {item.name}
        </NavLink>
      ))}
    </nav>
  );
}
