import { useLocation, useNavigate, Link } from 'react-router-dom';
import { ChevronRight, Home, ArrowLeft } from 'lucide-react';

// Converts a path segment like "fee-vouchers" into "Fee Vouchers".
function humanize(seg: string): string {
  return seg
    .replace(/-/g, ' ')
    .replace(/\b\w/g, (c) => c.toUpperCase());
}

export function Breadcrumb() {
  const location = useLocation();
  const navigate = useNavigate();
  // strip the leading "dashboard"
  const parts = location.pathname.split('/').filter(Boolean); // e.g. ['dashboard','fee-vouchers']
  const afterDashboard = parts.slice(1); // segments after /dashboard

  return (
    <div className="mb-4 flex items-center justify-between">
      <nav className="flex items-center gap-1.5 text-sm text-slate-500">
        <Link to="/dashboard" className="flex items-center gap-1 hover:text-indigo-600">
          <Home className="h-4 w-4" /> Dashboard
        </Link>
        {afterDashboard.map((seg, i) => (
          <span key={i} className="flex items-center gap-1.5">
            <ChevronRight className="h-3.5 w-3.5 text-slate-300" />
            <span className={i === afterDashboard.length - 1 ? 'font-medium text-slate-700' : ''}>
              {humanize(seg)}
            </span>
          </span>
        ))}
      </nav>
      {afterDashboard.length > 0 && (
        <button
          onClick={() => navigate(-1)}
          className="flex items-center gap-1 rounded-lg border border-slate-200 px-2.5 py-1 text-xs font-medium text-slate-600 hover:bg-slate-50"
        >
          <ArrowLeft className="h-3.5 w-3.5" /> Back
        </button>
      )}
    </div>
  );
}
