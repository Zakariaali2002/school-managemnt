import { NavLink } from 'react-router-dom';
import { cn } from '../../utils/cn';
import { UserRole } from '../../types';
import { getSettings } from '../../lib/db';
import {
  LayoutDashboard, Users, GraduationCap, UserCog, Wallet, ScrollText, Settings,
  CheckSquare, FileText, ClipboardCheck, Megaphone, BarChart3, Plane, CreditCard,
  FolderOpen, Receipt, Banknote, BookOpen, CalendarDays, Trophy, MessageSquare, TrendingUp,
  ScanLine, Contact, FileCheck2, BookText, Landmark, Wallet2, Coins, CalendarCheck,
  UserPlus, Users2, Library, Bus, Building2, Boxes, Bell, ShieldCheck, GitBranch,
  Percent, AlertTriangle, FileBarChart, ListChecks, ClipboardList,
} from 'lucide-react';

interface MenuItem {
  name: string;
  icon: any;
  path: string;
}
interface MenuSection {
  section?: string;
  items: MenuItem[];
}

const roleMenus: Record<UserRole, MenuSection[]> = {
  // ---------------- SUPER ADMIN — full system access ----------------
  super_admin: [
    { items: [{ name: 'Dashboard', icon: LayoutDashboard, path: '/dashboard' }] },
    {
      section: 'Academics',
      items: [
        { name: 'Admissions', icon: UserPlus, path: '/dashboard/admissions' },
        { name: 'Students', icon: GraduationCap, path: '/dashboard/students' },
        { name: 'Parents', icon: Users2, path: '/dashboard/parents' },
        { name: 'Teachers', icon: UserCog, path: '/dashboard/teachers' },
        { name: 'Classes & Sections', icon: BookOpen, path: '/dashboard/classes' },
        { name: 'Subjects', icon: BookText, path: '/dashboard/subjects' },
        { name: 'Timetable', icon: CalendarDays, path: '/dashboard/timetable' },
        { name: 'Attendance', icon: CheckSquare, path: '/dashboard/attendance' },
        { name: 'Examination', icon: FileText, path: '/dashboard/exams' },
        { name: 'Results', icon: Trophy, path: '/dashboard/results' },
      ],
    },
    {
      section: 'HR & Staff',
      items: [
        { name: 'Employees / HR', icon: Users, path: '/dashboard/staff' },
        { name: 'Payroll', icon: CreditCard, path: '/dashboard/payroll' },
        { name: 'ID Cards', icon: Contact, path: '/dashboard/id-cards' },
        { name: 'Attendance Scanner', icon: ScanLine, path: '/dashboard/scanner' },
      ],
    },
    {
      section: 'Finance',
      items: [
        { name: 'Fees Management', icon: Receipt, path: '/dashboard/finance' },
        { name: 'Finance & Accounts', icon: Wallet, path: '/dashboard/cashbook' },
      ],
    },
    {
      section: 'Operations',
      items: [
        { name: 'Library', icon: Library, path: '/dashboard/library' },
        { name: 'Transport', icon: Bus, path: '/dashboard/transport' },
        { name: 'Hostel', icon: Building2, path: '/dashboard/hostel' },
        { name: 'Inventory', icon: Boxes, path: '/dashboard/inventory' },
      ],
    },
    {
      section: 'Communication',
      items: [
        { name: 'Communication / SMS', icon: MessageSquare, path: '/dashboard/communication' },
        { name: 'Notifications', icon: Bell, path: '/dashboard/notifications' },
        { name: 'Notices', icon: Megaphone, path: '/dashboard/notices' },
      ],
    },
    {
      section: 'System',
      items: [
        { name: 'Documents', icon: FileCheck2, path: '/dashboard/documents' },
        { name: 'Reports', icon: BarChart3, path: '/dashboard/reports' },
        { name: 'User Management', icon: Users, path: '/dashboard/users' },
        { name: 'Roles & Permissions', icon: ShieldCheck, path: '/dashboard/roles' },
        { name: 'Branch Management', icon: GitBranch, path: '/dashboard/branches' },
        { name: 'Audit Logs', icon: ScrollText, path: '/dashboard/logs' },
        { name: 'System Settings', icon: Settings, path: '/dashboard/settings' },
      ],
    },
  ],

  // ---------------- PRINCIPAL ----------------
  principal: [
    { items: [{ name: 'Dashboard', icon: LayoutDashboard, path: '/dashboard' }] },
    {
      section: 'Academics',
      items: [
        { name: 'Students', icon: GraduationCap, path: '/dashboard/students' },
        { name: 'Teachers', icon: UserCog, path: '/dashboard/staff' },
        { name: 'Attendance', icon: CheckSquare, path: '/dashboard/attendance' },
        { name: 'Examination', icon: FileText, path: '/dashboard/exams' },
        { name: 'Results', icon: Trophy, path: '/dashboard/results' },
        { name: 'Timetable', icon: CalendarDays, path: '/dashboard/timetable' },
      ],
    },
    {
      section: 'Management',
      items: [
        { name: 'Approvals', icon: ClipboardCheck, path: '/dashboard/approvals' },
        { name: 'ID Cards', icon: Contact, path: '/dashboard/id-cards' },
        { name: 'Scanner', icon: ScanLine, path: '/dashboard/scanner' },
        { name: 'Notices', icon: Megaphone, path: '/dashboard/notices' },
        { name: 'Reports', icon: BarChart3, path: '/dashboard/reports' },
      ],
    },
    {
      section: 'Personal',
      items: [
        { name: 'My Attendance', icon: CalendarCheck, path: '/dashboard/my-attendance' },
        { name: 'Documents', icon: FileCheck2, path: '/dashboard/documents' },
        { name: 'My Documents', icon: FolderOpen, path: '/dashboard/my-documents' },
      ],
    },
  ],

  // ---------------- HR ----------------
  hr: [
    { items: [{ name: 'Dashboard', icon: LayoutDashboard, path: '/dashboard' }] },
    {
      section: 'Staff Management',
      items: [
        { name: 'Employees', icon: UserCog, path: '/dashboard/staff' },
        { name: 'Leave Requests', icon: Plane, path: '/dashboard/leave' },
        { name: 'Staff Attendance', icon: CheckSquare, path: '/dashboard/staff-attendance' },
        { name: 'My Attendance', icon: CalendarCheck, path: '/dashboard/my-attendance' },
        { name: 'Payroll', icon: CreditCard, path: '/dashboard/payroll' },
        { name: 'ID Cards', icon: Contact, path: '/dashboard/id-cards' },
        { name: 'Scanner', icon: ScanLine, path: '/dashboard/scanner' },
      ],
    },
    {
      section: 'Documents',
      items: [
        { name: 'Documents', icon: FileCheck2, path: '/dashboard/documents' },
        { name: 'Staff Files', icon: FolderOpen, path: '/dashboard/staff-files' },
        { name: 'My Documents', icon: BookText, path: '/dashboard/my-documents' },
      ],
    },
  ],

  // ---------------- ACCOUNTS — full finance suite ----------------
  accounts: [
    { items: [{ name: 'Dashboard', icon: LayoutDashboard, path: '/dashboard' }] },
    {
      section: 'Fee Management',
      items: [
        { name: 'Fee Collection', icon: Banknote, path: '/dashboard/payments' },
        { name: 'Fee Vouchers', icon: Receipt, path: '/dashboard/fee-vouchers' },
        { name: 'Pending Fees', icon: ClipboardList, path: '/dashboard/pending-fees' },
        { name: 'Fee Defaulters', icon: AlertTriangle, path: '/dashboard/defaulters' },
        { name: 'Fee Structure', icon: ListChecks, path: '/dashboard/fee-structure' },
        { name: 'Discounts', icon: Percent, path: '/dashboard/discounts' },
        { name: 'Fines / Penalties', icon: AlertTriangle, path: '/dashboard/fines' },
      ],
    },
    {
      section: 'Accounting',
      items: [
        { name: 'Vouchers', icon: Wallet2, path: '/dashboard/vouchers' },
        { name: 'Income', icon: TrendingUp, path: '/dashboard/income' },
        { name: 'Expenses', icon: Wallet, path: '/dashboard/expenses' },
        { name: 'General Ledger', icon: BookText, path: '/dashboard/ledger' },
        { name: 'Cash Book', icon: BookText, path: '/dashboard/cashbook' },
        { name: 'Bank Transactions', icon: Landmark, path: '/dashboard/bank' },
      ],
    },
    {
      section: 'Payroll',
      items: [
        { name: 'Salary Processing', icon: Coins, path: '/dashboard/salary' },
        { name: 'Payroll Reports', icon: FileBarChart, path: '/dashboard/payroll' },
      ],
    },
    {
      section: 'Reports',
      items: [
        { name: 'Financial Reports', icon: BarChart3, path: '/dashboard/reports' },
        { name: 'Student Fin. History', icon: ClipboardList, path: '/dashboard/student-finance' },
        { name: 'Daily Collection', icon: CalendarCheck, path: '/dashboard/daily-collection' },
        { name: 'Monthly Collection', icon: CalendarDays, path: '/dashboard/monthly-collection' },
        { name: 'Outstanding Dues', icon: AlertTriangle, path: '/dashboard/outstanding' },
      ],
    },
    {
      section: 'Personal',
      items: [
        { name: 'My Attendance', icon: CalendarCheck, path: '/dashboard/my-attendance' },
        { name: 'My Documents', icon: FolderOpen, path: '/dashboard/documents' },
      ],
    },
  ],

  // ---------------- TEACHER ----------------
  teacher: [
    { items: [{ name: 'Dashboard', icon: LayoutDashboard, path: '/dashboard' }] },
    {
      section: 'Teaching',
      items: [
        { name: 'Attendance', icon: CheckSquare, path: '/dashboard/attendance' },
        { name: 'Marks', icon: FileText, path: '/dashboard/marks' },
        { name: 'Assignments', icon: BookOpen, path: '/dashboard/assignments' },
        { name: 'Timetable', icon: CalendarDays, path: '/dashboard/timetable' },
        { name: 'Scanner', icon: ScanLine, path: '/dashboard/scanner' },
      ],
    },
    {
      section: 'Personal',
      items: [
        { name: 'My Attendance', icon: CalendarCheck, path: '/dashboard/my-attendance' },
        { name: 'My Documents', icon: FolderOpen, path: '/dashboard/documents' },
        { name: 'Leave', icon: Plane, path: '/dashboard/leave' },
      ],
    },
  ],

  // ---------------- STUDENT ----------------
  student: [
    { items: [{ name: 'Dashboard', icon: LayoutDashboard, path: '/dashboard' }] },
    {
      section: 'My Studies',
      items: [
        { name: 'My Attendance', icon: CheckSquare, path: '/dashboard/attendance' },
        { name: 'Timetable', icon: CalendarDays, path: '/dashboard/timetable' },
        { name: 'Assignments', icon: BookOpen, path: '/dashboard/assignments' },
        { name: 'Results', icon: Trophy, path: '/dashboard/results' },
      ],
    },
    {
      section: 'More',
      items: [
        { name: 'Fee Status', icon: Wallet, path: '/dashboard/fee' },
        { name: 'My Documents', icon: FolderOpen, path: '/dashboard/documents' },
        { name: 'Notices', icon: Megaphone, path: '/dashboard/notices' },
      ],
    },
  ],

  // ---------------- PARENT ----------------
  parent: [
    { items: [{ name: 'Dashboard', icon: LayoutDashboard, path: '/dashboard' }] },
    {
      section: 'My Children',
      items: [
        { name: 'Progress', icon: TrendingUp, path: '/dashboard/progress' },
        { name: 'Attendance', icon: CheckSquare, path: '/dashboard/attendance' },
        { name: 'Fee', icon: Wallet, path: '/dashboard/fee' },
      ],
    },
    {
      section: 'Communication',
      items: [
        { name: 'Messages', icon: MessageSquare, path: '/dashboard/messages' },
        { name: 'My Documents', icon: FolderOpen, path: '/dashboard/documents' },
        { name: 'Notices', icon: Megaphone, path: '/dashboard/notices' },
      ],
    },
  ],
};

export function Sidebar({ role, open = false, onClose }: { role: UserRole; open?: boolean; onClose?: () => void }) {
  const sections = roleMenus[role] || [];
  const settings = getSettings();

  const content = (
    <>
      <div className="safe-area-top flex h-16 shrink-0 items-center gap-3 border-b border-slate-200 px-5">
        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-blue-600 to-indigo-600">
          <span className="text-sm font-bold text-white">SMS</span>
        </div>
        <div className="overflow-hidden">
          <h1 className="truncate text-sm font-semibold text-slate-900">{settings.school_name}</h1>
          <p className="text-xs capitalize text-slate-500">{role.replace('_', ' ')}</p>
        </div>
      </div>

      {/* min-h-0 ensures the flex child can scroll; pb gives breathing room at the end */}
      <nav className="min-h-0 flex-1 overflow-y-auto p-3 pb-8">
        {sections.map((sec, si) => (
          <div key={si} className="mb-2">
            {sec.section && (
              <p className="px-3 pb-1 pt-3 text-[10px] font-semibold uppercase tracking-wider text-slate-400">
                {sec.section}
              </p>
            )}
            <ul className="space-y-0.5">
              {sec.items.map((item) => (
                <li key={item.path + item.name}>
                  <NavLink
                    to={item.path}
                    end={item.path === '/dashboard'}
                    onClick={onClose}
                    className={({ isActive }) =>
                      cn(
                        'flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors',
                        isActive ? 'bg-blue-50 text-blue-700' : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900',
                      )
                    }
                  >
                    <item.icon className="h-[18px] w-[18px] shrink-0" />
                    <span className="truncate">{item.name}</span>
                  </NavLink>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </nav>
    </>
  );

  return (
    <>
      {/* Desktop / tablet: fixed sidebar */}
      <aside className="hidden h-screen w-60 flex-col border-r border-slate-200 bg-white lg:flex">{content}</aside>

      {/* Mobile: slide-in drawer */}
      <div className={cn('fixed inset-0 z-40 lg:hidden', open ? '' : 'pointer-events-none')}>
        <div
          onClick={onClose}
          className={cn('absolute inset-0 bg-slate-900/50 transition-opacity', open ? 'opacity-100' : 'opacity-0')}
        />
        <aside
          className={cn(
            'absolute left-0 top-0 flex h-full w-72 max-w-[80%] flex-col bg-white shadow-2xl transition-transform duration-300',
            open ? 'translate-x-0' : '-translate-x-full',
          )}
        >
          {content}
        </aside>
      </div>
    </>
  );
}


