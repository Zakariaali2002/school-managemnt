import { AlertTriangle, Clock, FileWarning } from 'lucide-react';
import { useCollection } from '../hooks/useDB';
import { Card } from './ui/Shared';
import { daysUntil } from '../lib/documents';
import { fmtDate } from '../lib/utils';

// Global document alerts widget for admin dashboards (missing/expiring/pending).
export function DocumentAlerts() {
  const documents = useCollection<any>('documents');
  const categories = useCollection<any>('documentCategories');
  const users = useCollection<any>('users');
  const students = useCollection<any>('students');

  const userName = (id: string) => users.find((u) => u.id === id)?.name || students.find((s) => s.user_id === id)?.name || '-';
  const catName = (id: string) => categories.find((c) => c.id === id)?.name || '-';

  const pending = documents.filter((d) => d.status === 'pending');
  const expiring = documents.filter((d) => d.expiry_date && daysUntil(d.expiry_date) <= 30 && daysUntil(d.expiry_date) >= 0);
  const expired = documents.filter((d) => d.expiry_date && daysUntil(d.expiry_date) < 0);

  // Missing required docs across active users
  const missing: { name: string; doc: string }[] = [];
  users.filter((u) => u.is_active).forEach((u) => {
    const reqCats = categories.filter((c) => c.role === u.role && c.required);
    reqCats.forEach((c) => {
      if (!documents.find((d) => d.user_id === u.id && d.category_id === c.id)) {
        missing.push({ name: u.name, doc: c.name });
      }
    });
  });

  return (
    <div className="grid gap-4 md:grid-cols-3">
      <Card>
        <div className="mb-2 flex items-center gap-2">
          <div className="rounded-lg bg-red-100 p-1.5"><FileWarning className="h-4 w-4 text-red-600" /></div>
          <h3 className="text-sm font-semibold text-slate-900">Missing Documents ({missing.length})</h3>
        </div>
        <div className="max-h-40 space-y-1 overflow-y-auto">
          {missing.slice(0, 8).map((m, i) => (
            <div key={i} className="rounded bg-red-50 px-2 py-1 text-xs">
              <span className="font-medium text-slate-800">{m.name}</span> <span className="text-slate-500">— {m.doc}</span>
            </div>
          ))}
          {missing.length === 0 && <p className="text-xs text-slate-400">All required documents submitted</p>}
        </div>
      </Card>

      <Card>
        <div className="mb-2 flex items-center gap-2">
          <div className="rounded-lg bg-orange-100 p-1.5"><Clock className="h-4 w-4 text-orange-600" /></div>
          <h3 className="text-sm font-semibold text-slate-900">Expiring Soon ({expiring.length})</h3>
        </div>
        <div className="max-h-40 space-y-1 overflow-y-auto">
          {expiring.map((d) => (
            <div key={d.id} className="rounded bg-orange-50 px-2 py-1 text-xs">
              <span className="font-medium text-slate-800">{userName(d.user_id)}</span> <span className="text-slate-500">— {catName(d.category_id)} ({daysUntil(d.expiry_date)}d)</span>
            </div>
          ))}
          {expired.map((d) => (
            <div key={d.id} className="rounded bg-red-50 px-2 py-1 text-xs">
              <span className="font-medium text-slate-800">{userName(d.user_id)}</span> <span className="text-red-500">— {catName(d.category_id)} EXPIRED ({fmtDate(d.expiry_date)})</span>
            </div>
          ))}
          {expiring.length === 0 && expired.length === 0 && <p className="text-xs text-slate-400">No documents expiring</p>}
        </div>
      </Card>

      <Card>
        <div className="mb-2 flex items-center gap-2">
          <div className="rounded-lg bg-yellow-100 p-1.5"><AlertTriangle className="h-4 w-4 text-yellow-600" /></div>
          <h3 className="text-sm font-semibold text-slate-900">Verification Pending ({pending.length})</h3>
        </div>
        <div className="max-h-40 space-y-1 overflow-y-auto">
          {pending.slice(0, 8).map((d) => (
            <div key={d.id} className="rounded bg-yellow-50 px-2 py-1 text-xs">
              <span className="font-medium text-slate-800">{userName(d.user_id)}</span> <span className="text-slate-500">— {catName(d.category_id)}</span>
            </div>
          ))}
          {pending.length === 0 && <p className="text-xs text-slate-400">Nothing pending review</p>}
        </div>
      </Card>
    </div>
  );
}

// Personal document alert banner for end-users (their own missing/expiring/rejected docs)
export function MyDocumentAlerts({ userId, role }: { userId: string; role: string }) {
  const documents = useCollection<any>('documents').filter((d) => d.user_id === userId);
  const categories = useCollection<any>('documentCategories').filter((c) => c.role === role);

  const missing = categories.filter((c) => c.required && !documents.find((d) => d.category_id === c.id));
  const rejected = documents.filter((d) => d.status === 'rejected');
  const expiring = documents.filter((d) => d.expiry_date && daysUntil(d.expiry_date) <= 30 && daysUntil(d.expiry_date) >= 0);

  if (missing.length === 0 && rejected.length === 0 && expiring.length === 0) return null;

  return (
    <div className="mb-6 space-y-2">
      {missing.length > 0 && (
        <div className="rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700">
          <AlertTriangle className="mr-1 inline h-4 w-4" /> Missing required documents: <span className="font-medium">{missing.map((m) => m.name).join(', ')}</span>
        </div>
      )}
      {rejected.length > 0 && (
        <div className="rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700">
          <AlertTriangle className="mr-1 inline h-4 w-4" /> {rejected.length} document(s) rejected — please re-upload. Check "My Documents".
        </div>
      )}
      {expiring.map((d) => (
        <div key={d.id} className="rounded-lg border border-orange-200 bg-orange-50 p-3 text-sm text-orange-700">
          <Clock className="mr-1 inline h-4 w-4" /> A document will expire in {daysUntil(d.expiry_date)} days. Please upload a renewed copy.
        </div>
      ))}
    </div>
  );
}
