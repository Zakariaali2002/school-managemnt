import { useState, useEffect } from 'react';
import { LogIn, LogOut, Clock, CheckCircle2, Calendar, TrendingUp, CalendarCheck, CalendarX } from 'lucide-react';
import { useCollection } from '../hooks/useDB';
import { insert, update, logActivity } from '../lib/db';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from './ui/Toast';
import { fmtDate } from '../lib/utils';

type Kind = 'student' | 'staff';

interface Props {
  kind: Kind;
  // The record id used to tag attendance rows (student_id or staff_id)
  entityId: string;
  // display name + meta
  name: string;
  meta?: string;
  // optional class id for student records
  classId?: string;
  lateAfter?: string; // HH:MM
}

const STATUS_STYLES: Record<string, { bg: string; text: string; ring: string; label: string }> = {
  present: { bg: 'bg-emerald-50', text: 'text-emerald-700', ring: 'ring-emerald-200', label: 'Present' },
  late: { bg: 'bg-amber-50', text: 'text-amber-700', ring: 'ring-amber-200', label: 'Late' },
  absent: { bg: 'bg-rose-50', text: 'text-rose-700', ring: 'ring-rose-200', label: 'Absent' },
  leave: { bg: 'bg-sky-50', text: 'text-sky-700', ring: 'ring-sky-200', label: 'Leave' },
};

function useClock() {
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);
  return now;
}

export function SelfAttendance({ kind, entityId, name, meta, classId, lateAfter = '08:30' }: Props) {
  const { user } = useAuth();
  const { notify } = useToast();
  const collection = kind === 'student' ? 'studentAttendance' : 'staffAttendance';
  const idField = kind === 'student' ? 'student_id' : 'staff_id';
  const all = useCollection<any>(collection).filter((r) => r[idField] === entityId);
  const now = useClock();
  const today = now.toISOString().slice(0, 10);
  const todayRec = all.find((r) => r.date === today);

  const hhmm = now.toTimeString().slice(0, 5);
  const isLate = hhmm > lateAfter;

  const checkIn = () => {
    if (todayRec && todayRec.check_in) return notify('Already checked in today', 'info');
    const status = isLate ? 'late' : 'present';
    const base: any = { date: today, status, check_in: hhmm, check_out: '', remarks: 'Self check-in' };
    if (kind === 'student') { base[idField] = entityId; base.class_id = classId; base.marked_by = user!.id; }
    else { base[idField] = entityId; }
    if (todayRec) update(collection, todayRec.id, { status, check_in: hhmm });
    else insert(collection, base);
    logActivity(user!, `Self check-in (${status}) at ${hhmm}`, collection, entityId);
    notify(`Checked in at ${hhmm}${isLate ? ' (Late)' : ''}`, 'success');
  };

  const checkOut = () => {
    if (!todayRec || !todayRec.check_in) return notify('Please check in first', 'error');
    if (todayRec.check_out) return notify('Already checked out today', 'info');
    update(collection, todayRec.id, { check_out: hhmm });
    logActivity(user!, `Self check-out at ${hhmm}`, collection, entityId);
    notify(`Checked out at ${hhmm}`, 'success');
  };

  // Stats
  const present = all.filter((r) => r.status === 'present' || r.status === 'late').length;
  const absent = all.filter((r) => r.status === 'absent').length;
  const leave = all.filter((r) => r.status === 'leave').length;
  const pct = all.length ? Math.round((present / all.length) * 100) : 0;
  const monthStart = today.slice(0, 8) + '01';
  const monthCount = all.filter((r) => r.date >= monthStart && (r.status === 'present' || r.status === 'late')).length;

  const status = todayRec?.status;
  const sStyle = status ? STATUS_STYLES[status] : null;

  return (
    <div className="space-y-6">
      {/* Hero check-in card */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-indigo-600 via-violet-600 to-purple-600 p-8 text-white shadow-xl shadow-indigo-200">
        <div className="absolute -right-10 -top-10 h-44 w-44 rounded-full bg-white/10" />
        <div className="absolute -bottom-16 -left-10 h-52 w-52 rounded-full bg-white/5" />
        <div className="relative flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
          <div>
            <div className="flex items-center gap-2 text-sm text-indigo-100">
              <Calendar className="h-4 w-4" />
              {now.toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
            </div>
            <div className="mt-2 flex items-end gap-3">
              <span className="font-mono text-5xl font-bold tracking-tight tabular-nums">
                {now.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}
              </span>
              <span className="mb-1.5 font-mono text-xl text-indigo-200 tabular-nums">
                {now.toLocaleTimeString('en-GB', { second: '2-digit' })}s
              </span>
            </div>
            <p className="mt-3 text-lg font-semibold">{name}</p>
            {meta && <p className="text-sm text-indigo-100">{meta}</p>}
          </div>

          <div className="flex flex-col items-stretch gap-3 md:w-72">
            {/* today status pill */}
            <div className="rounded-2xl bg-white/10 p-4 backdrop-blur">
              <p className="text-xs uppercase tracking-wide text-indigo-100">Today's Status</p>
              {todayRec ? (
                <div className="mt-1 flex items-center gap-2">
                  <CheckCircle2 className="h-5 w-5" />
                  <span className="text-lg font-semibold capitalize">{sStyle?.label || status}</span>
                  <span className="ml-auto text-sm text-indigo-100">
                    {todayRec.check_in && <>in {todayRec.check_in}</>}{todayRec.check_out && <> · out {todayRec.check_out}</>}
                  </span>
                </div>
              ) : (
                <p className="mt-1 text-lg font-semibold text-indigo-100">Not marked yet</p>
              )}
            </div>

            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={checkIn}
                disabled={!!todayRec?.check_in}
                className="flex items-center justify-center gap-2 rounded-2xl bg-white px-4 py-3 font-semibold text-indigo-700 shadow-lg transition hover:bg-indigo-50 disabled:cursor-not-allowed disabled:opacity-50"
              >
                <LogIn className="h-5 w-5" /> Check In
              </button>
              <button
                onClick={checkOut}
                disabled={!todayRec?.check_in || !!todayRec?.check_out}
                className="flex items-center justify-center gap-2 rounded-2xl bg-indigo-900/40 px-4 py-3 font-semibold text-white shadow-lg ring-1 ring-white/30 transition hover:bg-indigo-900/60 disabled:cursor-not-allowed disabled:opacity-40"
              >
                <LogOut className="h-5 w-5" /> Check Out
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Stat tiles */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatTile icon={TrendingUp} label="Attendance Rate" value={`${pct}%`} tone="indigo" />
        <StatTile icon={CalendarCheck} label="Days Present" value={present} tone="emerald" />
        <StatTile icon={CalendarX} label="Days Absent" value={absent} tone="rose" />
        <StatTile icon={Clock} label="This Month" value={monthCount} tone="violet" />
      </div>

      {/* Donut + breakdown */}
      <div className="grid gap-6 lg:grid-cols-3">
        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
          <h3 className="mb-4 text-sm font-semibold text-slate-700">Overall</h3>
          <div className="flex items-center justify-center">
            <div className="relative h-40 w-40">
              <svg className="h-full w-full -rotate-90">
                <defs>
                  <linearGradient id="attGrad" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0%" stopColor="#6366f1" />
                    <stop offset="100%" stopColor="#a855f7" />
                  </linearGradient>
                </defs>
                <circle cx="80" cy="80" r="64" stroke="#eef2ff" strokeWidth="16" fill="none" />
                <circle cx="80" cy="80" r="64" stroke="url(#attGrad)" strokeWidth="16" strokeLinecap="round" fill="none"
                  strokeDasharray={402} strokeDashoffset={402 - (402 * pct) / 100}
                  style={{ transition: 'stroke-dashoffset 0.6s ease' }} />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-3xl font-bold text-slate-900">{pct}%</span>
                <span className="text-xs text-slate-400">{present}/{all.length} days</span>
              </div>
            </div>
          </div>
          <div className="mt-4 grid grid-cols-3 gap-2 text-center text-xs">
            <Legend color="bg-emerald-500" label="Present" val={present} />
            <Legend color="bg-rose-500" label="Absent" val={absent} />
            <Legend color="bg-sky-500" label="Leave" val={leave} />
          </div>
        </div>

        {/* Recent records timeline */}
        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm lg:col-span-2">
          <h3 className="mb-4 text-sm font-semibold text-slate-700">Recent Activity</h3>
          <div className="max-h-72 space-y-2 overflow-y-auto pr-1">
            {all.slice(-20).reverse().map((r) => {
              const st = STATUS_STYLES[r.status] || STATUS_STYLES.present;
              return (
                <div key={r.id} className={`flex items-center gap-3 rounded-xl px-4 py-3 ring-1 ${st.bg} ${st.ring}`}>
                  <div className={`flex h-9 w-9 items-center justify-center rounded-full bg-white ${st.text}`}>
                    <CalendarCheck className="h-4 w-4" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-slate-800">{fmtDate(r.date)}</p>
                    {(r.check_in || r.check_out) && (
                      <p className="text-xs text-slate-500">
                        {r.check_in && <>In {r.check_in}</>}{r.check_out && <> · Out {r.check_out}</>}
                      </p>
                    )}
                  </div>
                  <span className={`rounded-full px-3 py-1 text-xs font-semibold ${st.text} ${st.bg} ring-1 ${st.ring}`}>{st.label}</span>
                </div>
              );
            })}
            {all.length === 0 && (
              <div className="py-10 text-center text-sm text-slate-400">No attendance records yet. Tap "Check In" to start.</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function StatTile({ icon: Icon, label, value, tone }: { icon: any; label: string; value: string | number; tone: string }) {
  const tones: Record<string, string> = {
    indigo: 'from-indigo-500 to-indigo-600',
    emerald: 'from-emerald-500 to-emerald-600',
    rose: 'from-rose-500 to-rose-600',
    violet: 'from-violet-500 to-violet-600',
  };
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
      <div className={`mb-3 inline-flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br ${tones[tone]} text-white`}>
        <Icon className="h-5 w-5" />
      </div>
      <p className="text-2xl font-bold text-slate-900">{value}</p>
      <p className="text-xs text-slate-500">{label}</p>
    </div>
  );
}

function Legend({ color, label, val }: { color: string; label: string; val: number }) {
  return (
    <div>
      <div className="flex items-center justify-center gap-1.5">
        <span className={`h-2.5 w-2.5 rounded-full ${color}`} />
        <span className="font-semibold text-slate-700">{val}</span>
      </div>
      <p className="mt-0.5 text-slate-400">{label}</p>
    </div>
  );
}
