import { useSyncExternalStore } from 'react';
import { subscribe, getAll, DBShape } from '../lib/db';

// Re-renders the component whenever the DB collection changes.
export function useCollection<T = any>(collection: keyof DBShape): T[] {
  return useSyncExternalStore(
    subscribe,
    () => getAll<T>(collection),
    () => getAll<T>(collection),
  );
}

// Subscribe to the whole DB (any change) - returns a counter to force updates.
export function useDBVersion(): number {
  return useSyncExternalStore(
    subscribe,
    () => version,
    () => version,
  );
}

let version = 0;
subscribe(() => {
  version++;
});
