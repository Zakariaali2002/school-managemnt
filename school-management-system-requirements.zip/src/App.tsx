import { ReactElement, useState } from 'react';
// HashRouter use kar rahe hain taake routing web aur mobile app (file://) dono par chale.
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { ToastProvider } from './components/ui/Toast';
import { ConfirmProvider } from './components/ui/Confirm';
import { Login } from './pages/auth/Login';
import { VersionSelect } from './pages/VersionSelect';
import { Sidebar } from './components/layout/Sidebar';
import { Header } from './components/layout/Header';
import { BottomNav } from './components/layout/BottomNav';
import { Breadcrumb } from './components/layout/Breadcrumb';
import { UserRole } from './types';
import { getAll } from './lib/db';
import { useCollection } from './hooks/useDB';

import {
  SuperAdminHome, PrincipalHome, HRHome, TeacherHome, StudentHome, ParentHome, useMyStudent,
} from './pages/Dashboards';
import { UsersPage } from './pages/modules/Users';
import { StudentsPage } from './pages/modules/Students';
import { StaffPage } from './pages/modules/Staff';
import { ClassesPage } from './pages/modules/Classes';
import { AttendancePage, AttendanceView, StaffAttendanceView } from './pages/modules/Attendance';
import { StaffAttendancePage } from './pages/modules/StaffAttendance';
import { ExamsPage } from './pages/modules/Exams';
import { MarksPage } from './pages/modules/Marks';
import { AssignmentsPage } from './pages/modules/Assignments';
import { FeeVouchersPage, PaymentsPage } from './pages/modules/Fee';
import { ExpensesPage } from './pages/modules/Expenses';
import { PayrollPage } from './pages/modules/Payroll';
import { LeavePage } from './pages/modules/Leave';
import { ApprovalsPage } from './pages/modules/Approvals';
import { NoticesPage } from './pages/modules/Notices';
import { MessagesPage } from './pages/modules/Messages';
import { TimetablePage } from './pages/modules/Timetable';
import { SettingsPage } from './pages/modules/Settings';
import { LogsPage } from './pages/modules/Logs';
import { ReportsPage } from './pages/modules/Reports';
import { StaffPageDocuments } from './pages/modules/Documents';
import { ScannerPage } from './pages/modules/Scanner';
import { IDCardsPage } from './pages/modules/IDCards';
import {
  ResultsPage, StudentFeePage, ParentProgressPage, ParentAttendancePage, ParentFeePage,
} from './pages/modules/StudentViews';
import { AccountsDashboard } from './pages/modules/AccountsDashboard';
import { MyDocumentsPage } from './pages/modules/MyDocuments';
import { DocumentAdminPage } from './pages/modules/DocumentAdmin';
import { CashBookPage, VouchersPage, BankReconciliationPage, SalaryManagementPage } from './pages/modules/AccountsExtra';
import { LibraryPage, TransportPage, HostelPage, InventoryPage } from './pages/modules/OperationsModules';
import { CommunicationPage, NotificationsPage, BranchesPage, DiscountsPage, FinesPage } from './pages/modules/SystemModules';
import { ComplaintsPage, MyRemarksPage } from './pages/modules/Complaints';
import {
  PendingFeesPage, DefaultersPage, FeeStructurePage, IncomePage, GeneralLedgerPage,
  BankTransactionsPage, CollectionReportPage, OutstandingDuesPage, StudentFinancialHistoryPage,
} from './pages/modules/AccountsModules';
import { SubjectsPage } from './pages/modules/Subjects';
import { TeachersPage, ParentsPage, AdmissionsPage, ResultsAdminPage } from './pages/modules/AdminViews';
import { RolesPage } from './pages/modules/Roles';

// Student-context wrappers ---------------------------------------------------
function StudentTimetable() {
  const student = useMyStudent();
  return <TimetablePage classId={student?.class_id} />;
}
function StudentAssignments() {
  const student = useMyStudent();
  return <AssignmentsPage studentMode studentId={student?.id} classId={student?.class_id} />;
}
function StudentAttendanceWrapper() {
  const student = useMyStudent();
  return <AttendanceView studentId={student?.id} />;
}
function TeacherLeave() {
  const { user } = useAuth();
  const staff = useCollection<any>('staff');
  const me = staff.find((s) => s.user_id === user?.id);
  return <LeavePage ownStaffId={me?.id} />;
}
function TeacherMyAttendance() {
  const { user } = useAuth();
  const staff = useCollection<any>('staff');
  const me = staff.find((s) => s.user_id === user?.id);
  return <StaffAttendanceView staffId={me?.id} />;
}

// Route map by role ----------------------------------------------------------
const routesByRole: Record<UserRole, { path: string; el: ReactElement }[]> = {
  super_admin: [
    { path: '', el: <SuperAdminHome /> },
    // Academics
    { path: 'admissions', el: <AdmissionsPage /> },
    { path: 'students', el: <StudentsPage /> },
    { path: 'parents', el: <ParentsPage /> },
    { path: 'teachers', el: <TeachersPage /> },
    { path: 'classes', el: <ClassesPage /> },
    { path: 'subjects', el: <SubjectsPage /> },
    { path: 'timetable', el: <TimetablePage canEdit /> },
    { path: 'attendance', el: <AttendancePage /> },
    { path: 'exams', el: <ExamsPage /> },
    { path: 'results', el: <ResultsAdminPage /> },
    // HR & Staff
    { path: 'staff', el: <StaffPage /> },
    { path: 'payroll', el: <PayrollPage /> },
    { path: 'id-cards', el: <IDCardsPage /> },
    { path: 'scanner', el: <ScannerPage /> },
    // Finance
    { path: 'finance', el: <FeeVouchersPage /> },
    { path: 'cashbook', el: <CashBookPage /> },
    // Operations
    { path: 'library', el: <LibraryPage /> },
    { path: 'transport', el: <TransportPage /> },
    { path: 'hostel', el: <HostelPage /> },
    { path: 'inventory', el: <InventoryPage /> },
    // Communication
    { path: 'communication', el: <CommunicationPage /> },
    { path: 'notifications', el: <NotificationsPage /> },
    { path: 'complaints', el: <ComplaintsPage /> },
    { path: 'notices', el: <NoticesPage canPost /> },
    // System
    { path: 'documents', el: <DocumentAdminPage canManageCategories /> },
    { path: 'reports', el: <ReportsPage /> },
    { path: 'users', el: <UsersPage /> },
    { path: 'roles', el: <RolesPage /> },
    { path: 'branches', el: <BranchesPage /> },
    { path: 'logs', el: <LogsPage /> },
    { path: 'settings', el: <SettingsPage /> },
    { path: 'my-documents', el: <MyDocumentsPage /> },
  ],
  principal: [
    { path: '', el: <PrincipalHome /> },
    { path: 'students', el: <StudentsPage readOnly /> },
    { path: 'staff', el: <StaffPage readOnly /> },
    { path: 'id-cards', el: <IDCardsPage /> },
    { path: 'scanner', el: <ScannerPage /> },
    { path: 'attendance', el: <AttendancePage /> },
    { path: 'exams', el: <ExamsPage /> },
    { path: 'results', el: <ResultsAdminPage /> },
    { path: 'timetable', el: <TimetablePage canEdit /> },
    { path: 'approvals', el: <ApprovalsPage /> },
    { path: 'complaints', el: <ComplaintsPage /> },
    { path: 'notices', el: <NoticesPage canPost /> },
    { path: 'documents', el: <DocumentAdminPage /> },
    { path: 'my-documents', el: <MyDocumentsPage /> },
    { path: 'my-attendance', el: <TeacherMyAttendance /> },
    { path: 'reports', el: <ReportsPage /> },
  ],
  hr: [
    { path: '', el: <HRHome /> },
    { path: 'staff', el: <StaffPage /> },
    { path: 'id-cards', el: <IDCardsPage /> },
    { path: 'scanner', el: <ScannerPage /> },
    { path: 'leave', el: <LeavePage canReview /> },
    { path: 'staff-attendance', el: <StaffAttendancePage /> },
    { path: 'my-attendance', el: <TeacherMyAttendance /> },
    { path: 'payroll', el: <PayrollPage /> },
    { path: 'documents', el: <DocumentAdminPage canManageCategories /> },
    { path: 'staff-files', el: <StaffPageDocuments /> },
    { path: 'my-documents', el: <MyDocumentsPage /> },
  ],
  accounts: [
    { path: '', el: <AccountsDashboard /> },
    // Fee Management
    { path: 'payments', el: <PaymentsPage /> },
    { path: 'fee-vouchers', el: <FeeVouchersPage /> },
    { path: 'pending-fees', el: <PendingFeesPage /> },
    { path: 'defaulters', el: <DefaultersPage /> },
    { path: 'fee-structure', el: <FeeStructurePage /> },
    { path: 'discounts', el: <DiscountsPage /> },
    { path: 'fines', el: <FinesPage /> },
    // Accounting
    { path: 'vouchers', el: <VouchersPage /> },
    { path: 'income', el: <IncomePage /> },
    { path: 'expenses', el: <ExpensesPage canApprove /> },
    { path: 'ledger', el: <GeneralLedgerPage /> },
    { path: 'cashbook', el: <CashBookPage /> },
    { path: 'bank', el: <BankTransactionsPage /> },
    { path: 'reconciliation', el: <BankReconciliationPage /> },
    // Payroll
    { path: 'salary', el: <SalaryManagementPage /> },
    { path: 'payroll', el: <PayrollPage /> },
    // Reports
    { path: 'reports', el: <ReportsPage /> },
    { path: 'student-finance', el: <StudentFinancialHistoryPage /> },
    { path: 'daily-collection', el: <CollectionReportPage period="daily" /> },
    { path: 'monthly-collection', el: <CollectionReportPage period="monthly" /> },
    { path: 'outstanding', el: <OutstandingDuesPage /> },
    // Personal
    { path: 'my-attendance', el: <TeacherMyAttendance /> },
    { path: 'documents', el: <MyDocumentsPage /> },
  ],
  teacher: [
    { path: '', el: <TeacherHome /> },
    { path: 'scanner', el: <ScannerPage /> },
    { path: 'attendance', el: <AttendancePage /> },
    { path: 'marks', el: <MarksPage /> },
    { path: 'assignments', el: <AssignmentsPage /> },
    { path: 'complaints', el: <ComplaintsPage /> },
    { path: 'timetable', el: <TimetablePage canEdit /> },
    { path: 'my-attendance', el: <TeacherMyAttendance /> },
    { path: 'documents', el: <MyDocumentsPage /> },
    { path: 'leave', el: <TeacherLeave /> },
  ],
  student: [
    { path: '', el: <StudentHome /> },
    { path: 'timetable', el: <StudentTimetable /> },
    { path: 'assignments', el: <StudentAssignments /> },
    { path: 'results', el: <ResultsPage /> },
    { path: 'fee', el: <StudentFeePage /> },
    { path: 'attendance', el: <StudentAttendanceWrapper /> },
    { path: 'remarks', el: <MyRemarksPage /> },
    { path: 'documents', el: <MyDocumentsPage /> },
    { path: 'notices', el: <NoticesPage /> },
  ],
  parent: [
    { path: '', el: <ParentHome /> },
    { path: 'progress', el: <ParentProgressPage /> },
    { path: 'attendance', el: <ParentAttendancePage /> },
    { path: 'fee', el: <ParentFeePage /> },
    { path: 'remarks', el: <MyRemarksPage forParent /> },
    { path: 'messages', el: <MessagesPage /> },
    { path: 'documents', el: <MyDocumentsPage /> },
    { path: 'notices', el: <NoticesPage /> },
  ],
};

function DashboardLayout() {
  const { user, isLoading } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  if (isLoading) {
    return (
      <div className="flex h-screen items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100">
        <div className="text-center">
          <div className="mx-auto h-12 w-12 animate-spin rounded-full border-4 border-slate-300 border-t-blue-600" />
          <p className="mt-4 text-slate-600">Loading...</p>
        </div>
      </div>
    );
  }
  if (!user) return <Navigate to="/login" replace />;

  const routes = routesByRole[user.role] || [];

  return (
    <div className="flex h-screen bg-slate-50">
      <Sidebar role={user.role} open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <div className="flex flex-1 flex-col overflow-hidden">
        <Header user={user} onMenuClick={() => setSidebarOpen(true)} />
        {/* pb-20 par phone par bottom-nav ke neeche content na chhupe */}
        <main className="flex-1 overflow-y-auto p-4 pb-24 sm:p-6 lg:pb-6">
          <Breadcrumb />
          <Routes>
            {routes.map((r) => (
              <Route key={r.path} path={r.path} element={r.el} />
            ))}
            <Route path="*" element={<Navigate to="/dashboard" replace />} />
          </Routes>
        </main>
      </div>
      {/* Mobile bottom navigation */}
      <BottomNav role={user.role} />
    </div>
  );
}

function Root() {
  const { user } = useAuth();
  // Agar user logged in hai to dashboard, warna version selection page.
  return user ? <Navigate to="/dashboard" replace /> : <VersionSelect />;
}

export default function App() {
  return (
    <AuthProvider>
      <ToastProvider>
        <ConfirmProvider>
          <Router>
            <Routes>
              <Route path="/" element={<Root />} />
              <Route path="/login" element={<Login />} />
              <Route path="/dashboard/*" element={<DashboardLayout />} />
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </Router>
        </ConfirmProvider>
      </ToastProvider>
    </AuthProvider>
  );
}

// keep getAll referenced for tree-shaking safety in some bundlers
void getAll;
