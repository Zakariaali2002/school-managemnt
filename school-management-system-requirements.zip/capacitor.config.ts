import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  // App ka unique package ID — Play Store par ye unique hona chahiye.
  // Apna domain ulta likh kar app ka naam lagayein (reverse-domain notation).
  appId: 'com.citygrammar.sms',

  // App ka display naam jo phone par dikhega.
  appName: 'School Management System',

  // Vite ki build output directory. `npm run build` ke baad yahin se app load hoti hai.
  webDir: 'dist',

  // Android specific settings
  android: {
    // Mixed content allow karna (agar koi http resource ho) — optional.
    allowMixedContent: true,
  },

  plugins: {
    SplashScreen: {
      // App khulne par splash screen kitni der dikhe (milliseconds).
      launchShowDuration: 1500,
      backgroundColor: '#4f46e5', // indigo (aapki theme ke mutabiq)
      androidSplashResourceName: 'splash',
      showSpinner: false,
    },
    StatusBar: {
      // Status bar ka rang theme se match.
      backgroundColor: '#4f46e5',
      style: 'LIGHT',
    },
  },
};

export default config;
