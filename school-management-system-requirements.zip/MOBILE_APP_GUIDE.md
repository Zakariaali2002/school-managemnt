# 📱 Mobile App Banane aur Play Store par Upload karne ki Complete Guide

Aapki website ab **Capacitor** ke zariye Android app mein convert hone ke liye taiyar hai.
Yeh guide step-by-step bataati hai. Saare commands **apne computer** (laptop/PC) par
terminal/command prompt mein chalane hain.

---

## ✅ Kya kya pehle se ho chuka hai (is project mein)

- Capacitor install ho chuka hai (`@capacitor/core`, `@capacitor/cli`, `@capacitor/android`)
- `capacitor.config.ts` ban chuki hai (app ka naam aur ID set hai)
- Native helpers (status bar, splash screen, Android back button) add ho chuke hain
- App icon (`resources/icon.png`) aur splash (`resources/splash.png`) ban chuke hain

---

## 🧰 Zaroori Software (ek dafa install karein)

1. **Node.js** (v18 ya us se upar) — https://nodejs.org
2. **Android Studio** — https://developer.android.com/studio
   - Install ke baad ek dafa khol kar "Android SDK" aur "Android SDK Platform-Tools"
     ko download hone dein.
3. **Java JDK 17** — Android Studio ke saath aam tor par aa jaata hai.

---

## 🚀 Step 1 — Project download/clone karein apne computer par

Is poore project ko apne computer par le jaayein (download ZIP ya git clone),
phir us folder mein terminal kholein aur dependencies install karein:

```bash
npm install
```

---

## 🏗️ Step 2 — Web app build karein

```bash
npm run build
```

Isse `dist/` folder ban jaayega jisme aapki website ki final files hongi.

---

## 🤖 Step 3 — Android platform add karein (sirf pehli dafa)

```bash
npx cap add android
```

Isse project mein ek `android/` folder ban jaayega — yeh aapka asli Android project hai.

> Note: Agar `android/` folder pehle se mojood hai to ye step skip karein.

---

## 🔄 Step 4 — Web files ko Android app mein copy/sync karein

Jab bhi aap website mein koi tabdeeli karein, dobara build aur sync karein:

```bash
npm run build
npx cap sync android
```

Ya shortcut (project mein add kiya gaya hai):

```bash
npm run cap:sync
```

---

## 🎨 Step 5 — App icon aur splash screen lagayein (recommended)

`resources/icon.png` aur `resources/splash.png` pehle se mojood hain.
Inhe automatically saare Android sizes mein generate karne ke liye:

```bash
npm install -g @capacitor/assets
npx capacitor-assets generate --android
```

Isse app ka icon aur splash screen sab device sizes ke liye ban jaayega.

---

## 📱 Step 6 — Android Studio mein kholein aur test karein

```bash
npx cap open android
```

Ya shortcut:

```bash
npm run cap:open
```

Android Studio khulega. Phir:

1. Ek emulator (virtual phone) ya apna asli phone USB se connect karein
   (phone par "USB debugging" on karein — Settings → Developer Options).
2. Upar **▶ (Run)** button dabayein.
3. App aapke phone/emulator par chal padegi! 🎉

---

## 📦 Step 7 — Play Store ke liye signed APP BUNDLE (.aab) banayein

Play Store par upload ke liye **AAB (Android App Bundle)** chahiye, aur usay
"sign" karna zaroori hai.

### 7a. Signing key banayein (sirf ek dafa — is file ko kabhi na khoyein!)

Terminal mein:

```bash
keytool -genkey -v -keystore my-release-key.keystore -alias my-app-key -keyalg RSA -keysize 2048 -validity 10000
```

Yeh aapse password aur kuch maloomaat poochhega. **Password aur `.keystore` file
ko mehfooz rakhein** — har future update ke liye yehi key chahiye hogi.

### 7b. Android Studio se AAB build karein

1. Android Studio mein menu: **Build → Generate Signed Bundle / APK**
2. **Android App Bundle** chunein → Next
3. **Choose existing** → apni `my-release-key.keystore` file select karein,
   password aur alias (`my-app-key`) dalein → Next
4. **release** build variant chunein → Finish
5. Build complete hone par `.aab` file is path par milegi:
   `android/app/release/app-release.aab`

---

## 🏪 Step 8 — Google Play Store par upload karein

1. **Google Play Console** account banayein: https://play.google.com/console
   - Ek dafa **$25 (one-time fee)** dena padta hai.
2. **Create app** par click karein → app ka naam, language, type (App), free/paid chunein.
3. Left menu se ye sab complete karein (Play Console khud guide karta hai):
   - **App content** — Privacy Policy, Ads, Content rating, Target audience, Data safety
   - **Store listing** — App description, screenshots (phone ke), icon (512x512),
     feature graphic (1024x500)
4. **Production → Create new release** par jaayein.
5. Apni **`app-release.aab`** file upload karein.
6. Release notes likhein → **Review** → **Start rollout to Production**.
7. Google review karega (kuch ghante se kuch din). Approve hone par aapki app
   Play Store par live ho jaayegi aur log download kar sakenge! 🎉

---

## 🔁 App update kaise karein (future mein)

1. Website mein tabdeeli karein.
2. `capacitor.config.ts` / Android mein **versionCode badhayein** aur versionName update karein
   (`android/app/build.gradle` mein `versionCode` aur `versionName`).
3. `npm run cap:sync`
4. Naya signed `.aab` banayein (wahi keystore use karein).
5. Play Console mein new release upload karein.

---

## ⚙️ App ki maloomaat (capacitor.config.ts mein set hai)

| Cheez | Value | Kahan badlein |
|------|-------|----------------|
| App Name | School Management System | `capacitor.config.ts` → `appName` |
| Package ID | com.citygrammar.sms | `capacitor.config.ts` → `appId` |
| Theme Color | #4f46e5 (Indigo) | `capacitor.config.ts` → plugins |

> **Zaroori:** Play Store par `appId` (package name) unique hona chahiye aur
> app publish hone ke baad **kabhi change nahi ho sakta**. Isliye apna asli
> domain/brand use karein, jaise `com.aapkaschool.app`.

---

## ❓ Common masail

- **App khali/white screen dikhata hai:** `npm run build` dobara chalayein phir
  `npx cap sync android`.
- **Icon nahi badla:** `npx capacitor-assets generate --android` chalayein, phir
  Android Studio mein **Build → Clean Project**.
- **Gradle error:** Android Studio ko internet se SDK download karne dein, phir
  **File → Sync Project with Gradle Files**.

---

Mubarak ho! 🎓📱 Aapki website ab ek poori Android app hai jo Play Store par
upload ho sakti hai.
